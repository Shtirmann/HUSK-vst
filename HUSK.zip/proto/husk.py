"""
HUSK — прототип DSP-ядра.

Идея: живой гитарный сигнал разбирается на два слоя нулевой латентностью —
CORE (предсказуемая, тональная часть) и HUSK (шелуха: атака медиатора, скрип
пальцев, стук по деке, шум ладов). Дальше слои МЕНЯЮТСЯ РОЛЯМИ: шелуха, которую
обычно выбрасывают, возбуждает большое резонирующее тело, а тон уходит в поле
симпатических струн, настроенных под тональность того, что ты играешь.

Всё аудио идёт по time-domain путям: латентность 0 сэмплов.
Анализ (питч, тональность) живёт в control-пути и «опаздывает» — это не слышно.

Блоки повторяют будущую C++/JUCE-структуру один в один.
"""
import numpy as np
from numba import njit
from dataclasses import dataclass, field

SR = 48000
N_MODES = 64


# ============================================================== 1. АНАЛИЗ
@njit(cache=True)
def dc_block(x, fc, sr):
    R = 1.0 - 2.0 * np.pi * fc / sr
    y = np.zeros_like(x)
    x1 = 0.0
    y1 = 0.0
    for n in range(len(x)):
        y1 = x[n] - x1 + R * y1
        x1 = x[n]
        y[n] = y1
    return y


@njit(cache=True)
def transientness(x, sr, n_bands, edges):
    """Многополосный детектор «транзиентности» 0..1, латентность 0.
    В каждой полосе — быстрая и медленная огибающая, отношение -> T."""
    n = len(x)
    T = np.zeros(n)
    # простые однополюсные полосовые через каскад LP (достаточно для управления)
    lp_state = np.zeros(n_bands + 1)
    a = np.zeros(n_bands + 1)
    for b in range(n_bands + 1):
        a[b] = np.exp(-2.0 * np.pi * edges[b] / sr)

    ef = np.zeros(n_bands)
    es = np.zeros(n_bands)
    af_at = np.exp(-1.0 / (0.0006 * sr))
    af_rl = np.exp(-1.0 / (0.012 * sr))
    as_at = np.exp(-1.0 / (0.035 * sr))
    as_rl = np.exp(-1.0 / (0.220 * sr))

    for i in range(n):
        xi = x[i]
        prev = xi
        acc = 0.0
        for b in range(n_bands):
            lp_state[b] = (1.0 - a[b]) * prev + a[b] * lp_state[b]
            band = prev - lp_state[b]          # HP-остаток = полоса выше edges[b]
            prev = lp_state[b]
            m = abs(band)
            if m > ef[b]:
                ef[b] = af_at * ef[b] + (1.0 - af_at) * m
            else:
                ef[b] = af_rl * ef[b] + (1.0 - af_rl) * m
            if m > es[b]:
                es[b] = as_at * es[b] + (1.0 - as_at) * m
            else:
                es[b] = as_rl * es[b] + (1.0 - as_rl) * m
            r = ef[b] / (es[b] + 1e-9) - 1.0
            if r < 0.0:
                r = 0.0
            if r > 1.0:
                r = 1.0
            acc += r * (es[b] + 1e-9)
        # взвешенное по энергии среднее по полосам
        tot = 0.0
        for b in range(n_bands):
            tot += es[b] + 1e-9
        T[i] = acc / tot
    return T


@njit(cache=True)
def nlms_ale(x, P, delta, mu):
    """Adaptive Line Enhancer: предсказуемое (тон) vs непредсказуемое (шелуха).
    Латентность delta сэмплов (~0.1 мс)."""
    n = len(x)
    w = np.zeros(P)
    tonal = np.zeros(n)
    resid = np.zeros(n)
    pwr = 1e-6
    for i in range(n):
        y = 0.0
        base = i - delta
        for k in range(P):
            j = base - k
            if j >= 0:
                y += w[k] * x[j]
        e = x[i] - y
        # NLMS
        if base >= P:
            pwr = 0.999 * pwr + 0.001 * (x[base] * x[base]) * P
        g = mu * e / (pwr + 1e-9)
        for k in range(P):
            j = base - k
            if j >= 0:
                w[k] += g * x[j]
        tonal[i] = y
        resid[i] = e
    return tonal, resid


@njit(cache=True)
def track_pitch(x, sr, hop, fmin, fmax):
    """YIN-подобный трекер на control-rate. Возвращает f0 и confidence на hop-сетке."""
    tau_max = int(sr / fmin)
    tau_min = int(sr / fmax)
    W = 2 * tau_max
    n_frames = max(1, (len(x) - W) // hop)
    f0 = np.zeros(n_frames)
    conf = np.zeros(n_frames)
    d = np.zeros(tau_max + 1)
    for m in range(n_frames):
        off = m * hop
        for tau in range(tau_min, tau_max + 1):
            s = 0.0
            for j in range(W - tau_max):
                dv = x[off + j] - x[off + j + tau]
                s += dv * dv
            d[tau] = s
        # CMND
        run = 0.0
        best = -1
        best_v = 1e9
        for tau in range(tau_min, tau_max + 1):
            run += d[tau]
            dn = d[tau] * (tau - tau_min + 1) / (run + 1e-12)
            if dn < best_v:
                best_v = dn
                best = tau
            if dn < 0.12 and tau > tau_min + 1:
                best = tau
                best_v = dn
                break
        if best > tau_min and best < tau_max:
            y0 = d[best - 1]
            y1 = d[best]
            y2 = d[best + 1]
            den = 2.0 * (2.0 * y1 - y0 - y2)
            shift = 0.0 if abs(den) < 1e-12 else (y2 - y0) / den
            f0[m] = sr / (best + shift)
            c = 1.0 - best_v
            conf[m] = 0.0 if c < 0.0 else (1.0 if c > 1.0 else c)
    return f0, conf


KS_MAJOR = np.array([6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88])
KS_MINOR = np.array([6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17])
MAJ_SCALE = np.array([0, 2, 4, 5, 7, 9, 11])
MIN_SCALE = np.array([0, 2, 3, 5, 7, 8, 10])


def estimate_key(x, sr):
    """Хрома по Goertzel-подобной сетке + профили Krumhansl-Schmuckler."""
    from scipy.signal import stft
    f, t, Z = stft(x, fs=sr, nperseg=8192, noverlap=6144)
    mag = np.abs(Z) ** 2
    chroma = np.zeros(12)
    for i, fr in enumerate(f):
        if fr < 70 or fr > 2200:
            continue
        p = 12 * np.log2(fr / 440.0) + 69
        pc = int(round(p)) % 12
        w = 1.0 / (1.0 + np.exp(-(fr - 140) / 60))   # давим бас
        chroma[pc] += mag[i].sum() * w
    chroma = np.log1p(100 * chroma / (chroma.max() + 1e-12))
    chroma -= chroma.mean()
    best = (None, -9)
    for r in range(12):
        rot = np.roll(chroma, -r)
        for prof, name, scale in ((KS_MAJOR, "maj", MAJ_SCALE), (KS_MINOR, "min", MIN_SCALE)):
            p = prof - prof.mean()
            c = float(np.dot(rot, p) / (np.linalg.norm(rot) * np.linalg.norm(p) + 1e-12))
            if c > best[1]:
                best = ((r, name, scale), c)
    return best[0]


# ============================================================== 2. МОДАЛЬНОЕ ТЕЛО
def mode_ratios(body: float, n=N_MODES):
    """Морфинг формы объекта: струна -> труба -> брусок -> пластина."""
    k = np.arange(1, n + 1, dtype=float)
    string = k * np.sqrt(1.0 + 1.2e-4 * k * k)
    tube = 2.0 * k - 1.0
    bar = (2.0 * k + 1.0) ** 2 / 9.0
    # пластина / мембрана: реальные нули Бесселя, дальше — плавное продолжение
    mem12 = np.array([1.0, 1.593, 2.135, 2.295, 2.653, 2.917,
                      3.155, 3.500, 3.598, 3.652, 3.869, 4.060])
    plate = np.empty(n)
    plate[:12] = mem12
    kk = np.arange(13, n + 1, dtype=float)
    plate[12:] = mem12[-1] * (kk / 12.0) ** 0.78 * (1.0 + 0.045 * np.sin(2.39 * kk))

    tables = [string, tube, bar, plate]
    pos = np.clip(body, 0.0, 1.0) * (len(tables) - 1)
    i = int(np.floor(pos))
    if i >= len(tables) - 1:
        return tables[-1]
    fr = pos - i
    return np.exp((1 - fr) * np.log(tables[i]) + fr * np.log(tables[i + 1]))


@njit(cache=True)
def modal_bank(x, sr, f0_ctrl, ratios, decay, bright, position, ctrl_hop,
               n_active=64, t60_min=0.05, tilt=1.0):
    """Банк из N комплексных однополюсников. Латентность 0.

    t60_min — нижняя граница времени затухания. Это ключевой параметр «пятна»:
    если верхние моды становятся широкополосными (малый T60), банк перестаёт быть
    резонатором и превращается в шумовой фильтр. 40–80 мс держит его тональным.
    """
    n = len(x)
    m = len(ratios)
    if n_active < m:
        m = n_active
    out = np.zeros(n)
    re = np.zeros(m)
    im = np.zeros(m)
    pr = np.zeros(m)
    pi_ = np.zeros(m)
    amp = np.zeros(m)

    for i in range(n):
        if i % ctrl_hop == 0:
            f0 = f0_ctrl[i // ctrl_hop] if (i // ctrl_hop) < len(f0_ctrl) else f0_ctrl[-1]
            # q_loss: верхние моды теряют добротность (это и есть «органика»)
            q_loss = bright * (2.0 - bright) * 0.85 + 0.15
            loss = 1.0
            for k in range(m):
                fk = f0 * ratios[k]
                if fk > 0.45 * sr or fk < 15.0:
                    pr[k] = 0.0
                    pi_[k] = 0.0
                    amp[k] = 0.0
                    continue
                t60 = decay * loss
                if t60 < t60_min:
                    t60 = t60_min
                R = 10.0 ** (-3.0 / (sr * t60))
                w = 2.0 * np.pi * fk / sr
                pr[k] = R * np.cos(w)
                pi_[k] = R * np.sin(w)
                # позиция возбуждения: sin(k*pi*p) — гребёнка по модам
                a_pos = np.sin(np.pi * (k + 1) * position)
                amp[k] = (1.0 - R) * a_pos / (1.0 + tilt * 0.25 * k)
                loss *= q_loss
        acc = 0.0
        xi = x[i]
        for k in range(m):
            if amp[k] == 0.0:
                continue
            nr = xi + pr[k] * re[k] - pi_[k] * im[k]
            ni = pr[k] * im[k] + pi_[k] * re[k]
            re[k] = nr
            im[k] = ni
            acc += amp[k] * ni
        out[i] = acc
    return out


# ============================================================== 3. СИМПАТИЧЕСКОЕ ПОЛЕ
@njit(cache=True)
def sympathetic(x, sr, freqs, decay, damp_hf, drift, drift_rate, seed):
    """K независимых waveguide-петель (feed-forward => безусловно устойчиво).
    Латентность 0."""
    K = len(freqs)
    n = len(x)
    maxL = int(sr / max(freqs.min(), 20.0)) + 8
    buf = np.zeros((K, maxL))
    wp = np.zeros(K, dtype=np.int64)
    L0 = np.zeros(K)
    g = np.zeros(K)
    a = np.zeros(K)
    lpz = np.zeros(K)
    apz = np.zeros(K)
    dcx = np.zeros(K)
    dcy = np.zeros(K)
    ph = np.zeros(K)
    np.random.seed(seed)
    for k in range(K):
        L0[k] = sr / freqs[k]
        g[k] = 10.0 ** (-3.0 * L0[k] / (sr * decay))
        ratio = damp_hf
        a[k] = -(1.0 - ratio) / (1.0 + ratio) * 0.9
        if a[k] < -0.88:
            a[k] = -0.88
        ph[k] = np.random.random() * 6.283185

    out = np.zeros(n)
    inv = 1.0 / np.sqrt(K)
    dw = 2.0 * np.pi * drift_rate / sr

    for i in range(n):
        xi = x[i]
        acc = 0.0
        for k in range(K):
            ph[k] += dw * (0.6 + 0.8 * (k % 5) / 4.0)
            L = L0[k] * (1.0 + drift * 0.004 * np.sin(ph[k]))
            Li = int(L)
            frac = L - Li
            if Li < 4:
                Li = 4
            if Li > maxL - 4:
                Li = maxL - 4
            rp = wp[k] - Li
            if rp < 0:
                rp += maxL
            s = buf[k, rp]
            c = (1.0 - frac) / (1.0 + frac)
            y_ap = c * (s - apz[k]) + apz[k]
            apz[k] = s
            s = y_ap
            lp = g[k] * (1.0 + a[k]) * s - a[k] * lpz[k]
            lpz[k] = lp
            dcy[k] = lp - dcx[k] + 0.9993 * dcy[k]
            dcx[k] = lp
            v = dcy[k] + xi * (1.0 - g[k]) * inv
            buf[k, wp[k]] = v
            wp[k] += 1
            if wp[k] >= maxL:
                wp[k] = 0
            acc += s
        out[i] = acc * inv
    return out


def scale_frequencies(root, scale, lo_midi=45, hi_midi=81, n_strings=10):
    notes = []
    m = lo_midi
    while m <= hi_midi:
        if (m - root) % 12 in scale:
            notes.append(m)
        m += 1
    if len(notes) > n_strings:
        idx = np.linspace(0, len(notes) - 1, n_strings).round().astype(int)
        notes = [notes[i] for i in idx]
    return np.array([440.0 * 2 ** ((m - 69) / 12.0) for m in notes])


# ============================================================== 4. ВОЗДУХ (FDN-8)
@njit(cache=True)
def onepole_hp(x, fc, sr):
    a = np.exp(-2.0 * np.pi * fc / sr)
    y = np.zeros_like(x)
    z = 0.0
    for i in range(len(x)):
        z = (1.0 - a) * x[i] + a * z
        y[i] = x[i] - z
    return y


@njit(cache=True)
def fdn8(x, sr, size, feedback, damp, mod_depth, mod_rate, drive):
    N = 8
    base = np.array([0.0431, 0.0537, 0.0669, 0.0761, 0.0893, 0.1039, 0.1181, 0.1327])
    lens = np.empty(N, dtype=np.int64)
    maxL = 1
    for i in range(N):
        lens[i] = int(base[i] * size * sr)
        if lens[i] < 32:
            lens[i] = 32
        if lens[i] > maxL:
            maxL = lens[i]
    maxL += 64
    buf = np.zeros((N, maxL))
    wp = np.zeros(N, dtype=np.int64)
    lpz = np.zeros(N)
    dcx = np.zeros(N)
    dcy = np.zeros(N)
    ph = np.zeros(N)
    for i in range(N):
        ph[i] = i * 0.7854
    dw = 2.0 * np.pi * mod_rate / sr
    n = len(x)
    outL = np.zeros(n)
    outR = np.zeros(n)
    s = np.zeros(N)
    ap = np.exp(-2.0 * np.pi * (500.0 + 9000.0 * (1.0 - damp)) / sr)

    for t in range(n):
        # чтение с модуляцией
        for i in range(N):
            ph[i] += dw * (0.7 + 0.09 * i)
            d = lens[i] + mod_depth * sr * 0.0004 * np.sin(ph[i])
            di = int(d)
            fr = d - di
            r0 = wp[i] - di
            r1 = r0 - 1
            if r0 < 0:
                r0 += maxL
            if r1 < 0:
                r1 += maxL
            s[i] = buf[i, r0] * (1.0 - fr) + buf[i, r1] * fr

        # Householder: out_i = s_i - (2/N) * sum
        sm = 0.0
        for i in range(N):
            sm += s[i]
        sm *= 2.0 / N
        for i in range(N):
            v = (s[i] - sm) * feedback
            # потери
            lpz[i] = (1.0 - ap) * v + ap * lpz[i]
            v = lpz[i]
            # мягкое насыщение в петле
            if drive > 0.0:
                v = np.tanh(v * (1.0 + 3.0 * drive)) / (1.0 + 3.0 * drive)
            dcy[i] = v - dcx[i] + 0.9995 * dcy[i]
            dcx[i] = v
            v = dcy[i] + x[t] * 0.35
            buf[i, wp[i]] = v
            wp[i] += 1
            if wp[i] >= maxL:
                wp[i] = 0
        l = 0.0
        r = 0.0
        for i in range(N):
            if i % 2 == 0:
                l += s[i]
            else:
                r += s[i]
        outL[t] = l * 0.5
        outR[t] = r * 0.5
    return outL, outR


# ============================================================== 5. ЦЕПЬ
@dataclass
class Params:
    # разбор
    split: float = 0.5        # 0 = движки питает CORE, 1 = HUSK
    cross: float = 0.0        # 0 = husk->тело / core->поле, 1 = наоборот
    husk_gain: float = 1.0
    # тело
    body: float = 0.35        # струна..труба..брусок..пластина
    body_decay: float = 1.8
    body_modes: int = 20      # плотность: мало мод = чистый тон, много = «пятно»
    body_t60min: float = 0.08  # нижняя граница затухания мод (держит банк тональным)
    body_tilt: float = 1.0
    body_bright: float = 0.55
    body_position: float = 0.28
    body_follow: float = 1.0  # 1 = следить за сыгранной нотой
    body_tune: float = 110.0  # если follow = 0
    body_amt: float = 0.9
    # поле
    field_amt: float = 0.7
    field_decay: float = 4.0
    field_damp: float = 0.22
    field_strings: int = 10
    drift: float = 0.35
    # воздух
    air_amt: float = 0.4
    air_size: float = 1.0
    air_feedback: float = 0.82
    air_damp: float = 0.45
    air_drive: float = 0.15
    # выход
    mix: float = 0.6
    out_gain: float = 1.0


def quantize_to_scale(f0, root, scale):
    """Снап f0 в ближайшую ступень лада. Резонаторы не должны «вылизывать» глиссандо."""
    midi = 69 + 12 * np.log2(np.maximum(f0, 20.0) / 440.0)
    out = np.empty_like(midi)
    for i, m in enumerate(midi):
        cand = np.round(m)
        # ближайшая нота лада
        best = cand
        bd = 99
        for d in range(-3, 4):
            c = cand + d
            if (int(c) - root) % 12 in scale:
                if abs(c - m) < bd:
                    bd = abs(c - m)
                    best = c
        out[i] = best
    return 440.0 * 2 ** ((out - 69) / 12.0)


def process(x, sr=SR, p: Params = None, verbose=True):
    p = p or Params()
    x = np.asarray(x, dtype=np.float64)
    xd = dc_block(x, 18.0, sr)

    # --- анализ
    edges = np.array([220.0, 900.0, 2800.0, 7000.0, 16000.0])
    T = transientness(xd, sr, 4, edges)
    tonal, resid = nlms_ale(xd, 320, 4, 0.06)

    hop = 256
    f0, conf = track_pitch(xd, sr, hop, 70.0, 1200.0)
    # держим последнюю уверенную ноту
    held = np.zeros(len(f0))
    last = 110.0
    for i in range(len(f0)):
        if conf[i] > 0.72 and 60 < f0[i] < 1400:
            last = f0[i]
        held[i] = last

    root, mode, scale = estimate_key(x, sr)
    names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
    # квантуем в лад, потом быстрый слю (≈20 мс) — без «вау»-глиссандо по модам
    held = quantize_to_scale(held, root, scale)
    al = np.exp(-hop / (0.020 * sr))
    for i in range(1, len(held)):
        held[i] = al * held[i - 1] + (1 - al) * held[i]
    if verbose:
        print(f"    тональность: {names[root]} {mode}   "
              f"медианная f0: {np.median(held):.1f} Гц   "
              f"средняя transientness: {T.mean():.3f}")

    # --- два слоя
    # шелуха = непредсказуемый остаток, но только там, где реально играют:
    # T^1.4 душит стационарный шумовой пол, экспандер по огибающей входа — фон.
    env = np.abs(xd)
    ae = np.exp(-1.0 / (0.030 * sr))
    for i in range(1, len(env)):
        env[i] = max(env[i], ae * env[i - 1])
    thr = 0.06 * np.percentile(env, 98)
    gate = np.clip((env - thr) / (thr + 1e-9), 0.0, 1.0) ** 1.5

    husk = onepole_hp(resid, 150.0, sr) * (T ** 1.4) * gate * p.husk_gain
    core = tonal * gate

    ref = np.sqrt(np.mean(xd ** 2)) + 1e-9
    eh = np.sqrt(np.mean(husk ** 2)) + 1e-9
    ec = np.sqrt(np.mean(core ** 2)) + 1e-9
    # makeup ограничен: слои не должны «вытягивать» шумовой пол
    husk_n = husk * min(ref / eh, 12.0)
    core_n = core * min(ref / ec, 4.0)

    # SPLIT — кроссфейд источника, CROSS — обмен адресами движков
    a = p.split
    srcA = (1 - a) * core_n + a * husk_n
    srcB = a * core_n + (1 - a) * husk_n
    c = p.cross
    exc_body = (1 - c) * srcA + c * srcB
    exc_field = onepole_hp((1 - c) * srcB + c * srcA, 95.0, sr)

    # --- тело
    ctrl = np.zeros(len(xd) // hop + 2)
    for i in range(len(ctrl)):
        j = min(i, len(held) - 1)
        ctrl[i] = held[j] if p.body_follow > 0.5 else p.body_tune
    ratios = mode_ratios(p.body)
    body = modal_bank(exc_body * 0.9, sr, ctrl, ratios,
                      p.body_decay, p.body_bright, p.body_position, hop,
                      n_active=p.body_modes, t60_min=p.body_t60min,
                      tilt=p.body_tilt)

    # --- поле
    freqs = scale_frequencies(root, scale, n_strings=p.field_strings)
    fieldy = sympathetic(exc_field, sr, freqs, p.field_decay, p.field_damp,
                         p.drift, 0.17, 1234)

    def rms(v):
        return np.sqrt(np.mean(v ** 2)) + 1e-12

    body *= ref / rms(body)
    fieldy *= ref / rms(fieldy)

    wet = p.body_amt * body + p.field_amt * fieldy
    wet *= ref / rms(wet)

    # --- воздух (стерео)
    if p.air_amt > 0.001:
        aL, aR = fdn8(wet, sr, p.air_size, p.air_feedback, p.air_damp,
                      1.0, 0.13, p.air_drive)
        g = ref / (0.5 * (rms(aL) + rms(aR)))
        aL *= g
        aR *= g
        wetL = (1 - p.air_amt) * wet + p.air_amt * aL
        wetR = (1 - p.air_amt) * wet + p.air_amt * aR
    else:
        wetL = wet.copy()
        wetR = wet.copy()

    # лёгкая стереодекорреляция самих движков
    wetL = 0.82 * wetL + 0.18 * (p.body_amt * body * ref / rms(body))
    wetR = 0.82 * wetR + 0.18 * (p.field_amt * fieldy * ref / rms(fieldy))

    wetL = dc_block(wetL, 22.0, sr)
    wetR = dc_block(wetR, 22.0, sr)
    gw = ref / (0.5 * (rms(wetL) + rms(wetR)))
    wetL *= gw
    wetR *= gw

    yL = (1 - p.mix) * xd + p.mix * wetL * 0.9
    yR = (1 - p.mix) * xd + p.mix * wetR * 0.9
    y = np.stack([yL, yR], axis=1) * p.out_gain

    peak = np.max(np.abs(y))
    if peak > 0.95:
        y = np.tanh(y * (1.2 / peak)) * 0.82
    return y.astype(np.float32), dict(husk=husk_n, core=core_n, body=body,
                                      field=fieldy, T=T, f0=held,
                                      key=f"{names[root]} {mode}")
