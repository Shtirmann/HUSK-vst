"""Демонстрация того, что шелуха не усиливается, а работает МОЛОТОЧКОМ."""
import numpy as np, soundfile as sf
import husk
from husk import Params

SR = 48000
OUT = "/home/claude/husk/render"


def norm(y, target=0.13):
    y = np.asarray(y, dtype=np.float64)
    if y.ndim == 1:
        y = np.stack([y, y], 1)
    y = y * (target / (np.sqrt(np.mean(y ** 2)) + 1e-12))
    y = np.tanh(y * 1.05) / np.tanh(1.05) * 0.94
    p = np.max(np.abs(y))
    if p > 0.99:
        y *= 0.99 / p
    return y.astype(np.float32)


def tick(k):
    n = int(0.10 * SR)
    t = np.arange(n) / SR
    s = np.sin(2 * np.pi * 880 * t) * np.exp(-t * 55) * 0.10
    seq = []
    for _ in range(k):
        seq += [s, np.zeros(int(0.11 * SR))]
    seq.append(np.zeros(int(0.45 * SR)))
    v = np.concatenate(seq)
    return np.stack([v, v], 1).astype(np.float32)


def gap(s=0.8):
    v = np.zeros(int(s * SR))
    return np.stack([v, v], 1).astype(np.float32)


x, _ = sf.read(f"{OUT}/src_fingerstyle.wav")
x = x[: SR * 7]
_, info = husk.process(x, SR, Params(mix=0.0), verbose=True)
h = np.asarray(info["husk"], dtype=float)
f0 = np.asarray(info["f0"], dtype=float)
nctrl = len(h) // 256 + 2
ctrl_follow = np.interp(np.linspace(0, len(f0) - 1, nctrl),
                        np.arange(len(f0)), f0)

ratios = husk.mode_ratios(0.10)

# 3. шелуха бьёт по телу, настроенному на одну ноту (D2)
b_fix = husk.modal_bank(h * 0.9, SR, np.full(nctrl, 73.42), ratios,
                        3.0, 0.5, 0.24, 256, n_active=14, t60_min=0.12, tilt=1.3)
# 4. то же, но тело следит за сыгранной нотой
b_fol = husk.modal_bank(h * 0.9, SR, ctrl_follow, ratios,
                        2.0, 0.5, 0.24, 256, n_active=18, t60_min=0.09, tilt=1.1)
# 5. шелуха раскачивает симпатическое поле в D maj
freqs = husk.scale_frequencies(2, husk.MAJ_SCALE, n_strings=10)
fld = husk.sympathetic(husk.onepole_hp(h, 95.0, SR), SR, freqs, 6.0, 0.2, 0.4, 0.17, 7)

# 6. полный плагин, 100 % wet — в выходе нет ни одного щелчка входа
p = Params(split=0.55, cross=0.0, body=0.22, body_decay=2.4, body_modes=18,
           body_t60min=0.09, body_bright=0.5, body_amt=1.0,
           field_amt=0.6, field_decay=5.0, field_damp=0.2, drift=0.4,
           air_amt=0.3, air_size=1.0, air_feedback=0.82, air_damp=0.45,
           air_drive=0.1, mix=1.0)
wet, _ = husk.process(x, SR, p, verbose=False)

items = [x, h, b_fix, b_fol, fld, wet]
segs = []
for i, v in enumerate(items):
    segs += [tick(i + 1), norm(v), gap()]
sf.write(f"{OUT}/m_proof.wav", np.concatenate(segs, 0), SR)
print("готово")
