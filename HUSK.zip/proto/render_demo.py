import numpy as np, soundfile as sf, os, sys
import husk
from husk import Params

OUT = "/home/claude/husk/render"
SR = 48000


def norm(y, target=0.13):
    y = np.asarray(y, dtype=np.float64)
    r = np.sqrt(np.mean(y ** 2)) + 1e-12
    y = y * (target / r)
    # мягкий лимитер вместо пикового деления — уровни остаются сопоставимыми
    y = np.tanh(y * 1.05) / np.tanh(1.05) * 0.94
    p = np.max(np.abs(y))
    if p > 0.99:
        y *= 0.99 / p
    return y.astype(np.float32)


PRESETS = {
    # 1. Деликатно: только тело инструмента, шелуха слегка подсвечивает
    "01_breath": Params(split=0.62, cross=0.0, husk_gain=1.0,
                        body=0.18, body_decay=1.1, body_modes=16, body_t60min=0.10,
                        body_tilt=1.2, body_bright=0.45,
                        body_position=0.24, body_amt=1.0,
                        field_amt=0.22, field_decay=2.2, field_damp=0.18, drift=0.2,
                        air_amt=0.22, air_size=0.7, air_feedback=0.72, air_damp=0.6,
                        air_drive=0.0, mix=0.34),

    # 2. Симпатическое поле: гитара «раскачивает» невидимые струны в тональности
    "02_field": Params(split=0.25, cross=0.0,
                       body=0.30, body_decay=1.6, body_modes=14, body_t60min=0.10,
                       body_tilt=1.2, body_bright=0.5, body_amt=0.35,
                       field_amt=1.0, field_decay=6.0, field_damp=0.20,
                       field_strings=12, drift=0.45,
                       air_amt=0.3, air_size=1.0, air_feedback=0.8, air_damp=0.5,
                       air_drive=0.05, mix=0.5),

    # 3. Инверсия: шелуха играет большое тело, тон уходит в струны
    "03_inversion": Params(split=0.5, cross=1.0, husk_gain=1.6,
                           body=0.72, body_decay=3.2, body_modes=22, body_t60min=0.09,
                           body_tilt=1.0, body_bright=0.6,
                           body_position=0.17, body_amt=1.0,
                           field_amt=0.55, field_decay=5.0, field_damp=0.3, drift=0.6,
                           air_amt=0.42, air_size=1.3, air_feedback=0.86, air_damp=0.42,
                           air_drive=0.2, mix=0.62),

    # 4. Пластина: странный неорганический объект, но возбуждаемый органикой
    "04_plate": Params(split=0.8, cross=0.0, husk_gain=1.4,
                       body=1.0, body_decay=4.5, body_modes=26, body_t60min=0.10,
                       body_tilt=0.9, body_bright=0.68,
                       body_position=0.11, body_amt=1.0, body_follow=0.0,
                       body_tune=98.0,
                       field_amt=0.3, field_decay=4.0, field_damp=0.25, drift=0.5,
                       air_amt=0.5, air_size=1.6, air_feedback=0.88, air_damp=0.35,
                       air_drive=0.25, mix=0.6),

    # 5. Полный расцвет: длинные хвосты, самоподдерживающийся воздух
    "05_bloom": Params(split=0.45, cross=0.35,
                       body=0.45, body_decay=6.0, body_modes=20, body_t60min=0.12,
                       body_tilt=1.0, body_bright=0.58, body_amt=0.85,
                       field_amt=0.9, field_decay=9.0, field_damp=0.16,
                       field_strings=12, drift=0.7,
                       air_amt=0.62, air_size=2.0, air_feedback=0.93, air_damp=0.3,
                       air_drive=0.3, mix=0.72),
}


def main():
    srcs = {}
    for n in ("fingerstyle", "picked", "chords"):
        y, sr = sf.read(f"{OUT}/src_{n}.wav")
        srcs[n] = y

    # A. слои разбора — самое важное для понимания идеи
    x = srcs["fingerstyle"]
    _, info = husk.process(x, SR, Params(mix=0.0), verbose=True)
    sf.write(f"{OUT}/A1_input.wav", norm(x, 0.14), SR)
    sf.write(f"{OUT}/A2_core.wav", norm(info["core"], 0.14), SR)
    sf.write(f"{OUT}/A3_husk.wav", norm(info["husk"], 0.14), SR)
    print("  слои записаны")

    # B. пресеты на разных источниках
    for src_name in ("fingerstyle", "picked", "chords"):
        for pname, prm in PRESETS.items():
            y, _ = husk.process(srcs[src_name], SR, prm, verbose=False)
            sf.write(f"{OUT}/B_{src_name}__{pname}.wav", norm(y), SR)
            print(f"  {src_name:11s} {pname}")

    # C. сухой референс для сравнения (та же громкость)
    for src_name in ("fingerstyle", "picked", "chords"):
        sf.write(f"{OUT}/B_{src_name}__00_dry.wav", norm(srcs[src_name]), SR)


if __name__ == "__main__":
    main()
