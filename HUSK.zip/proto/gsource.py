"""
Тестовый источник: физмодель акустической/электро гитары.
Extended Karplus-Strong: возбуждение (щипок медиатором / пальцем) -> петля струны
с однополюсным демпфированием и аллпасс-дисперсией -> модальное тело инструмента.

Задача — получить сигнал с честным шумовым слоем (атака медиатора, скрип пальцев,
дыхание корпуса), потому что именно на нём строится эффект HUSK.
"""
import numpy as np
from numba import njit

SR = 48000


# ----------------------------------------------------------------------------- струна
@njit(cache=True)
def _string(exc, f0, sr, decay_lo, decay_hi, dispersion, out_len):
    L = sr / f0
    Li = int(L)
    frac = L - Li
    if Li < 4:
        Li = 4
    buf = np.zeros(Li + 8, dtype=np.float64)
    wp = 0

    # однополюсный loop-фильтр: g*(1+a)/(1+a z^-1)
    # decay_lo -> T60 на f0, decay_hi -> T60 на ~5 кГц
    g = 10.0 ** (-3.0 * L / (sr * decay_lo))
    ratio = decay_hi / decay_lo
    # a подбираем так, чтобы верх умирал в ratio раз быстрее
    a = -(1.0 - ratio) / (1.0 + ratio) * 0.9
    if a < -0.9:
        a = -0.9
    lp_z = 0.0

    # аллпасс дробной задержки
    c = (1.0 - frac) / (1.0 + frac)
    ap_z = 0.0
    # аллпасс дисперсии (инхармоничность стальной струны)
    dg = -0.618 * dispersion / (0.15 + abs(dispersion))
    dz = 0.0

    out = np.zeros(out_len, dtype=np.float64)
    n_exc = len(exc)
    dc_x = 0.0
    dc_y = 0.0

    for n in range(out_len):
        rp = wp - Li
        if rp < 0:
            rp += Li + 8
        s = buf[rp]

        # дробная задержка (allpass)
        y_ap = c * (s - ap_z) + ap_z
        ap_z = s
        s = y_ap

        # дисперсия
        y_d = dg * (s - dz) + dz
        dz = s
        s = y_d

        # потери
        lp = g * (1.0 + a) * s - a * lp_z
        lp_z = lp

        # DC blocker внутри петли
        dc_y = lp - dc_x + 0.9995 * dc_y
        dc_x = lp
        v = dc_y

        if n < n_exc:
            v += exc[n]

        buf[wp] = v
        wp += 1
        if wp >= Li + 8:
            wp = 0
        out[n] = s
    return out


def pluck_excitation(sr, f0, hardness, position, level, pick_noise):
    """Возбуждение: короткий шумовой всплеск, отфильтрованный, + гребёнка позиции."""
    dur = 0.006 + 0.010 * (1.0 - hardness)
    n = int(dur * sr)
    rng = np.random.default_rng()
    e = rng.standard_normal(n)
    # окно
    w = np.hanning(n)
    e *= w
    # мягкость: чем мягче палец, тем больше НЧ
    b = np.exp(-np.arange(n) / (n * (0.25 + 0.5 * (1 - hardness))))
    e = e * b
    # низкочастотный "толчок" (тело щипка)
    t = np.arange(n) / sr
    body = np.sin(np.pi * np.arange(n) / n) ** 2
    e = 0.35 * e + 0.65 * body * (0.6 + 0.4 * hardness)

    # гребёнка позиции щипка: y = x - x[n - L*pos]
    L = sr / f0
    d = int(L * position)
    if d > 0:
        pad = np.zeros(len(e) + d)
        pad[: len(e)] = e
        pad[d:] += -0.85 * e
        e = pad

    # отдельный «щёлк» медиатора — широкополосный, очень короткий
    if pick_noise > 0:
        nc = int(0.0018 * sr)
        click = rng.standard_normal(nc) * np.exp(-np.arange(nc) / (nc * 0.28))
        click *= pick_noise * hardness
        e[:nc] += click[: min(nc, len(e))]

    return e * level


@njit(cache=True)
def _modal_body(x, freqs, t60s, gains, sr):
    """Модальный резонатор корпуса: комплексные однополюсники."""
    n = len(x)
    m = len(freqs)
    out = np.zeros(n)
    re = np.zeros(m)
    im = np.zeros(m)
    pr = np.zeros(m)
    pi = np.zeros(m)
    for k in range(m):
        w = 2.0 * np.pi * freqs[k] / sr
        R = 10.0 ** (-3.0 / (sr * t60s[k]))
        pr[k] = R * np.cos(w)
        pi[k] = R * np.sin(w)
    for i in range(n):
        acc = 0.0
        xi = x[i]
        for k in range(m):
            nr = xi + pr[k] * re[k] - pi[k] * im[k]
            ni = pr[k] * im[k] + pi[k] * re[k]
            re[k] = nr
            im[k] = ni
            acc += gains[k] * ni
        out[i] = acc
    return out


BODY_MODES = np.array([96.0, 172.0, 214.0, 289.0, 386.0, 460.0, 612.0, 780.0,
                       934.0, 1180.0, 1490.0, 2110.0])
BODY_T60 = np.array([0.28, 0.20, 0.17, 0.14, 0.12, 0.10, 0.085, 0.07,
                     0.06, 0.05, 0.04, 0.03])
BODY_GAIN = np.array([1.0, 0.78, 0.62, 0.5, 0.42, 0.35, 0.28, 0.22,
                      0.18, 0.13, 0.09, 0.05])


def finger_squeak(sr, dur=0.09, level=0.02):
    n = int(dur * sr)
    rng = np.random.default_rng()
    x = rng.standard_normal(n)
    # узкополосный шум ~2-4 кГц с глиссандо
    from scipy.signal import butter, lfilter
    b, a = butter(2, [1800 / (sr / 2), 4200 / (sr / 2)], btype="band")
    x = lfilter(b, a, x)
    env = np.hanning(n) ** 2
    return x * env * level


def render_performance(notes, sr=SR, tail=3.0, seed=7):
    """notes: список (t_start, midi, velocity, hardness, position, squeak_before)"""
    np.random.seed(seed)
    total = int((max(n[0] for n in notes) + tail) * sr)
    strings = np.zeros(total)
    for (t, midi, vel, hard, pos, sq) in notes:
        f0 = 440.0 * 2 ** ((midi - 69) / 12.0)
        start = int(t * sr)
        seg_len = total - start
        if seg_len <= 100:
            continue
        exc = pluck_excitation(sr, f0, hard, pos, vel, pick_noise=0.9 * hard)
        decay_lo = 3.4 + 2.0 * (1 - hard)
        decay_hi = decay_lo * (0.10 + 0.10 * hard)
        s = _string(exc, f0, sr, decay_lo, decay_hi, 0.22, seg_len)
        strings[start:] += s
        if sq > 0:
            sq_sig = finger_squeak(sr, level=sq)
            st = max(0, start - len(sq_sig) - int(0.01 * sr))
            strings[st: st + len(sq_sig)] += sq_sig

    strings *= 0.25
    body = _modal_body(strings, BODY_MODES, BODY_T60, BODY_GAIN, sr)
    y = 0.62 * strings + 0.38 * body / (np.max(np.abs(body)) + 1e-12) * (
        np.max(np.abs(strings)) + 1e-12)
    # немного воздуха/шума комнаты
    y += np.random.default_rng(seed).standard_normal(total) * 2e-4
    y /= (np.max(np.abs(y)) + 1e-9)
    return (y * 0.55).astype(np.float32)


def perf_fingerstyle():
    """Медленное арпеджио Dadd9 -> Bm11, пальцами, мягко."""
    notes = []
    seq = [
        (0.00, 50, 0.9, 0.22, 0.14, 0.0),   # D2
        (0.42, 62, 0.7, 0.20, 0.16, 0.010),  # D3
        (0.84, 69, 0.6, 0.18, 0.18, 0.0),   # A3
        (1.26, 76, 0.55, 0.16, 0.20, 0.008),  # E4
        (1.68, 74, 0.5, 0.16, 0.20, 0.0),   # D4
        (2.20, 47, 0.85, 0.24, 0.14, 0.014),  # B1
        (2.62, 59, 0.65, 0.20, 0.16, 0.0),   # B2
        (3.04, 66, 0.6, 0.18, 0.18, 0.009),  # F#3
        (3.46, 74, 0.5, 0.16, 0.20, 0.0),   # D4
        (3.88, 78, 0.45, 0.15, 0.22, 0.007),  # F#4
        (4.60, 50, 0.9, 0.22, 0.14, 0.012),
        (5.02, 62, 0.7, 0.20, 0.16, 0.0),
        (5.44, 69, 0.6, 0.18, 0.18, 0.0),
        (5.86, 76, 0.5, 0.16, 0.20, 0.008),
    ]
    notes.extend(seq)
    return render_performance(notes, tail=4.5)


def perf_picked():
    """Медиатор, ближе к подставке, жёстче — много шумовой атаки."""
    notes = []
    t = 0.0
    pattern = [52, 64, 71, 59, 67, 76, 64, 71]
    for i in range(16):
        m = pattern[i % len(pattern)] + (0 if i < 8 else -3)
        notes.append((t, m, 0.75 + 0.2 * ((i % 3) == 0), 0.85, 0.09,
                      0.006 if i % 4 == 0 else 0.0))
        t += 0.31
    return render_performance(notes, tail=4.0)


def perf_chords():
    """Два медленных аккорда, широко — для проверки хвостов."""
    notes = []
    for i, m in enumerate([40, 47, 52, 56, 59, 64]):
        notes.append((0.0 + i * 0.022, m, 0.8, 0.45, 0.12, 0.0))
    for i, m in enumerate([45, 52, 57, 60, 64, 69]):
        notes.append((3.2 + i * 0.025, m, 0.75, 0.4, 0.12, 0.012 if i == 0 else 0.0))
    return render_performance(notes, tail=5.5)
