#!/usr/bin/env python3
"""
Автопроверка раскладки интерфейса.

Смещение в два пикселя глазами видно, но непонятно, что именно съехало.
`husk_shot` выгружает точную геометрию всех элементов в JSON, а этот скрипт
проверяет инварианты сетки и печатает расхождения в пикселях.

  ./build/husk_shot_artefacts/Release/husk_shot render/ui.png 16
  python3 tools/layout_audit.py render/ui.json
"""
import json, sys, itertools
from collections import defaultdict

CAPTION_H = 16          # Knob::kCaptionH
GROUP_HDR_TOP = 14      # заголовок подгруппы рисуется на area.y - 14
PANEL_TITLE_BOT = 18    # полоса заголовка панели: y+6 .. y+18


def load(path):
    items = json.load(open(path, encoding="utf-8"))
    return {i["name"]: i for i in items}, items


def rect(i):
    return i["x"], i["y"], i["x"] + i["w"], i["y"] + i["h"]


def inside(c, p):
    """Принадлежность по центру: панели перекрываются по X (ROUTING и AIR шире
    половинок), поэтому проверять только диапазон X нельзя."""
    cx, cy = c["x"] + c["w"] / 2, c["y"] + c["h"] / 2
    return p["x"] <= cx <= p["x"] + p["w"] and p["y"] <= cy <= p["y"] + p["h"]


def overlap(a, b):
    ax0, ay0, ax1, ay1 = rect(a)
    bx0, by0, bx1, by1 = rect(b)
    ix = min(ax1, bx1) - max(ax0, bx0)
    iy = min(ay1, by1) - max(ay0, by0)
    return (ix, iy) if ix > 0 and iy > 0 else None


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "render/ui_new.json"
    by, items = load(path)
    win = by["window"]
    panels = {k: v for k, v in by.items() if k.startswith("panel:")}
    groups = {k: v for k, v in by.items() if k.startswith("group:")}
    ctrls = {k: v for k, v in by.items()
             if k.split(":")[0] in ("knob", "strip", "view", "slider", "combo", "button")}

    problems = []

    # ---- 1. поля панелей
    print(f"{'панель':<16}{'верх':>6}{'низ':>6}{'слева':>7}{'справа':>8}")
    pads = {}
    for pname, p in sorted(panels.items()):
        px0, py0, px1, py1 = rect(p)
        within = [c for n, c in ctrls.items() if inside(c, p)]
        if not within:
            continue
        # мастер-ручка центрируется в своей колонке, её левый край шире отступа
        edge = [c for n, c in ctrls.items()
                if inside(c, p) and not n.startswith("knob:LEVEL")]
        top = min(c["y"] for c in within) - py0
        bot = py1 - max(c["y"] + c["h"] for c in within)
        left = min(c["x"] for c in (edge or within)) - px0
        rightp = px1 - max(c["x"] + c["w"] for c in within)
        pads[pname] = (top, bot, left, rightp)
        print(f"{pname.split(':')[1]:<16}{top:>6}{bot:>6}{left:>7}{rightp:>8}")

    # левое поле у панели без визуализатора задаёт мастер-колонка, поэтому
    # сравнивать «минимальный x» бессмысленно — проверяем сами колонки
    def offsets(pred):
        out = {}
        for pname, p in panels.items():
            xs = [c["x"] - p["x"] for n, c in ctrls.items() if inside(c, p) and pred(n)]
            if xs:
                out[pname.split(":")[1]] = min(xs)
        return out

    for label, pred in (("мастер-колонка", lambda n: n.startswith("knob:LEVEL")),):
        vals = offsets(pred)
        if len(set(vals.values())) > 1:
            problems.append(f"{label} на разных отступах: {vals}")
    # сравниваем первую подгруппу каждой панели: вторая (TAIL) стоит дальше по ряду
    firstGroup = {}
    for pname, p in panels.items():
        xs = [g["x"] - p["x"] for g in groups.values() if inside(g, p)]
        if xs:
            firstGroup[pname.split(":")[1]] = min(xs)
    if len(set(firstGroup.values())) > 1:
        problems.append(f"подгруппы начинаются на разных отступах: {firstGroup}")

    for idx, label in ((1, "нижнее поле"), (3, "правое поле")):
        vals = {k: v[idx] for k, v in pads.items()}
        if len(set(vals.values())) > 1:
            problems.append(f"{label} панелей не совпадает: " +
                            ", ".join(f"{k.split(':')[1]}={v}" for k, v in vals.items()))

    # ---- 2. ряды: одинаковая высота и y
    rows = defaultdict(list)
    for name, c in ctrls.items():
        if name.split(":")[0] in ("knob", "strip"):
            rows[(c["y"], c["h"])].append(name)
    ys = defaultdict(list)
    for (y, h), names in rows.items():
        ys[y].append((h, names))
    for y, entries in sorted(ys.items()):
        if len({h for h, _ in entries}) > 1:
            problems.append(f"ряд y={y}: разная высота элементов " +
                            str({h: n for h, n in entries}))

    # ---- 3. пересечения
    names = list(ctrls)
    for a, b in itertools.combinations(names, 2):
        ov = overlap(ctrls[a], ctrls[b])
        if ov:
            problems.append(f"перекрытие {a} и {b}: {ov[0]}×{ov[1]} px")

    # ---- 4. заголовки подгрупп: нужен свободный воздух сверху
    for gname, g in sorted(groups.items()):
        band = {"x": g["x"], "y": g["y"] - GROUP_HDR_TOP, "w": 160, "h": 11}
        for cname, c in ctrls.items():
            if c is g:
                continue
            ov = overlap(band, c)
            if ov:
                problems.append(f"заголовок {gname} наезжает на {cname}: "
                                f"{ov[0]}×{ov[1]} px")
        for pname, p in panels.items():
            if inside(g, p):
                titleBot = p["y"] + PANEL_TITLE_BOT
                if band["y"] < titleBot:
                    problems.append(f"заголовок {gname} налезает на заголовок {pname} "
                                    f"({titleBot - band['y']} px)")

    # ---- 5. всё внутри своих панелей и окна
    for cname, c in ctrls.items():
        x0, y0, x1, y1 = rect(c)
        if x0 < 0 or y0 < 0 or x1 > win["w"] or y1 > win["h"]:
            problems.append(f"{cname} выходит за окно")

    # ---- 6. симметрия BODY / FIELD
    b, f = by.get("panel:BODY"), by.get("panel:FIELD")
    if b and f:
        if (b["y"], b["h"], b["w"]) != (f["y"], f["h"], f["w"]):
            problems.append("BODY и FIELD разного размера или на разной высоте")
        bl = by.get("knob:LEVEL:bodyamt")
        fl = by.get("knob:LEVEL:fieldamt")
        if bl and fl and bl["y"] != fl["y"]:
            problems.append(f"мастер-ручки BODY и FIELD на разной высоте: "
                            f"{bl['y']} против {fl['y']} ({abs(bl['y'] - fl['y'])} px)")

    # ---- 7. зазоры внутри ряда, отдельно по каждой панели: ряды соседних
    #         панелей стоят на одной высоте, и мерить их вместе бессмысленно
    for pname, p in sorted(panels.items()):
        px0, _, px1, _ = rect(p)
        for y, entries in sorted(ys.items()):
            row = sorted((ctrls[n] for _, names in entries for n in names
                          if inside(ctrls[n], p)), key=lambda c: c["x"])
            if len(row) < 3:
                continue
            gaps = [row[i + 1]["x"] - (row[i]["x"] + row[i]["w"]) for i in range(len(row) - 1)]
            inner = [g for g in gaps if g < 30]     # внутри подгруппы
            if len(set(inner)) > 1:
                problems.append(f"{pname}, ряд y={y}: неравные зазоры {inner}")

    print()
    if problems:
        for i, p in enumerate(problems, 1):
            print(f"{i:>2}. {p}")
    else:
        print("расхождений не найдено")
    print(f"\nвсего замечаний: {len(problems)}")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
