#!/usr/bin/env python3
"""
Аудит заводского банка HUSK.

Пресеты нельзя отбирать «на глаз» — их слишком легко сделать почти одинаковыми.
Скрипт рендерит весь банк через C++ движок на нескольких источниках и меряет:

  LUFS-I   интегральная громкость (ITU-R BS.1770 K-weighting) — для выравнивания
  centroid спектральный центроид, Гц — «яркость»
  tail     время падения на 40 dB после последней ноты, с — длина хвоста
  flat     спектральная плоскостность — тональность против шума
  width    1 − корреляция каналов — стереоширина
  wetness  отличие от сухого сигнала — насколько эффект вообще заметен

Дальше считается матрица расстояний между пресетами в нормированном
пространстве этих признаков и печатаются пары, которые слишком похожи.

  python3 tools/preset_audit.py            # аудит
  python3 tools/preset_audit.py --calibrate  # плюс предложенные outputDb
"""
import subprocess, sys, os, itertools, json
import numpy as np
import soundfile as sf
from scipy.signal import bilinear, lfilter, welch

ROOT = os.path.dirname (os.path.dirname (os.path.abspath (__file__)))
BIN = os.path.join (ROOT, "build", "husk_offline")
SRC = os.path.join (ROOT, "render")
TMP = "/tmp/husk_audit"
TARGET_LUFS = -20.0
SOURCES = ["fingerstyle", "picked", "chords"]


# ---------------------------------------------------------------- K-weighting
def k_filters(sr):
    """Два звена по BS.1770-4: shelf на голову + ФВЧ."""
    # high-shelf (стадия 1)
    f0, G, Q = 1681.974450955533, 3.999843853973347, 0.7071752369554196
    K = np.tan(np.pi * f0 / sr)
    Vh = 10 ** (G / 20.0); Vb = Vh ** 0.4996667741545416
    a0 = 1.0 + K / Q + K * K
    b = np.array([(Vh + Vb * K / Q + K * K), 2 * (K * K - Vh), (Vh - Vb * K / Q + K * K)]) / a0
    a = np.array([1.0, 2 * (K * K - 1) / a0, (1 - K / Q + K * K) / a0])
    # high-pass (стадия 2)
    f0b, Qb = 38.13547087602444, 0.5003270373238773
    Kb = np.tan(np.pi * f0b / sr)
    b2 = np.array([1.0, -2.0, 1.0])
    a2 = np.array([1.0,
                   2 * (Kb * Kb - 1) / (1 + Kb / Qb + Kb * Kb),
                   (1 - Kb / Qb + Kb * Kb) / (1 + Kb / Qb + Kb * Kb)])
    return (b, a), (b2, a2)


def lufs(y, sr):
    """Интегральная громкость с гейтингом по BS.1770 (упрощённо, без relative gate 2)."""
    if y.ndim == 1:
        y = y[:, None]
    (b1, a1), (b2, a2) = k_filters(sr)
    z = np.stack([lfilter(b2, a2, lfilter(b1, a1, y[:, c])) for c in range(y.shape[1])], 1)
    win = int(0.4 * sr); hop = int(0.1 * sr)
    if len(z) < win:
        return -70.0
    blocks = []
    for i in range(0, len(z) - win, hop):
        seg = z[i:i + win]
        ms = (seg ** 2).mean(0).sum()
        blocks.append(-0.691 + 10 * np.log10(ms + 1e-20))
    blocks = np.array(blocks)
    gated = blocks[blocks > -70.0]
    if len(gated) == 0:
        return -70.0
    rel = 10 * np.log10(np.mean(10 ** (gated / 10))) - 10.0
    gated = gated[gated > rel]
    if len(gated) == 0:
        return -70.0
    return float(10 * np.log10(np.mean(10 ** (gated / 10))))


# --------------------------------------------------------------------- метрики
def measure(y, sr, dry):
    m = y.mean(1) if y.ndim > 1 else y
    f, P = welch(m, sr, nperseg=8192)
    P = P / (P.sum() + 1e-30)
    centroid = float((f * P).sum())
    flat = float(np.exp(np.mean(np.log(P + 1e-20))) / (np.mean(P) + 1e-30))

    # хвост: от последнего момента, когда огибающая выше −20 dB от пика,
    # до падения ещё на 40 dB
    env = np.abs(m)
    k = int(0.02 * sr)
    env = np.convolve(env, np.ones(k) / k, mode="same")
    pk = env.max() + 1e-20
    above = np.where(env > pk * 10 ** (-20 / 20))[0]
    tail = 0.0
    if len(above):
        i0 = above[-1]
        thr = env[i0] * 10 ** (-40 / 20)
        after = np.where(env[i0:] < thr)[0]
        tail = float(after[0] / sr) if len(after) else float((len(env) - i0) / sr)

    if y.ndim > 1 and y.shape[1] == 2:
        a, b = y[:, 0], y[:, 1]
        c = float(np.corrcoef(a, b)[0, 1]) if a.std() > 0 and b.std() > 0 else 1.0
        width = 1.0 - max(-1.0, min(1.0, c))
    else:
        width = 0.0

    n = min(len(m), len(dry))
    d, w = dry[:n], m[:n]
    d = d / (np.sqrt((d ** 2).mean()) + 1e-12)
    w = w / (np.sqrt((w ** 2).mean()) + 1e-12)
    wetness = float(np.sqrt(((w - d) ** 2).mean()) / np.sqrt(2))

    return dict(centroid=centroid, flat=flat, tail=tail, width=width,
                wetness=wetness, lufs=lufs(y, sr))


# ------------------------------------------------------------------------ run
def presets():
    out = subprocess.run([BIN, "--list-tsv"], capture_output=True, text=True).stdout
    rows = []
    for line in out.strip().split("\n"):
        idx, cat, name = line.split("\t")
        rows.append((int(idx), cat, name))
    return rows


HDR = os.path.join(ROOT, "Source", "Presets.h")
BEGIN = "// BEGIN GENERATED TRIMS"
END = "// END GENERATED TRIMS"


def read_trims(n):
    s = open(HDR, encoding="utf-8").read()
    body = s[s.index(BEGIN):s.index(END)]
    vals = [float(x) for x in __import__("re").findall(r"(-?\d+\.\d+)f", body)]
    vals = (vals + [0.0] * n)[:n]
    return vals


def write_trims(residual):
    n = len(residual)
    cur = read_trims(n)
    new = [round(c + r, 1) for c, r in zip(cur, residual)]
    rows = ",\n        ".join(f"{v:>6.1f}f" for v in new)
    block = (BEGIN + "\ninline const float* presetTrimDb (int& count) noexcept\n{\n"
             "    static const float t[] = {\n        " + rows + "\n    };\n"
             "    count = (int) (sizeof (t) / sizeof (t[0]));\n    return t;\n}\n")
    s = open(HDR, encoding="utf-8").read()
    s = s[:s.index(BEGIN)] + block + s[s.index(END):]
    open(HDR, "w", encoding="utf-8").write(s)


def main():
    calibrate = "--calibrate" in sys.argv
    os.makedirs(TMP, exist_ok=True)
    rows = presets()

    dry, dryL = {}, {}
    for s in SOURCES:
        y, sr = sf.read(f"{SRC}/src_{s}.wav")
        dry[s] = (y.mean(1) if y.ndim > 1 else y)
        dryL[s] = lufs(y, sr)

    feats, table = {}, []
    for idx, cat, name in rows:
        acc = []
        for s in SOURCES:
            # характер меряем по чистому wet, громкость — по реальному пресету
            wetf = f"{TMP}/{idx}_{s}_wet.wav"
            mixf = f"{TMP}/{idx}_{s}.wav"
            subprocess.run([BIN, f"{SRC}/src_{s}.wav", wetf, str(idx), "--wet"],
                           capture_output=True)
            subprocess.run([BIN, f"{SRC}/src_{s}.wav", mixf, str(idx)],
                           capture_output=True)
            yw, sr = sf.read(wetf)
            ym, _ = sf.read(mixf)
            m = measure(yw, sr, dry[s])
            m["lufs"] = lufs(ym, sr)
            m["delta"] = dryL[s] - m["lufs"]      # на сколько поднять, чтобы совпасть с сухим
            acc.append(m)
        avg = {k: float(np.mean([a[k] for a in acc])) for k in acc[0]}
        feats[idx] = avg
        table.append((idx, cat, name, avg))

    print(f"{'#':>2}  {'категория':<10} {'имя':<18} {'LUFS':>7} {'dB':>6} {'центр,Гц':>9} "
          f"{'хвост,с':>8} {'flat':>7} {'ширина':>7} {'wet':>6}")
    print("-" * 96)
    for idx, cat, name, a in table:
        print(f"{idx:>2}  {cat:<10} {name:<18} {a['lufs']:>7.1f} {a['delta']:>+6.1f} {a['centroid']:>9.0f} "
              f"{a['tail']:>8.2f} {a['flat']:>7.4f} {a['width']:>7.3f} {a['wetness']:>6.2f}")

    # ---- проверки
    print("\nЗамечания:")
    problems = 0
    for idx, cat, name, a in table:
        if a["flat"] > 0.06:
            print(f"  [{idx}] {name}: шумновато (flat {a['flat']:.3f})"); problems += 1
        if a["wetness"] < 0.25 and cat != "Delicate" and cat != "Utility":
            print(f"  [{idx}] {name}: эффект почти не слышен (wet {a['wetness']:.2f})"); problems += 1
        if a["tail"] > 25.0:
            print(f"  [{idx}] {name}: хвост {a['tail']:.1f} с — длиннее заявленного tail time"); problems += 1

    # ---- похожесть
    keys = ["centroid", "tail", "flat", "width", "wetness"]
    M = np.array([[feats[i][k] for k in keys] for i, _, _, _ in table], float)
    M[:, 0] = np.log10(M[:, 0] + 1)
    M[:, 1] = np.log10(M[:, 1] + 0.05)
    M[:, 2] = np.log10(M[:, 2] + 1e-4)
    M = (M - M.mean(0)) / (M.std(0) + 1e-12)
    print()
    near = []
    for i, j in itertools.combinations(range(len(table)), 2):
        d = float(np.linalg.norm(M[i] - M[j]))
        if d < 0.75:
            near.append((d, table[i][2], table[j][2]))
    if near:
        for d, a, b in sorted(near):
            print(f"  похожи (d={d:.2f}): {a}  ~  {b}")
            problems += 1
    else:
        print("  все пресеты различимы по измеряемым признакам")

    if "--write" in sys.argv:
        write_trims([feats[i]["delta"] for i, _, _, _ in table])
        print("\nтримы записаны в Source/Presets.h — пересобери и прогони аудит ещё раз")

    if calibrate:
        print("\nПредложенные outputDb (совпасть по громкости с сухим сигналом):")
        for idx, cat, name, a in table:
            print(f"  {idx:>2} {name:<18} {a['delta']:+.1f}")
        json.dump({str(i): round(feats[i]["delta"], 1) for i, _, _, _ in table},
                  open(f"{TMP}/gains.json", "w"))

    # ---- устойчивость: горячий вход, поиск разгона
    print("\nУстойчивость (10 с белого шума 0 dBFS):")
    hot = f"{TMP}/hot.wav"
    if not os.path.exists(hot):
        rng = np.random.default_rng(5)
        sf.write(hot, (rng.standard_normal(48000 * 10) * 0.9).astype(np.float32), 48000)
    bad = 0
    for idx, cat, name, a in table:
        o = f"{TMP}/hot_{idx}.wav"
        subprocess.run([BIN, hot, o, str(idx)], capture_output=True)
        y, sr = sf.read(o)
        m = y.mean(1) if y.ndim > 1 else y
        if not np.all(np.isfinite(m)):
            print(f"  [{idx}] {name}: NaN/Inf"); bad += 1; continue
        if np.max(np.abs(m)) > 1.001:
            print(f"  [{idx}] {name}: пик {np.max(np.abs(m)):.3f} > 1"); bad += 1
        # разгон: энергия последней секунды против пятой
        e5 = np.sqrt((m[4 * sr:5 * sr] ** 2).mean()) + 1e-12
        e10 = np.sqrt((m[-sr:] ** 2).mean()) + 1e-12
        if 20 * np.log10(e10 / e5) > 3.0:
            print(f"  [{idx}] {name}: рост {20 * np.log10(e10 / e5):+.1f} dB за 5 с — разгоняется")
            bad += 1
    if bad == 0:
        print("  весь банк устойчив")
    problems += bad

    print(f"\nвсего замечаний: {problems}")


if __name__ == "__main__":
    main()
