#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include "PluginProcessor.h"
#include <array>
#include <vector>
#include <memory>

// ============================================================================
/** Тёмная органическая тема: тёплый почти чёрный фон, охра как основной акцент,
    холодная бирюза как второй. Цвет здесь несёт смысл, а не украшает —
    охра = HUSK и тело, бирюза = CORE и поле. */
namespace hcol
{
    extern const juce::Colour bg, panel, panelHi, line, lineSoft, text, dim, faint;
    extern const juce::Colour warm, warmDim, cool, coolDim;
}

class HuskLookAndFeel : public juce::LookAndFeel_V4
{
public:
    HuskLookAndFeel();
    void drawRotarySlider (juce::Graphics&, int x, int y, int w, int h,
                           float pos, float a0, float a1, juce::Slider&) override;
    void drawLinearSlider (juce::Graphics&, int x, int y, int w, int h,
                           float pos, float minPos, float maxPos,
                           juce::Slider::SliderStyle, juce::Slider&) override;
    void drawComboBox (juce::Graphics&, int w, int h, bool down,
                       int bx, int by, int bw, int bh, juce::ComboBox&) override;
    void drawButtonBackground (juce::Graphics&, juce::Button&, const juce::Colour&,
                               bool over, bool down) override;
    void drawButtonText (juce::Graphics&, juce::TextButton&, bool over, bool down) override;
    juce::Font getComboBoxFont (juce::ComboBox&) override;
    juce::Font getPopupMenuFont() override;
};

// ============================================================================
/** Ручка с подписью, которая превращается в значение, когда на неё смотрят.
    Постоянно висящие числа под каждым регулятором — главный источник визуального
    шума; здесь значение появляется при наведении и перетаскивании. */
class Knob : public juce::Component
{
public:
    static constexpr int kCaptionH = 16;   // общая для Knob и Strip полоса подписи

    Knob (juce::AudioProcessorValueTreeState&, const juce::String& paramID,
          const juce::String& caption, bool large, juce::Colour accent);

    void paint (juce::Graphics&) override;
    void resized() override;

    juce::Slider slider;

private:
    void mouseEnter (const juce::MouseEvent&) override { hover = true;  repaint(); }
    void mouseExit  (const juce::MouseEvent&) override { hover = false; repaint(); }

    juce::String caption;
    bool big;
    juce::Colour accent;
    bool hover = false;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> att;
};

// ============================================================================
/** Регулятор, который выглядит как то, чем управляет.

    Ряд из пяти одинаковых кружков не сообщает ничего: чтобы понять, что делает
    ручка, приходится читать подпись. Здесь у четырёх параметров, у которых есть
    внятный физический смысл, своя графика — форма объекта, плотность мод, точка
    щипка, количество струн. Мышью управляет обычный juce::Slider под капотом,
    так что автоматизация, шаги и правый клик работают как везде. */
class Strip : public juce::Component
{
public:
    static constexpr int kCaptionH = Knob::kCaptionH;

    enum class Kind { Morph, Density, Pluck, Steps };

    Strip (juce::AudioProcessorValueTreeState&, const juce::String& paramID,
           const juce::String& caption, Kind, juce::Colour accent);
    ~Strip() override;

    void paint (juce::Graphics&) override;
    void resized() override;

    juce::Slider slider;

private:
    class StripLnf;
    void mouseEnter (const juce::MouseEvent&) override { hover = true;  repaint(); }
    void mouseExit  (const juce::MouseEvent&) override { hover = false; repaint(); }

    juce::String caption;
    Kind kind;
    juce::Colour accent;
    bool hover = false;
    std::unique_ptr<StripLnf> lnf;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> att;
};

// ============================================================================
/** Схема маршрутизации: куда на самом деле уходят слои при текущих SPLIT и
    CROSS. Толщина и яркость лент равны весам смешивания, которые считает
    движок. Без этого CROSS невозможно понять, не читая мануал. */
class RouterView : public juce::Component
{
public:
    void setState (float split, float cross, float huskLvl, float coreLvl) noexcept;
    /** Центры рядов в локальных координатах: чипы должны стоять ровно на
        линиях слайдеров SPLIT и CROSS, иначе схема живёт своей жизнью. */
    void setRowCentres (float topRow, float bottomRow) noexcept;
    void paint (juce::Graphics&) override;

private:
    float split = 0.5f, cross = 0.0f, husk = 0.0f, core = 0.0f;
    float rowTop = 20.0f, rowBottom = 64.0f;
};

/** Спектр мод тела: где стоят резонаторы и какой у них вес. */
class ModeView : public juce::Component
{
public:
    void setModes (const float* hz, const float* amp, int n, float f0, float level) noexcept;
    void paint (juce::Graphics&) override;

private:
    std::array<float, 64> hz {}, amp {};
    int n = 0;
    float f0 = 110.0f, level = 0.0f;
};

/** Форма хвоста воздуха: T60 считается из SIZE и BLOOM ровно так же, как в FDN
    (g = 10^(−3m/(fs·T60))), вторая кривая — затухание верха от DAMP. Показывает
    в секундах то, что иначе приходится выяснивать на слух. */
class TailView : public juce::Component
{
public:
    void setTail (float size, float bloom, float damp, float amount, bool frozen) noexcept;
    void paint (juce::Graphics&) override;

private:
    float t60 = 3.0f, t60hf = 1.0f, amt = 0.5f;
    bool frozen = false;
};

/** Симпатические струны: положение по частоте, подсветка по отклику. */
class StringView : public juce::Component
{
public:
    void setStrings (const float* hz, int n, float level, int root, bool minor) noexcept;
    void paint (juce::Graphics&) override;

private:
    std::array<float, 12> hz {};
    int n = 0, root = 0;
    bool minor = false;
    float level = 0.0f;
};

// ============================================================================
class HuskAudioProcessorEditor : public juce::AudioProcessorEditor,
                                 private juce::Timer
{
public:
    explicit HuskAudioProcessorEditor (HuskAudioProcessor&);
    ~HuskAudioProcessorEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

    /** Выгрузка геометрии для автопроверки раскладки (tools/layout_audit.py).
        Глазами такие вещи ловятся плохо: пара пикселей смещения видна, но не
        понятно, что именно съехало. */
    juce::String dumpLayout() const;

private:
    void timerCallback() override;
    void showPresetMenu();
    void stepPreset (int delta);
    void refreshPresetLabel();

    Knob& addKnob (const juce::String& id, const juce::String& cap,
                   bool large, juce::Colour accent);
    Strip& addStrip (const juce::String& id, const juce::String& cap,
                     Strip::Kind, juce::Colour accent);
    void drawPanel (juce::Graphics&, juce::Rectangle<int>, const juce::String& title,
                    juce::Colour titleColour) const;

    /** Раскладывает элементы заданных ширин по всей ширине span с равными
        зазорами. Ряд, упирающийся в левый край и обрывающийся на середине
        панели, — главная причина ощущения «недособранности». */
    static std::vector<int> spreadRow (int x0, int spanW, const std::vector<int>& widths,
                                       int minGap);

    static constexpr int kW = 1020, kH = 674;

    /** Подгруппа внутри панели: заголовок плюс вертикальная линия слева.
        Панель отвечает за «что это за машина», подгруппа — за «что за набор
        ручек»; без второго уровня десяток регуляторов читается как россыпь. */
    struct Group
    {
        juce::Rectangle<int> area;
        juce::String title;
        bool divider = true;
    };

    juce::Rectangle<int> rRouter, rBody, rField, rAir, rOut;
    std::vector<Group> groups;

    HuskAudioProcessor& proc;
    HuskLookAndFeel lnf;

    juce::OwnedArray<Knob> knobs;
    juce::OwnedArray<Strip> strips;
    juce::Slider splitSlider, crossSlider;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> splitAtt, crossAtt;

    juce::ComboBox tuneBox;
    juce::TextButton freezeBtn { "FREEZE" };
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> tuneAtt;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> freezeAtt;

    juce::TextButton prevBtn { "<" }, nextBtn { ">" }, presetBtn, saveBtn { "SAVE" };
    std::unique_ptr<juce::AlertWindow> saveWindow;

    RouterView router;
    TailView tail;
    ModeView modes;
    StringView strings;

    husk::VisualState vis;
    float outMeter = 0.0f, transientMeter = 0.0f;
    juce::String keyText { "—" }, f0Text { "—" }, presetCat, presetNote;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (HuskAudioProcessorEditor)
};
