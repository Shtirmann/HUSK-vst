#pragma once
#include "dsp/UiParams.h"
#include <vector>
#include <functional>
#include <string>

namespace husk
{

struct Preset
{
    const char* name;
    const char* category;
    const char* note;      // одна строка: что это и когда брать
    UiParams p;
};

inline const float* presetTrimDb (int& count) noexcept;   // определён ниже, генерируется

/** Заводской банк.

    Принцип отбора: каждый пресет должен звучать законченно сразу, без правки, и
    заметно отличаться от соседей. Разнообразие проверяется не на слух, а
    измерением — tools/preset_audit.py считает для каждого спектральный центроид,
    длину хвоста, тональность, стереоширину и громкость и ругается на пары,
    которые слишком похожи.

    Громкость выровнена: outputDb подобран так, чтобы интегральная громкость
    всех пресетов совпадала в пределах 1 dB. Ручку OUT после смены пресета
    трогать не нужно.
*/
inline const std::vector<Preset>& factoryPresets()
{
    static const std::vector<Preset> bank = []
    {
        std::vector<Preset> v;
        auto add = [&v] (const char* name, const char* cat, const char* note,
                         const std::function<void (UiParams&)>& set)
        {
            UiParams u;
            set (u);
            v.push_back ({ name, cat, note, u });
        };

        // ------------------------------------------------------- DELICATE
        // Низкий MIX. Задача — чтобы слушатель не понял, что включён эффект,
        // но выключение было слышно сразу.
        add ("Breath", "Delicate",
             "Дыхание корпуса поверх сухой гитары. Ставится и забывается.",
             [] (UiParams& u) {
                 u.split = 0.62f; u.cross = 0.0f; u.husk = 1.0f;
                 u.bodyshape = 0.12f; u.bodymodes = 16; u.bodydecay = 1.0f;
                 u.bodybright = 0.45f; u.bodypos = 0.26f; u.bodyamt = 1.0f;
                 u.fieldamt = 0.20f; u.fielddecay = 2.0f; u.fielddamp = 0.25f;
                 u.fieldstrings = 8; u.drift = 0.20f;
                 u.airamt = 0.20f; u.airsize = 0.70f; u.airbloom = 0.70f;
                 u.airdamp = 0.60f; u.airdrive = 0.0f;
                 u.mix = 0.30f; });

        add ("Under Glass", "Delicate",
             "Едва слышная пластина под нотами. Хорошо для медленных аккордов.",
             [] (UiParams& u) {
                 u.split = 0.50f; u.husk = 0.9f;
                 u.bodyshape = 0.86f; u.bodymodes = 12; u.bodydecay = 2.2f;
                 u.bodybright = 0.34f; u.bodypos = 0.30f; u.bodyamt = 0.60f;
                 u.fieldamt = 0.30f; u.fielddecay = 3.0f; u.fielddamp = 0.20f;
                 u.fieldstrings = 9; u.drift = 0.35f;
                 u.airamt = 0.30f; u.airsize = 1.20f; u.airbloom = 0.78f;
                 u.airdamp = 0.55f; u.airdrive = 0.03f;
                 u.mix = 0.24f; });

        add ("Nail & Wood", "Delicate",
             "Только шелуха в короткое деревянное тело. Подчёркивает пальцы.",
             [] (UiParams& u) {
                 u.split = 0.88f; u.husk = 1.3f;
                 u.bodyshape = 0.55f; u.bodymodes = 10; u.bodydecay = 0.50f;
                 u.bodybright = 0.62f; u.bodypos = 0.12f; u.bodyamt = 1.0f;
                 u.bodytune = 1;
                 u.fieldamt = 0.12f; u.fielddecay = 1.6f; u.fielddamp = 0.35f;
                 u.fieldstrings = 6; u.drift = 0.15f;
                 u.airamt = 0.16f; u.airsize = 0.55f; u.airbloom = 0.62f;
                 u.airdamp = 0.5f; u.airdrive = 0.0f;
                 u.mix = 0.36f; });

        add ("Second Guitar", "Delicate",
             "Поле, настроенное на твою тональность. Как будто кто-то подыгрывает.",
             [] (UiParams& u) {
                 u.split = 0.18f;
                 u.bodyshape = 0.10f; u.bodymodes = 14; u.bodydecay = 1.4f;
                 u.bodybright = 0.45f; u.bodyamt = 0.22f;
                 u.fieldamt = 1.0f; u.fielddecay = 5.5f; u.fielddamp = 0.16f;
                 u.fieldstrings = 7; u.drift = 0.28f;
                 u.airamt = 0.26f; u.airsize = 0.95f; u.airbloom = 0.76f;
                 u.airdamp = 0.5f; u.airdrive = 0.02f;
                 u.mix = 0.40f; });

        // ---------------------------------------------------------- BODIES
        add ("Steel Body", "Bodies",
             "Стальная струна с инхармоничностью. Самое «правдоподобное» тело.",
             [] (UiParams& u) {
                 u.split = 0.55f; u.husk = 1.1f;
                 u.bodyshape = 0.0f; u.bodymodes = 28; u.bodydecay = 3.0f;
                 u.bodybright = 0.62f; u.bodypos = 0.20f; u.bodyamt = 1.0f;
                 u.fieldamt = 0.30f; u.fielddecay = 3.5f; u.fielddamp = 0.25f;
                 u.fieldstrings = 8; u.drift = 0.30f;
                 u.airamt = 0.30f; u.airsize = 1.0f; u.airbloom = 0.80f;
                 u.airdamp = 0.45f; u.airdrive = 0.08f;
                 u.mix = 0.50f; });

        add ("Tube", "Bodies",
             "Только нечётные гармоники, фиксированная нота. Кларнетовая полая труба.",
             [] (UiParams& u) {
                 u.split = 0.70f; u.husk = 1.2f;
                 u.bodyshape = 0.333f; u.bodymodes = 12; u.bodydecay = 2.5f;
                 u.bodybright = 0.40f; u.bodypos = 0.33f; u.bodyamt = 1.0f;
                 u.bodytune = 2; u.bodyfixed = 82.41f;
                 u.fieldamt = 0.22f; u.fielddecay = 3.0f; u.fielddamp = 0.20f;
                 u.fieldstrings = 7; u.drift = 0.35f;
                 u.airamt = 0.34f; u.airsize = 1.15f; u.airbloom = 0.80f;
                 u.airdamp = 0.5f; u.airdrive = 0.05f;
                 u.mix = 0.50f; });

        add ("Marimba Shell", "Bodies",
             "Свободный брусок, короткий и сухой. Перкуссия из медиатора.",
             [] (UiParams& u) {
                 u.split = 0.92f; u.husk = 1.5f;
                 u.bodyshape = 0.667f; u.bodymodes = 8; u.bodydecay = 0.80f;
                 u.bodybright = 0.70f; u.bodypos = 0.10f; u.bodyamt = 1.0f;
                 u.fieldamt = 0.10f; u.fielddecay = 1.2f; u.fielddamp = 0.45f;
                 u.fieldstrings = 5; u.drift = 0.20f;
                 u.airamt = 0.24f; u.airsize = 0.65f; u.airbloom = 0.68f;
                 u.airdamp = 0.55f; u.airdrive = 0.0f;
                 u.mix = 0.46f; });

        add ("Bell Plate", "Bodies",
             "Инхармоничная пластина, длинный звон. Металл, но не «дешёвый металл».",
             [] (UiParams& u) {
                 u.split = 0.80f; u.husk = 1.4f;
                 u.bodyshape = 1.0f; u.bodymodes = 30; u.bodydecay = 5.0f;
                 u.bodybright = 0.74f; u.bodypos = 0.09f; u.bodyamt = 1.0f;
                 u.bodytune = 2; u.bodyfixed = 146.83f;
                 u.fieldamt = 0.28f; u.fielddecay = 4.0f; u.fielddamp = 0.30f;
                 u.fieldstrings = 9; u.drift = 0.45f;
                 u.airamt = 0.45f; u.airsize = 1.60f; u.airbloom = 0.86f;
                 u.airdamp = 0.38f; u.airdrive = 0.18f;
                 u.mix = 0.56f; });

        // ---------------------------------------------------------- FIELDS
        add ("Sympathetic", "Fields",
             "Двенадцать струн в ладу. Базовый вариант «второй невидимой гитары».",
             [] (UiParams& u) {
                 u.split = 0.25f;
                 u.bodyshape = 0.22f; u.bodymodes = 14; u.bodydecay = 1.6f;
                 u.bodybright = 0.5f; u.bodyamt = 0.35f;
                 u.fieldamt = 1.0f; u.fielddecay = 6.0f; u.fielddamp = 0.22f;
                 u.fieldstrings = 12; u.drift = 0.45f;
                 u.airamt = 0.30f; u.airsize = 1.0f; u.airbloom = 0.80f;
                 u.airdamp = 0.5f; u.airdrive = 0.05f;
                 u.mix = 0.52f; });

        add ("Sitar Bridge", "Fields",
             "Яркое дребезжащее поле плюс жёсткий верх тела. Ближе всего к джавари.",
             [] (UiParams& u) {
                 u.split = 0.82f; u.husk = 1.6f;
                 u.bodyshape = 0.05f; u.bodymodes = 24; u.bodydecay = 1.2f;
                 u.bodybright = 0.85f; u.bodypos = 0.07f; u.bodyamt = 0.45f;
                 u.fieldamt = 1.0f; u.fielddecay = 3.5f; u.fielddamp = 0.62f;
                 u.fieldstrings = 12; u.drift = 0.14f;
                 u.airamt = 0.26f; u.airsize = 0.85f; u.airbloom = 0.74f;
                 u.airdamp = 0.35f; u.airdrive = 0.10f;
                 u.mix = 0.56f; });

        add ("Slow Field", "Fields",
             "Очень длинные струны с сильным дрейфом. Медленно наливается.",
             [] (UiParams& u) {
                 u.split = 0.30f;
                 u.bodyshape = 0.30f; u.bodymodes = 18; u.bodydecay = 4.0f;
                 u.bodybright = 0.45f; u.bodyamt = 0.40f;
                 u.fieldamt = 1.0f; u.fielddecay = 14.0f; u.fielddamp = 0.14f;
                 u.fieldstrings = 10; u.drift = 0.80f;
                 u.airamt = 0.40f; u.airsize = 1.80f; u.airbloom = 0.88f;
                 u.airdamp = 0.40f; u.airdrive = 0.10f;
                 u.mix = 0.62f; });

        add ("Harp Room", "Fields",
             "Поле в большой комнате с пластиной. Плотно, но не мутно.",
             [] (UiParams& u) {
                 u.split = 0.40f; u.husk = 1.2f;
                 u.bodyshape = 0.90f; u.bodymodes = 20; u.bodydecay = 3.4f;
                 u.bodybright = 0.55f; u.bodyamt = 0.38f;
                 u.fieldamt = 0.90f; u.fielddecay = 8.0f; u.fielddamp = 0.20f;
                 u.fieldstrings = 12; u.drift = 0.55f;
                 u.airamt = 0.55f; u.airsize = 2.0f; u.airbloom = 0.90f;
                 u.airdamp = 0.30f; u.airdrive = 0.15f;
                 u.mix = 0.66f; });

        // --------------------------------------------------------- STRANGE
        add ("Inversion", "Strange",
             "CROSS на максимум: шелуха играет тело, тон уходит в струны.",
             [] (UiParams& u) {
                 u.split = 0.50f; u.cross = 1.0f; u.husk = 1.6f;
                 u.bodyshape = 0.60f; u.bodymodes = 22; u.bodydecay = 3.2f;
                 u.bodybright = 0.60f; u.bodypos = 0.17f; u.bodyamt = 1.0f;
                 u.fieldamt = 0.55f; u.fielddecay = 5.0f; u.fielddamp = 0.42f;
                 u.fieldstrings = 10; u.drift = 0.60f;
                 u.airamt = 0.42f; u.airsize = 1.30f; u.airbloom = 0.86f;
                 u.airdamp = 0.42f; u.airdrive = 0.20f;
                 u.mix = 0.62f; });

        add ("Wrong Instrument", "Strange",
             "Большая низкая пластина не в той тональности. Неуютно и красиво.",
             [] (UiParams& u) {
                 u.split = 0.30f; u.cross = 1.0f; u.husk = 1.1f;
                 u.bodyshape = 1.0f; u.bodymodes = 40; u.bodydecay = 6.0f;
                 u.bodybright = 0.88f; u.bodypos = 0.05f; u.bodyamt = 1.0f;
                 u.bodytune = 2; u.bodyfixed = 61.74f;
                 u.fieldamt = 0.70f; u.fielddecay = 9.0f; u.fielddamp = 0.50f;
                 u.fieldstrings = 11; u.drift = 0.65f;
                 u.airamt = 0.50f; u.airsize = 1.9f; u.airbloom = 0.89f;
                 u.airdamp = 0.34f; u.airdrive = 0.38f;
                 u.mix = 0.70f; });

        add ("Insect", "Strange",
             "Шесть очень коротких мод и злой дрейф. Сухо, нервно, почти сухие щелчки.",
             [] (UiParams& u) {
                 u.split = 1.0f; u.husk = 2.4f;
                 u.bodyshape = 0.72f; u.bodymodes = 6; u.bodydecay = 0.25f;
                 u.bodybright = 1.0f; u.bodypos = 0.04f; u.bodyamt = 1.0f;
                 u.fieldamt = 0.40f; u.fielddecay = 1.2f; u.fielddamp = 0.70f;
                 u.fieldstrings = 7; u.drift = 1.0f;
                 u.airamt = 0.30f; u.airsize = 0.40f; u.airbloom = 0.72f;
                 u.airdamp = 0.30f; u.airdrive = 0.25f;
                 u.mix = 0.56f; });

        add ("Tension", "Strange",
             "BLOOM у самого края. Сеть почти самовозбуждается, но остаётся в ладу.",
             [] (UiParams& u) {
                 u.split = 0.45f; u.cross = 0.60f; u.husk = 1.3f;
                 u.bodyshape = 0.48f; u.bodymodes = 26; u.bodydecay = 7.0f;
                 u.bodybright = 0.55f; u.bodyamt = 0.75f;
                 u.fieldamt = 0.80f; u.fielddecay = 12.0f; u.fielddamp = 0.22f;
                 u.fieldstrings = 11; u.drift = 0.70f;
                 u.airamt = 0.68f; u.airsize = 2.20f; u.airbloom = 0.95f;
                 u.airdamp = 0.28f; u.airdrive = 0.50f;
                 u.mix = 0.74f; });

        // ------------------------------------------------------------ VAST
        add ("Bloom", "Vast",
             "Расцвет: длинные хвосты, обе машины поровну. Рабочая лошадка эмбиента.",
             [] (UiParams& u) {
                 u.split = 0.45f; u.cross = 0.35f;
                 u.bodyshape = 0.38f; u.bodymodes = 20; u.bodydecay = 6.0f;
                 u.bodybright = 0.58f; u.bodyamt = 0.85f;
                 u.fieldamt = 0.90f; u.fielddecay = 9.0f; u.fielddamp = 0.18f;
                 u.fieldstrings = 12; u.drift = 0.70f;
                 u.airamt = 0.62f; u.airsize = 2.0f; u.airbloom = 0.93f;
                 u.airdamp = 0.30f; u.airdrive = 0.30f;
                 u.mix = 0.72f; });

        add ("Cathedral Husk", "Vast",
             "Максимум воздуха, тёмный хвост. Один аккорд держится минуту.",
             [] (UiParams& u) {
                 u.split = 0.55f; u.husk = 1.2f;
                 u.bodyshape = 0.42f; u.bodymodes = 24; u.bodydecay = 8.0f;
                 u.bodybright = 0.48f; u.bodyamt = 0.80f;
                 u.fieldamt = 0.85f; u.fielddecay = 16.0f; u.fielddamp = 0.15f;
                 u.fieldstrings = 12; u.drift = 0.60f;
                 u.airamt = 0.80f; u.airsize = 2.5f; u.airbloom = 0.95f;
                 u.airdamp = 0.24f; u.airdrive = 0.22f;
                 u.mix = 0.80f; });

        add ("Distant Weather", "Vast",
             "Только шелуха, много мод, огромное пространство. Шум погоды, не гитара.",
             [] (UiParams& u) {
                 u.split = 0.95f; u.husk = 2.0f;
                 u.bodyshape = 0.80f; u.bodymodes = 44; u.bodydecay = 9.0f;
                 u.bodybright = 0.80f; u.bodypos = 0.06f; u.bodyamt = 1.0f;
                 u.fieldamt = 0.60f; u.fielddecay = 12.0f; u.fielddamp = 0.30f;
                 u.fieldstrings = 12; u.drift = 0.85f;
                 u.airamt = 0.75f; u.airsize = 2.30f; u.airbloom = 0.93f;
                 u.airdamp = 0.32f; u.airdrive = 0.35f;
                 u.mix = 0.84f; });

        add ("Undertow", "Vast",
             "Низкое фиксированное тело под всем, что играешь. Тёмный подводный гул.",
             [] (UiParams& u) {
                 u.split = 0.40f; u.husk = 1.0f;
                 u.bodyshape = 0.20f; u.bodymodes = 52; u.bodydecay = 10.0f;
                 u.bodybright = 0.26f; u.bodypos = 0.40f; u.bodyamt = 1.0f;
                 u.bodytune = 2; u.bodyfixed = 49.0f;
                 u.fieldamt = 0.50f; u.fielddecay = 10.0f; u.fielddamp = 0.12f;
                 u.fieldstrings = 8; u.drift = 0.50f;
                 u.airamt = 0.70f; u.airsize = 2.20f; u.airbloom = 0.92f;
                 u.airdamp = 0.20f; u.airdrive = 0.18f;
                 u.mix = 0.70f; });

        // --------------------------------------------------------- UTILITY
        add ("Freeze Pad", "Utility",
             "Заготовка под FREEZE: сыграй аккорд и нажми кнопку — хвост встанет намертво.",
             [] (UiParams& u) {
                 u.split = 0.35f;
                 u.bodyshape = 0.35f; u.bodymodes = 22; u.bodydecay = 6.0f;
                 u.bodybright = 0.50f; u.bodyamt = 0.70f;
                 u.fieldamt = 0.85f; u.fielddecay = 10.0f; u.fielddamp = 0.18f;
                 u.fieldstrings = 12; u.drift = 0.60f;
                 u.airamt = 1.0f; u.airsize = 1.8f; u.airbloom = 0.92f;
                 u.airdamp = 0.32f; u.airdrive = 0.10f;
                 u.mix = 0.70f; });

        add ("Tuning Drone", "Utility",
             "Тело настроено на тонику, струны длинные. Гудящая опора под импровизацию.",
             [] (UiParams& u) {
                 u.split = 0.35f;
                 u.bodyshape = 0.16f; u.bodymodes = 24; u.bodydecay = 12.0f;
                 u.bodybright = 0.42f; u.bodyamt = 0.90f;
                 u.bodytune = 1;
                 u.fieldamt = 1.0f; u.fielddecay = 20.0f; u.fielddamp = 0.16f;
                 u.fieldstrings = 12; u.drift = 0.40f;
                 u.airamt = 0.50f; u.airsize = 1.5f; u.airbloom = 0.90f;
                 u.airdamp = 0.36f; u.airdrive = 0.08f;
                 u.mix = 0.66f; });

        add ("Warm Double", "Utility",
             "Утолщитель. Почти не слышен отдельно, но трек без него становится плоским.",
             [] (UiParams& u) {
                 u.split = 0.45f; u.husk = 0.8f;
                 u.bodyshape = 0.08f; u.bodymodes = 14; u.bodydecay = 1.2f;
                 u.bodybright = 0.40f; u.bodypos = 0.32f; u.bodyamt = 0.60f;
                 u.fieldamt = 0.35f; u.fielddecay = 2.4f; u.fielddamp = 0.22f;
                 u.fieldstrings = 7; u.drift = 0.25f;
                 u.airamt = 0.15f; u.airsize = 0.60f; u.airbloom = 0.60f;
                 u.airdamp = 0.60f; u.airdrive = 0.0f;
                 u.mix = 0.18f; });

        add ("Send 100%", "Utility",
             "Для посыла на отдельную шину: сухого нет вообще, только машины.",
             [] (UiParams& u) {
                 u.split = 0.50f; u.husk = 1.2f;
                 u.bodyshape = 0.30f; u.bodymodes = 20; u.bodydecay = 3.0f;
                 u.bodybright = 0.55f; u.bodyamt = 0.85f;
                 u.fieldamt = 0.70f; u.fielddecay = 6.0f; u.fielddamp = 0.22f;
                 u.fieldstrings = 10; u.drift = 0.45f;
                 u.airamt = 0.45f; u.airsize = 1.3f; u.airbloom = 0.85f;
                 u.airdamp = 0.40f; u.airdrive = 0.12f;
                 u.mix = 1.0f; });

        int nTrim = 0;
        const float* trim = presetTrimDb (nTrim);
        for (size_t i = 0; i < v.size(); ++i)
            if ((int) i < nTrim) v[i].p.outputDb += trim[i];

        return v;
    }();
    return bank;
}

/** Калибровка громкости. Значения генерирует tools/preset_audit.py --write:
    он рендерит весь банк, считает интегральную громкость по BS.1770 и
    подбирает трим так, чтобы включение любого пресета не меняло уровень.
    Руками не править — перезапишется. */
// BEGIN GENERATED TRIMS
inline const float* presetTrimDb (int& count) noexcept
{
    static const float t[] = {
          -4.6f,
          -2.8f,
          -2.9f,
          -2.4f,
          -5.1f,
          -1.5f,
          -2.2f,
           2.1f,
          -2.9f,
           0.1f,
          -2.8f,
          -1.7f,
          -5.3f,
          -1.0f,
          -1.4f,
          -2.1f,
          -3.4f,
          -3.4f,
           1.2f,
           1.6f,
          -3.5f,
          -0.9f,
          -3.1f,
          -9.9f
    };
    count = (int) (sizeof (t) / sizeof (t[0]));
    return t;
}
// END GENERATED TRIMS

inline int findPreset (const std::string& name)
{
    const auto& b = factoryPresets();
    for (size_t i = 0; i < b.size(); ++i)
        if (name == b[i].name) return (int) i;
    return -1;
}

} // namespace husk
