#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include "dsp/UiParams.h"
#include "Presets.h"

class HuskAudioProcessor : public juce::AudioProcessor
{
public:
    HuskAudioProcessor();
    ~HuskAudioProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout&) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "HUSK"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 12.0; }

    int getNumPrograms() override { return (int) husk::factoryPresets().size(); }
    int getCurrentProgram() override { return currentProgram; }
    void setCurrentProgram (int index) override;
    const juce::String getProgramName (int index) override;
    void changeProgramName (int, const juce::String&) override {}

    /** Применяет набор значений к APVTS (уведомляя хост — автоматизация и
        undo в DAW видят изменение). Вызывать только из message thread. */
    void applyUiParams (const husk::UiParams&);
    void applyFactoryPreset (int index);
    husk::UiParams currentUiParams() const;

    // пользовательские пресеты
    static juce::File userPresetDir();
    bool saveUserPreset (const juce::String& name);
    bool loadUserPreset (const juce::File&);
    juce::StringArray userPresetNames() const;

    juce::String displayedPresetName { husk::factoryPresets()[0].name };

    void getStateInformation (juce::MemoryBlock&) override;
    void setStateInformation (const void*, int) override;

    juce::AudioProcessorValueTreeState apvts;

    // для интерфейса
    int   uiKeyRoot()  const noexcept { return engine.getKeyRoot(); }
    bool  uiKeyMinor() const noexcept { return engine.getKeyMinor(); }
    float uiF0()       const noexcept { return engine.getTrackedF0(); }
    float uiTransient() const noexcept { return engine.getTransientness(); }
    bool  readVisualState (husk::VisualState& v) const noexcept { return engine.readVisualState (v); }

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();
    void pullParameters() noexcept;

    int currentProgram = 0;
    husk::Engine engine;
    juce::AudioBuffer<float> monoIn;

    // кэш указателей на параметры — atomic-чтение в аудио-потоке
    std::atomic<float>* pSplit = nullptr;   std::atomic<float>* pCross = nullptr;
    std::atomic<float>* pHusk = nullptr;
    std::atomic<float>* pBodyShape = nullptr; std::atomic<float>* pBodyModes = nullptr;
    std::atomic<float>* pBodyDecay = nullptr; std::atomic<float>* pBodyBright = nullptr;
    std::atomic<float>* pBodyPos = nullptr;   std::atomic<float>* pBodyAmt = nullptr;
    std::atomic<float>* pBodyTune = nullptr;  std::atomic<float>* pBodyFixed = nullptr;
    std::atomic<float>* pFieldAmt = nullptr;  std::atomic<float>* pFieldDecay = nullptr;
    std::atomic<float>* pFieldDamp = nullptr; std::atomic<float>* pFieldStrings = nullptr;
    std::atomic<float>* pDrift = nullptr;
    std::atomic<float>* pAirAmt = nullptr;    std::atomic<float>* pAirSize = nullptr;
    std::atomic<float>* pAirBloom = nullptr;  std::atomic<float>* pAirDamp = nullptr;
    std::atomic<float>* pAirDrive = nullptr;  std::atomic<float>* pFreeze = nullptr;
    std::atomic<float>* pMix = nullptr;       std::atomic<float>* pOut = nullptr;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (HuskAudioProcessor)
};
