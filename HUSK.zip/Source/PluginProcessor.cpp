#include "PluginProcessor.h"
#include "PluginEditor.h"

using namespace juce;

namespace
{
    inline auto pct (const String& id, const String& name, float def)
    {
        return std::make_unique<AudioParameterFloat> (
            ParameterID { id, 1 }, name, NormalisableRange<float> (0.0f, 1.0f, 0.001f), def);
    }
}

AudioProcessorValueTreeState::ParameterLayout HuskAudioProcessor::createLayout()
{
    AudioProcessorValueTreeState::ParameterLayout l;

    // Значения по умолчанию = первый заводской пресет. Свежий экземпляр плагина
    // сразу звучит осмысленно, и подпись пресета не врёт.
    const husk::UiParams d = husk::factoryPresets()[0].p;

    l.add (pct ("split", "Split", d.split));
    l.add (pct ("cross", "Cross", d.cross));
    l.add (std::make_unique<AudioParameterFloat> (ParameterID { "husk", 1 }, "Husk",
             NormalisableRange<float> (0.0f, 3.0f, 0.001f, 0.6f), d.husk));

    l.add (pct ("bodyshape", "Body Shape", d.bodyshape));
    l.add (std::make_unique<AudioParameterInt> (ParameterID { "bodymodes", 1 }, "Body Modes", 4, 64, d.bodymodes));
    l.add (std::make_unique<AudioParameterFloat> (ParameterID { "bodydecay", 1 }, "Body Decay",
             NormalisableRange<float> (0.05f, 12.0f, 0.001f, 0.4f), d.bodydecay));
    l.add (pct ("bodybright", "Body Bright", d.bodybright));
    l.add (pct ("bodypos", "Body Position", d.bodypos));
    l.add (pct ("bodyamt", "Body Amount", d.bodyamt));
    l.add (std::make_unique<AudioParameterChoice> (ParameterID { "bodytune", 1 }, "Body Tune",
             StringArray { "Follow", "Key", "Fixed" }, d.bodytune));
    l.add (std::make_unique<AudioParameterFloat> (ParameterID { "bodyfixed", 1 }, "Body Fixed",
             NormalisableRange<float> (30.0f, 600.0f, 0.01f, 0.35f), d.bodyfixed));

    l.add (pct ("fieldamt", "Field Amount", d.fieldamt));
    l.add (std::make_unique<AudioParameterFloat> (ParameterID { "fielddecay", 1 }, "Field Decay",
             NormalisableRange<float> (0.2f, 20.0f, 0.001f, 0.4f), d.fielddecay));
    l.add (pct ("fielddamp", "Field Damp", d.fielddamp));
    l.add (std::make_unique<AudioParameterInt> (ParameterID { "fieldstrings", 1 }, "Field Strings", 1, 12, d.fieldstrings));
    l.add (pct ("drift", "Drift", d.drift));

    l.add (pct ("airamt", "Air Amount", d.airamt));
    l.add (std::make_unique<AudioParameterFloat> (ParameterID { "airsize", 1 }, "Air Size",
             NormalisableRange<float> (0.15f, 2.5f, 0.001f), d.airsize));
    l.add (std::make_unique<AudioParameterFloat> (ParameterID { "airbloom", 1 }, "Air Bloom",
             NormalisableRange<float> (0.0f, 0.99f, 0.001f), d.airbloom));
    l.add (pct ("airdamp", "Air Damp", d.airdamp));
    l.add (pct ("airdrive", "Air Drive", d.airdrive));
    l.add (std::make_unique<AudioParameterBool> (ParameterID { "freeze", 1 }, "Freeze", d.freeze));

    l.add (pct ("mix", "Mix", d.mix));
    l.add (std::make_unique<AudioParameterFloat> (ParameterID { "output", 1 }, "Output",
             NormalisableRange<float> (-24.0f, 12.0f, 0.01f), d.outputDb));

    return l;
}

HuskAudioProcessor::HuskAudioProcessor()
    : AudioProcessor (BusesProperties()
                        .withInput ("Input", AudioChannelSet::stereo(), true)
                        .withOutput ("Output", AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "HUSK", createLayout())
{
    auto g = [this] (const char* id) { return apvts.getRawParameterValue (id); };
    pSplit = g ("split");           pCross = g ("cross");         pHusk = g ("husk");
    pBodyShape = g ("bodyshape");   pBodyModes = g ("bodymodes"); pBodyDecay = g ("bodydecay");
    pBodyBright = g ("bodybright"); pBodyPos = g ("bodypos");     pBodyAmt = g ("bodyamt");
    pBodyTune = g ("bodytune");     pBodyFixed = g ("bodyfixed");
    pFieldAmt = g ("fieldamt");     pFieldDecay = g ("fielddecay");
    pFieldDamp = g ("fielddamp");   pFieldStrings = g ("fieldstrings"); pDrift = g ("drift");
    pAirAmt = g ("airamt");         pAirSize = g ("airsize");     pAirBloom = g ("airbloom");
    pAirDamp = g ("airdamp");       pAirDrive = g ("airdrive");   pFreeze = g ("freeze");
    pMix = g ("mix");               pOut = g ("output");
}

void HuskAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    engine.prepare (sampleRate, samplesPerBlock);
    monoIn.setSize (1, std::max (samplesPerBlock, 4096), false, true, true);
    // весь тракт во временной области — компенсировать нечего
    setLatencySamples (0);
}

bool HuskAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto& out = layouts.getMainOutputChannelSet();
    const auto& in  = layouts.getMainInputChannelSet();
    if (out != AudioChannelSet::stereo() && out != AudioChannelSet::mono()) return false;
    if (in  != AudioChannelSet::stereo() && in  != AudioChannelSet::mono()) return false;
    return true;
}

husk::UiParams HuskAudioProcessor::currentUiParams() const
{
    husk::UiParams u;
    u.split        = pSplit->load();
    u.cross        = pCross->load();
    u.husk         = pHusk->load();
    u.bodyshape    = pBodyShape->load();
    u.bodymodes    = (int) pBodyModes->load();
    u.bodydecay    = pBodyDecay->load();
    u.bodybright   = pBodyBright->load();
    u.bodypos      = pBodyPos->load();
    u.bodyamt      = pBodyAmt->load();
    u.bodytune     = (int) pBodyTune->load();
    u.bodyfixed    = pBodyFixed->load();
    u.fieldamt     = pFieldAmt->load();
    u.fielddecay   = pFieldDecay->load();
    u.fielddamp    = pFieldDamp->load();
    u.fieldstrings = (int) pFieldStrings->load();
    u.drift        = pDrift->load();
    u.airamt       = pAirAmt->load();
    u.airsize      = pAirSize->load();
    u.airbloom     = pAirBloom->load();
    u.airdamp      = pAirDamp->load();
    u.airdrive     = pAirDrive->load();
    u.freeze       = pFreeze->load() > 0.5f;
    u.mix          = pMix->load();
    u.outputDb     = pOut->load();
    return u;
}

void HuskAudioProcessor::pullParameters() noexcept
{
    engine.setParameters (husk::toEngine (currentUiParams()));
}

// --------------------------------------------------------------- пресеты
namespace
{
    void setParam (AudioProcessorValueTreeState& s, const char* id, float v)
    {
        if (auto* p = s.getParameter (id))
            p->setValueNotifyingHost (p->convertTo0to1 (v));
    }
}

void HuskAudioProcessor::applyUiParams (const husk::UiParams& u)
{
    setParam (apvts, "split",        u.split);
    setParam (apvts, "cross",        u.cross);
    setParam (apvts, "husk",         u.husk);
    setParam (apvts, "bodyshape",    u.bodyshape);
    setParam (apvts, "bodymodes",    (float) u.bodymodes);
    setParam (apvts, "bodydecay",    u.bodydecay);
    setParam (apvts, "bodybright",   u.bodybright);
    setParam (apvts, "bodypos",      u.bodypos);
    setParam (apvts, "bodyamt",      u.bodyamt);
    setParam (apvts, "bodytune",     (float) u.bodytune);
    setParam (apvts, "bodyfixed",    u.bodyfixed);
    setParam (apvts, "fieldamt",     u.fieldamt);
    setParam (apvts, "fielddecay",   u.fielddecay);
    setParam (apvts, "fielddamp",    u.fielddamp);
    setParam (apvts, "fieldstrings", (float) u.fieldstrings);
    setParam (apvts, "drift",        u.drift);
    setParam (apvts, "airamt",       u.airamt);
    setParam (apvts, "airsize",      u.airsize);
    setParam (apvts, "airbloom",     u.airbloom);
    setParam (apvts, "airdamp",      u.airdamp);
    setParam (apvts, "airdrive",     u.airdrive);
    setParam (apvts, "freeze",       u.freeze ? 1.0f : 0.0f);
    setParam (apvts, "mix",          u.mix);
    setParam (apvts, "output",       u.outputDb);
}

void HuskAudioProcessor::applyFactoryPreset (int index)
{
    const auto& bank = husk::factoryPresets();
    if (! isPositiveAndBelow (index, (int) bank.size())) return;
    currentProgram = index;
    displayedPresetName = bank[(size_t) index].name;
    applyUiParams (bank[(size_t) index].p);
    updateHostDisplay();
}

void HuskAudioProcessor::setCurrentProgram (int index) { applyFactoryPreset (index); }

const String HuskAudioProcessor::getProgramName (int index)
{
    const auto& bank = husk::factoryPresets();
    if (! isPositiveAndBelow (index, (int) bank.size())) return {};
    return String (bank[(size_t) index].category) + " / " + bank[(size_t) index].name;
}

File HuskAudioProcessor::userPresetDir()
{
    auto d = File::getSpecialLocation (File::userApplicationDataDirectory)
                 .getChildFile ("HUSK").getChildFile ("Presets");
    if (! d.exists()) d.createDirectory();
    return d;
}

bool HuskAudioProcessor::saveUserPreset (const String& name)
{
    auto clean = File::createLegalFileName (name.trim());
    if (clean.isEmpty()) return false;
    auto f = userPresetDir().getChildFile (clean + ".huskpreset");
    auto state = apvts.copyState();
    state.setProperty ("presetName", name, nullptr);
    if (auto xml = state.createXml())
    {
        displayedPresetName = name;
        return xml->writeTo (f);
    }
    return false;
}

bool HuskAudioProcessor::loadUserPreset (const File& f)
{
    if (! f.existsAsFile()) return false;
    if (auto xml = parseXML (f))
    {
        if (! xml->hasTagName (apvts.state.getType())) return false;
        apvts.replaceState (ValueTree::fromXml (*xml));
        displayedPresetName = f.getFileNameWithoutExtension();
        updateHostDisplay();
        return true;
    }
    return false;
}

StringArray HuskAudioProcessor::userPresetNames() const
{
    StringArray out;
    for (auto& f : userPresetDir().findChildFiles (File::findFiles, false, "*.huskpreset"))
        out.add (f.getFileNameWithoutExtension());
    out.sortNatural();
    return out;
}

void HuskAudioProcessor::processBlock (AudioBuffer<float>& buffer, MidiBuffer&)
{
    ScopedNoDenormals noDenormals;
    const int n = buffer.getNumSamples();
    const int numIn = getTotalNumInputChannels();
    const int numOut = getTotalNumOutputChannels();

    pullParameters();

    // моно-сумма на вход движка
    float* m = monoIn.getWritePointer (0);
    if (numIn >= 2)
    {
        const float* a = buffer.getReadPointer (0);
        const float* b = buffer.getReadPointer (1);
        for (int i = 0; i < n; ++i) m[i] = 0.5f * (a[i] + b[i]);
    }
    else if (numIn == 1)
    {
        FloatVectorOperations::copy (m, buffer.getReadPointer (0), n);
    }
    else
    {
        FloatVectorOperations::clear (m, n);
    }

    if (numOut >= 2)
    {
        engine.process (m, buffer.getWritePointer (0), buffer.getWritePointer (1), n);
    }
    else if (numOut == 1)
    {
        auto* tmp = monoIn.getWritePointer (0);
        engine.process (m, buffer.getWritePointer (0), tmp, n);
    }

    for (int ch = numOut; ch < buffer.getNumChannels(); ++ch)
        buffer.clear (ch, 0, n);
}

AudioProcessorEditor* HuskAudioProcessor::createEditor() { return new HuskAudioProcessorEditor (*this); }

void HuskAudioProcessor::getStateInformation (MemoryBlock& dest)
{
    auto state = apvts.copyState();
    state.setProperty ("presetName", displayedPresetName, nullptr);
    state.setProperty ("program", currentProgram, nullptr);
    if (auto xml = state.createXml())
        copyXmlToBinary (*xml, dest);
}

void HuskAudioProcessor::setStateInformation (const void* data, int size)
{
    if (auto xml = getXmlFromBinary (data, size))
        if (xml->hasTagName (apvts.state.getType()))
        {
            auto tree = ValueTree::fromXml (*xml);
            apvts.replaceState (tree);
            displayedPresetName = tree.getProperty ("presetName",
                                     husk::factoryPresets()[0].name).toString();
            currentProgram = (int) tree.getProperty ("program", 0);

            // APVTS пропускает параметр, у которого ДЕнормализованное значение не
            // изменилось. У AudioParameterBool диапазон снапится в 0/1, поэтому
            // сырое нормализованное значение (например 0.1) остаётся от прошлого
            // состояния и не восстанавливается. Досылаем значения принудительно.
            for (auto* prm : getParameters())
                if (auto* rp = dynamic_cast<RangedAudioParameter*> (prm))
                    if (auto* v = apvts.getRawParameterValue (rp->getParameterID()))
                        rp->setValueNotifyingHost (rp->convertTo0to1 (v->load()));
        }
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new HuskAudioProcessor(); }
