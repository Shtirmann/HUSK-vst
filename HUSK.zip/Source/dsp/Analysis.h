#pragma once
#include "Utils.h"

namespace husk
{

// ============================================================================
/** Многополосный детектор транзиентности. Латентность 0.
    В каждой полосе отношение быстрой и медленной огибающей; итог взвешивается
    по энергии полос. Это управляющий сигнал 0..1, а не аудио. */
class TransientDetector
{
public:
    static constexpr int kBands = 4;

    void prepare (double sr) noexcept
    {
        static const float edges[kBands] = { 220.0f, 900.0f, 2800.0f, 7000.0f };
        for (int b = 0; b < kBands; ++b)
        {
            a[b] = std::exp (-2.0f * kPi * edges[b] / (float) sr);
            fast[b].prepare (sr, 0.0006f, 0.012f);
            slow[b].prepare (sr, 0.035f, 0.220f);
            lp[b] = 0.0f;
        }
    }

    void reset() noexcept
    {
        for (int b = 0; b < kBands; ++b) { lp[b] = 0.0f; fast[b].reset(); slow[b].reset(); }
    }

    inline float process (float x) noexcept
    {
        float prev = x, acc = 0.0f, tot = 0.0f;
        for (int b = 0; b < kBands; ++b)
        {
            lp[b] = (1.0f - a[b]) * prev + a[b] * lp[b];
            const float band = prev - lp[b];
            prev = lp[b];
            const float ef = fast[b].process (band);
            const float es = slow[b].process (band) + 1.0e-9f;
            float r = ef / es - 1.0f;
            r = std::clamp (r, 0.0f, 1.0f);
            acc += r * es;
            tot += es;
        }
        return acc / tot;
    }

private:
    float a[kBands] {}, lp[kBands] {};
    EnvFollower fast[kBands], slow[kBands];
};

// ============================================================================
/** Adaptive Line Enhancer (NLMS). Разделяет предсказуемое (тон) и
    непредсказуемое (шелуха) с латентностью delta сэмплов (~0.1 мс).
    Это единственный класс методов разделения с практически нулевой задержкой:
    любой спектральный подход стоит минимум длину окна. */
class AdaptiveLineEnhancer
{
public:
    void prepare (int taps, int delaySamples, float mu_)
    {
        P = taps;
        delta = delaySamples;
        mu = mu_;
        w.assign ((size_t) P, 0.0f);
        hist.assign ((size_t) nextPow2 (P + delta + 8), 0.0f);
        mask = (int) hist.size() - 1;
        wp = 0;
        pwr = 1.0e-6f;
    }

    void reset() noexcept
    {
        std::fill (w.begin(), w.end(), 0.0f);
        std::fill (hist.begin(), hist.end(), 0.0f);
        wp = 0;
        pwr = 1.0e-6f;
    }

    /** Возвращает tonal, кладёт остаток в residual. */
    inline float process (float x, float& residual) noexcept
    {
        hist[(size_t) wp] = x;

        const int base = wp - delta;
        float y = 0.0f;
        for (int k = 0; k < P; ++k)
            y += w[(size_t) k] * hist[(size_t) ((base - k) & mask)];

        const float e = x - y;

        const float xb = hist[(size_t) (base & mask)];
        pwr = 0.999f * pwr + 0.001f * (xb * xb) * (float) P;
        const float g = mu * e / (pwr + 1.0e-9f);
        for (int k = 0; k < P; ++k)
            w[(size_t) k] += g * hist[(size_t) ((base - k) & mask)];

        if (++wp > mask) wp = 0;

        if (isBad (y) || isBad (e)) { reset(); residual = 0.0f; return 0.0f; }
        residual = e;
        return y;
    }

private:
    static int nextPow2 (int n) { int p = 8; while (p < n) p <<= 1; return p; }

    std::vector<float> w, hist;
    int P = 320, delta = 4, wp = 0, mask = 0;
    float mu = 0.06f, pwr = 1.0e-6f;
};

// ============================================================================
/** YIN-подобный трекер на децимированном сигнале (12 кГц).
    Работает в control-пути: анализ «опаздывает» на ~27 мс, но управляет только
    строем резонаторов, поэтому в звуке это не слышно. Аудио не задерживается.

    Стоимость размазана по блокам: за один вызов считается фиксированная порция
    лагов, чтобы не было пика CPU на границе кадра. */
class PitchTracker
{
public:
    void prepare (double sr)
    {
        srIn = (float) sr;
        dec = std::max (1, (int) std::round (sr / 12000.0));
        srDec = (float) (sr / dec);
        tauMin = (int) (srDec / 1200.0f);
        tauMax = (int) (srDec / 70.0f);
        W = 2 * tauMax;
        ring.assign ((size_t) nextPow2 (W + 8), 0.0f);
        mask = (int) ring.size() - 1;
        d.assign ((size_t) (tauMax + 2), 0.0f);
        // антиалиасинговый ФНЧ перед децимацией (каскад двух однополюсников)
        aLp = std::exp (-2.0f * kPi * 2400.0f / (float) sr);
        lp1 = lp2 = 0.0f;
        wp = 0; decCnt = 0; tauCur = tauMin; running = false;
        f0 = 110.0f; conf = 0.0f;
    }

    void reset() noexcept
    {
        std::fill (ring.begin(), ring.end(), 0.0f);
        lp1 = lp2 = 0.0f; wp = 0; decCnt = 0; tauCur = tauMin; running = false;
        f0 = 110.0f; conf = 0.0f;
    }

    inline void pushSample (float x) noexcept
    {
        lp1 = (1.0f - aLp) * x + aLp * lp1;
        lp2 = (1.0f - aLp) * lp1 + aLp * lp2;
        if (++decCnt >= dec)
        {
            decCnt = 0;
            ring[(size_t) wp] = lp2;
            wp = (wp + 1) & mask;
            ++newSamples;
        }
    }

    /** Вызывается раз в блок. budget — сколько лагов посчитать за раз. */
    void advance (int budget) noexcept
    {
        if (! running)
        {
            if (newSamples < W / 4) return;      // обновляемся ~4 раза за окно
            newSamples = 0;
            anchor = wp;                          // фиксируем конец окна
            tauCur = tauMin;
            running = true;
        }

        const int N = W - tauMax;
        int done = 0;
        while (tauCur <= tauMax && done < budget)
        {
            float s = 0.0f;
            const int b = anchor - W;
            for (int j = 0; j < N; ++j)
            {
                const float v = ring[(size_t) ((b + j) & mask)]
                              - ring[(size_t) ((b + j + tauCur) & mask)];
                s += v * v;
            }
            d[(size_t) tauCur] = s;
            ++tauCur;
            ++done;
        }

        if (tauCur > tauMax)
        {
            running = false;
            finish();
        }
    }

    float getF0() const noexcept { return f0; }
    float getConfidence() const noexcept { return conf; }

private:
    static int nextPow2 (int n) { int p = 8; while (p < n) p <<= 1; return p; }

    void finish() noexcept
    {
        // CMNDF + первый минимум ниже порога
        double run = 0.0;
        int best = -1;
        float bestV = 1.0e9f;
        for (int t = tauMin; t <= tauMax; ++t)
        {
            run += d[(size_t) t];
            const float dn = (float) (d[(size_t) t] * (t - tauMin + 1) / (run + 1.0e-12));
            if (dn < bestV) { bestV = dn; best = t; }
            if (dn < 0.12f && t > tauMin + 1) { best = t; bestV = dn; break; }
        }
        if (best > tauMin && best < tauMax)
        {
            const float y0 = d[(size_t) (best - 1)], y1 = d[(size_t) best], y2 = d[(size_t) (best + 1)];
            const float den = 2.0f * (2.0f * y1 - y0 - y2);
            const float sh = (std::fabs (den) < 1.0e-12f) ? 0.0f : (y2 - y0) / den;
            const float cand = srDec / ((float) best + sh);
            if (cand > 60.0f && cand < 1400.0f)
            {
                f0 = cand;
                conf = std::clamp (1.0f - bestV, 0.0f, 1.0f);
                return;
            }
        }
        conf *= 0.5f;
    }

    std::vector<float> ring;
    std::vector<double> d;
    float srIn = 48000.0f, srDec = 12000.0f, aLp = 0.7f, lp1 = 0.0f, lp2 = 0.0f;
    int dec = 4, tauMin = 10, tauMax = 171, W = 342, mask = 0, wp = 0, decCnt = 0;
    int tauCur = 0, anchor = 0, newSamples = 0;
    bool running = false;
    float f0 = 110.0f, conf = 0.0f;
};

// ============================================================================
/** Определение тональности. Банк из 60 узких комплексных резонаторов
    (C2..B6) -> хрома -> корреляция с профилями Krumhansl-Schmuckler.

    Тональность меняется раз в секунды, поэтому здесь можно позволить себе
    длинное сглаживание и обновление раз в ~100 мс. */
class KeyFollower
{
public:
    static constexpr int kBins = 60;   // 5 октав по 12 полутонов, от C2
    static constexpr int kBase = 36;   // MIDI C2

    void prepare (double sr) noexcept
    {
        for (int i = 0; i < kBins; ++i)
        {
            const float f = midiToHz ((float) (kBase + i));
            const float bw = f / 28.0f;                      // Q ≈ 28
            const float R = std::exp (-kPi * bw / (float) sr);
            const float w = 2.0f * kPi * f / (float) sr;
            pr[i] = R * std::cos (w);
            pi_[i] = R * std::sin (w);
            gn[i] = 1.0f - R;
            // давим бас: он тянет тональность к себе
            wgt[i] = 1.0f / (1.0f + std::exp (- ((f - 150.0f) / 70.0f)));
            re[i] = im[i] = mag[i] = 0.0f;
        }
        smooth = std::exp (-1.0f / (4.0f * (float) sr));
        counter = 0;
        interval = (int) (sr / 10.0);
        root = 0; isMinor = false; strength = 0.0f;
    }

    void reset() noexcept
    {
        for (int i = 0; i < kBins; ++i) re[i] = im[i] = mag[i] = 0.0f;
        counter = 0;
    }

    inline void pushSample (float x) noexcept
    {
        for (int i = 0; i < kBins; ++i)
        {
            const float nr = gn[i] * x + pr[i] * re[i] - pi_[i] * im[i];
            const float ni = pr[i] * im[i] + pi_[i] * re[i];
            re[i] = nr; im[i] = ni;
            const float m = nr * nr + ni * ni;
            mag[i] = smooth * mag[i] + (1.0f - smooth) * m;
        }
        if (++counter >= interval) { counter = 0; estimate(); }
    }

    int getRoot() const noexcept { return root; }
    bool getIsMinor() const noexcept { return isMinor; }
    float getStrength() const noexcept { return strength; }

    /** Массив из 12 булей: принадлежит ли класс высоты текущему ладу. */
    void getScaleMask (bool* out12) const noexcept
    {
        static const int maj[7] = { 0, 2, 4, 5, 7, 9, 11 };
        static const int min_[7] = { 0, 2, 3, 5, 7, 8, 10 };
        for (int i = 0; i < 12; ++i) out12[i] = false;
        const int* sc = isMinor ? min_ : maj;
        for (int i = 0; i < 7; ++i) out12[(root + sc[i]) % 12] = true;
    }

private:
    void estimate() noexcept
    {
        float ch[12] = {};
        for (int i = 0; i < kBins; ++i)
            ch[(kBase + i) % 12] += mag[i] * wgt[i];

        float mx = 0.0f;
        for (int p = 0; p < 12; ++p) mx = std::max (mx, ch[p]);
        if (mx < 1.0e-12f) return;
        for (int p = 0; p < 12; ++p) ch[p] = std::log1p (100.0f * ch[p] / mx);

        float mean = 0.0f;
        for (int p = 0; p < 12; ++p) mean += ch[p];
        mean /= 12.0f;
        float nrm = 0.0f;
        for (int p = 0; p < 12; ++p) { ch[p] -= mean; nrm += ch[p] * ch[p]; }
        nrm = std::sqrt (nrm) + 1.0e-12f;

        static const float MAJ[12] = { 6.35f, 2.23f, 3.48f, 2.33f, 4.38f, 4.09f,
                                       2.52f, 5.19f, 2.39f, 3.66f, 2.29f, 2.88f };
        static const float MIN[12] = { 6.33f, 2.68f, 3.52f, 5.38f, 2.60f, 3.53f,
                                       2.54f, 4.75f, 3.98f, 2.69f, 3.34f, 3.17f };

        int bestR = root;
        bool bestM = isMinor;
        float bestC = -9.0f;
        for (int r = 0; r < 12; ++r)
        {
            for (int m = 0; m < 2; ++m)
            {
                const float* pf = m ? MIN : MAJ;
                float pm = 0.0f;
                for (int p = 0; p < 12; ++p) pm += pf[p];
                pm /= 12.0f;
                float dot = 0.0f, pn = 0.0f;
                for (int p = 0; p < 12; ++p)
                {
                    const float pv = pf[p] - pm;
                    dot += ch[(p + r) % 12] * pv;
                    pn += pv * pv;
                }
                const float c = dot / (nrm * (std::sqrt (pn) + 1.0e-12f));
                if (c > bestC) { bestC = c; bestR = r; bestM = (m == 1); }
            }
        }
        // гистерезис: смена тональности только при заметном выигрыше
        if (bestR != root || bestM != isMinor)
        {
            if (bestC > strength * 1.15f + 0.02f) { root = bestR; isMinor = bestM; strength = bestC; }
        }
        else strength = 0.9f * strength + 0.1f * bestC;
    }

    float pr[kBins] {}, pi_[kBins] {}, gn[kBins] {}, wgt[kBins] {};
    float re[kBins] {}, im[kBins] {}, mag[kBins] {};
    float smooth = 0.9999f, strength = 0.0f;
    int counter = 0, interval = 4800, root = 0;
    bool isMinor = false;
};

} // namespace husk
