#pragma once
#include "Utils.h"

namespace husk
{

/** Модальное тело: банк комплексных однополюсников.

    Комплексная форма выбрана намеренно: при T60 в единицы секунд полюс лежит на
    расстоянии ~5e-5 от единичной окружности, и direct-form биквад в float там
    накапливает ошибку. Состояния комплексного однополюсника ортогональны.

    Два параметра определяют, будет это резонатор или шумовой фильтр:
      MODES    — сколько мод активно (мало = чистый тон),
      T60 MIN  — нижняя граница затухания. Если верхние моды получают T60 в
                 единицы миллисекунд, они превращаются в широкие полосовые
                 фильтры, и банк начинает просто красить шум. 80–120 мс держат
                 его тональным.
*/
class ModalBank
{
public:
    static constexpr int kMaxModes = 64;

    enum Shape { String = 0, Tube, Bar, Plate, kNumShapes };

    void prepare (double sampleRate) noexcept
    {
        sr = (float) sampleRate;
        buildTables();
        reset();
    }

    void reset() noexcept
    {
        for (int k = 0; k < kMaxModes; ++k) { re[k] = im[k] = 0.0f; }
    }

    /** shape 0..1 — непрерывный морф струна → труба → брусок → пластина. */
    void setShape (float shape01) noexcept
    {
        const float pos = std::clamp (shape01, 0.0f, 1.0f) * (float) (kNumShapes - 1);
        const int i = std::min ((int) pos, kNumShapes - 2);
        const float f = pos - (float) i;
        for (int k = 0; k < kMaxModes; ++k)
            ratios[k] = std::exp ((1.0f - f) * logTab[i][k] + f * logTab[i + 1][k]);
    }

    void setTone (int numModes, float t60, float t60min, float brightness,
                  float position, float tilt) noexcept
    {
        nModes = std::clamp (numModes, 1, kMaxModes);
        decay = std::max (0.02f, t60);
        minT60 = std::max (0.005f, t60min);
        bright = std::clamp (brightness, 0.0f, 1.0f);
        pos = std::clamp (position, 0.02f, 0.98f);
        tiltAmt = std::max (0.0f, tilt);
    }

    /** Пересчёт коэффициентов. Вызывать на control-rate (раз в 32–64 сэмпла),
        не на каждый сэмпл: здесь sin/cos/pow. */
    void updateCoeffs (float f0) noexcept
    {
        f0 = std::clamp (f0, 20.0f, 2000.0f);
        lastF0 = f0;
        // q_loss: верхние моды теряют добротность быстрее — это и есть «органика».
        // Без него банк звучит как дешёвый металл.
        const float qLoss = bright * (2.0f - bright) * 0.85f + 0.15f;
        float loss = 1.0f;
        const float nyq = 0.45f * sr;

        for (int k = 0; k < nModes; ++k)
        {
            const float fk = f0 * ratios[k];
            visHz[k] = fk;
            if (fk > nyq || fk < 15.0f) { amp[k] = 0.0f; visAmp[k] = 0.0f; pr[k] = pi_[k] = 0.0f; loss *= qLoss; continue; }

            float t60 = decay * loss;
            if (t60 < minT60) t60 = minT60;
            const float R = std::pow (10.0f, -3.0f / (sr * t60));
            const float w = 2.0f * kPi * fk / sr;
            pr[k] = R * std::cos (w);
            pi_[k] = R * std::sin (w);
            // sin(k*pi*p) — гребёнка точки возбуждения, как на реальной струне
            const float aPos = std::sin (kPi * (float) (k + 1) * pos);
            amp[k] = (1.0f - R) * aPos / (1.0f + tiltAmt * 0.25f * (float) k);
            visAmp[k] = std::fabs (aPos) / (1.0f + tiltAmt * 0.25f * (float) k);
            visT60[k] = t60;
            loss *= qLoss;
        }
        for (int k = nModes; k < kMaxModes; ++k) { amp[k] = 0.0f; visAmp[k] = 0.0f; }
    }

    inline float process (float x) noexcept
    {
        float acc = 0.0f;
        for (int k = 0; k < nModes; ++k)
        {
            if (amp[k] == 0.0f) continue;
            const float nr = x + pr[k] * re[k] - pi_[k] * im[k];
            const float ni = pr[k] * im[k] + pi_[k] * re[k];
            re[k] = nr; im[k] = ni;
            acc += amp[k] * ni;
        }
        return acc;
    }

    // данные для интерфейса: что за резонаторы сейчас стоят
    int   visCount() const noexcept { return nModes; }
    float visFreq (int k) const noexcept { return visHz[k]; }
    float visAmplitude (int k) const noexcept { return visAmp[k]; }
    float visDecay (int k) const noexcept { return visT60[k]; }
    float visF0() const noexcept { return lastF0; }

    bool checkAndRepair() noexcept
    {
        for (int k = 0; k < nModes; ++k)
            if (isBad (re[k]) || isBad (im[k]) || std::fabs (re[k]) > 1.0e6f)
            { reset(); return false; }
        return true;
    }

private:
    void buildTables() noexcept
    {
        // реальные нули Бесселя для круглой мембраны, дальше — гладкое продолжение
        static const float mem12[12] = { 1.0f, 1.593f, 2.135f, 2.295f, 2.653f, 2.917f,
                                         3.155f, 3.500f, 3.598f, 3.652f, 3.869f, 4.060f };
        for (int k = 0; k < kMaxModes; ++k)
        {
            const float kk = (float) (k + 1);
            const float str = kk * std::sqrt (1.0f + 1.2e-4f * kk * kk); // инхармоничность стали
            const float tub = 2.0f * kk - 1.0f;                          // нечётные (труба)
            const float bar = (2.0f * kk + 1.0f) * (2.0f * kk + 1.0f) / 9.0f; // свободный брусок
            float pla;
            if (k < 12) pla = mem12[k];
            else        pla = mem12[11] * std::pow (kk / 12.0f, 0.78f)
                              * (1.0f + 0.045f * std::sin (2.39f * kk));
            logTab[String][k] = std::log (str);
            logTab[Tube][k]   = std::log (tub);
            logTab[Bar][k]    = std::log (bar);
            logTab[Plate][k]  = std::log (pla);
            ratios[k] = str;
        }
    }

    float sr = 48000.0f;
    float logTab[kNumShapes][kMaxModes] {};
    float ratios[kMaxModes] {};
    float pr[kMaxModes] {}, pi_[kMaxModes] {}, amp[kMaxModes] {};
    float re[kMaxModes] {}, im[kMaxModes] {};
    float visHz[kMaxModes] {}, visAmp[kMaxModes] {}, visT60[kMaxModes] {};
    float lastF0 = 110.0f;
    int nModes = 20;
    float decay = 1.8f, minT60 = 0.08f, bright = 0.55f, pos = 0.28f, tiltAmt = 1.0f;
};

} // namespace husk
