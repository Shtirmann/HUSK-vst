#pragma once
#include <cmath>
#include <algorithm>
#include <vector>
#include <cstdint>

namespace husk
{

inline constexpr float  kPi  = 3.14159265358979323846f;
inline constexpr double kPid = 3.14159265358979323846;

/** Периодически подмешиваемый знакопеременный дизер: страховка от денормалов
    на случай, если хост сбросил MXCSR. Знак чередуется, поэтому DC не копится. */
struct DenormalDither
{
    float v = 1.0e-20f;
    inline float next() noexcept { v = -v; return v; }
};

inline bool isBad (float x) noexcept { return ! std::isfinite (x); }

/** Однополюсный DC-блокер. Коэффициент считается в double: при fc < 10 Гц
    полюс слишком близко к единице для float. */
class DCBlocker
{
public:
    void prepare (double sampleRate, double fc = 18.0) noexcept
    {
        R = 1.0 - 2.0 * kPid * fc / sampleRate;
        reset();
    }
    void reset() noexcept { x1 = 0.0; y1 = 0.0; }

    inline float process (float x) noexcept
    {
        const double xd = (double) x;
        y1 = xd - x1 + R * y1;
        x1 = xd;
        return (float) y1;
    }

private:
    double R = 0.999, x1 = 0.0, y1 = 0.0;
};

/** Однополюсный ФВЧ через вычитание НЧ-составляющей. */
class OnePoleHP
{
public:
    void prepare (double sampleRate, float fc) noexcept
    {
        a = std::exp (-2.0f * kPi * fc / (float) sampleRate);
        z = 0.0f;
    }
    void reset() noexcept { z = 0.0f; }

    inline float process (float x) noexcept
    {
        z = (1.0f - a) * x + a * z;
        return x - z;
    }

private:
    float a = 0.99f, z = 0.0f;
};

/** Экспоненциальное сглаживание параметра. Сглаживаем ВЕЛИЧИНЫ (f0, Q, gain),
    никогда не коэффициенты биквада — интерполяция между двумя устойчивыми
    наборами коэффициентов может дать неустойчивый промежуточный. */
class Smoothed
{
public:
    void prepare (double sampleRate, float tauSeconds, float initial = 0.0f) noexcept
    {
        a = std::exp (-1.0f / (tauSeconds * (float) sampleRate));
        cur = target = initial;
    }
    inline void setTarget (float t) noexcept { target = t; }
    inline void snap (float t) noexcept { cur = target = t; }
    inline float next() noexcept { cur = target + a * (cur - target); return cur; }
    inline float value() const noexcept { return cur; }

private:
    float a = 0.99f, cur = 0.0f, target = 0.0f;
};

/** Огибающая с раздельными attack/release. */
class EnvFollower
{
public:
    void prepare (double sampleRate, float attackSec, float releaseSec) noexcept
    {
        aAtt = std::exp (-1.0f / (attackSec * (float) sampleRate));
        aRel = std::exp (-1.0f / (releaseSec * (float) sampleRate));
        e = 0.0f;
    }
    void reset() noexcept { e = 0.0f; }

    inline float process (float x) noexcept
    {
        const float m = std::fabs (x);
        const float a = (m > e) ? aAtt : aRel;
        e = a * e + (1.0f - a) * m;
        return e;
    }
    inline float value() const noexcept { return e; }

private:
    float aAtt = 0.9f, aRel = 0.99f, e = 0.0f;
};

/** Кольцевой буфер задержки с интерполяцией Эрмита (Catmull-Rom).
    Линейная интерполяция даёт слышимый алиасинг при модуляции задержки. */
class DelayLine
{
public:
    void prepare (int maxSamples)
    {
        size = std::max (8, maxSamples);
        buf.assign ((size_t) size, 0.0f);
        wp = 0;
    }
    void reset() noexcept { std::fill (buf.begin(), buf.end(), 0.0f); wp = 0; }

    inline void write (float x) noexcept
    {
        buf[(size_t) wp] = x;
        if (++wp >= size) wp = 0;
    }

    inline float readHermite (float delay) const noexcept
    {
        delay = std::clamp (delay, 2.0f, (float) size - 4.0f);
        const int di = (int) delay;
        const float f = delay - (float) di;
        auto at = [this] (int d) noexcept -> float
        {
            int i = wp - d;
            while (i < 0) i += size;
            while (i >= size) i -= size;
            return buf[(size_t) i];
        };
        const float ym1 = at (di - 1), y0 = at (di), y1 = at (di + 1), y2 = at (di + 2);
        const float c0 = y0;
        const float c1 = 0.5f * (y1 - ym1);
        const float c2 = ym1 - 2.5f * y0 + 2.0f * y1 - 0.5f * y2;
        const float c3 = 0.5f * (y2 - ym1) + 1.5f * (y0 - y1);
        return ((c3 * f + c2) * f + c1) * f + c0;
    }

    inline float readLinear (float delay) const noexcept
    {
        delay = std::clamp (delay, 1.0f, (float) size - 2.0f);
        const int di = (int) delay;
        const float f = delay - (float) di;
        int i0 = wp - di;      while (i0 < 0) i0 += size;
        int i1 = i0 - 1;       while (i1 < 0) i1 += size;
        return buf[(size_t) i0] * (1.0f - f) + buf[(size_t) i1] * f;
    }

    int capacity() const noexcept { return size; }

private:
    std::vector<float> buf;
    int size = 0, wp = 0;
};

/** Мягкий клиппер, ЛИНЕЙНЫЙ ниже порога: сухой сигнал не должен получать
    компрессию только потому, что в цепи есть предохранитель. */
inline float softClip (float x) noexcept
{
    constexpr float t = 0.75f, k = 1.0f - t;
    if (x >  t) return  t + k * std::tanh ((x - t) / k);
    if (x < -t) return -t - k * std::tanh ((-x - t) / k);
    return x;
}

inline float midiToHz (float m) noexcept { return 440.0f * std::pow (2.0f, (m - 69.0f) / 12.0f); }
inline float hzToMidi (float f) noexcept { return 69.0f + 12.0f * std::log2 (std::max (f, 1.0f) / 440.0f); }

} // namespace husk
