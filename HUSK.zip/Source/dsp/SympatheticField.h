#pragma once
#include "Utils.h"

namespace husk
{

/** Поле симпатических струн: K независимых waveguide-петель.

    Топология намеренно feed-forward (вход → K петель → сумма), без матрицы
    связи между струнами. Такая конфигурация безусловно устойчива: каждая петля
    проверяется отдельно на |H_loop| < 1. Почти все «мистические» самовозбуждения
    в подобных схемах берутся из попытки сделать честную bridge-coupling матрицу.

    Гейн-стейджинг: пик АЧХ гребёнки на резонансе равен 1/(1−g), поэтому вход
    каждой струны масштабируется на (1−g), а сумма — на 1/sqrt(K).
*/
class SympatheticField
{
public:
    static constexpr int kMaxStrings = 12;

    void prepare (double sampleRate)
    {
        sr = (float) sampleRate;
        const int maxLen = (int) (sr / 55.0f) + 16;
        for (int k = 0; k < kMaxStrings; ++k)
        {
            line[k].prepare (maxLen);
            dc[k].prepare (sampleRate, 12.0);
            phase[k] = 0.6283f * (float) k;
            lpz[k] = 0.0f;
        }
        reset();
    }

    void reset() noexcept
    {
        for (int k = 0; k < kMaxStrings; ++k) { line[k].reset(); dc[k].reset(); lpz[k] = 0.0f; }
    }

    /** Настройка строя. freqs — Гц, по возрастанию; соседние ноты разносим
        минимум на полтона: две струны ближе 0.5 Гц дают биение с периодом
        больше двух секунд, которое слышится как «наплыв». */
    void setTuning (const float* freqs, int count) noexcept
    {
        n = std::clamp (count, 1, kMaxStrings);
        for (int k = 0; k < n; ++k)
        {
            f0[k] = std::clamp (freqs[k], 60.0f, 2000.0f);
            L0[k] = sr / f0[k];
        }
        updateDamping();
    }

    void setDamping (float t60, float hfRatio) noexcept
    {
        decay = std::max (0.05f, t60);
        hf = std::clamp (hfRatio, 0.02f, 0.95f);
        updateDamping();
    }

    void setDrift (float amount, float rateHz) noexcept
    {
        drift = std::clamp (amount, 0.0f, 1.0f);
        dw = 2.0f * kPi * rateHz / sr;
    }

    inline float process (float x) noexcept
    {
        const float inv = invSqrtN;
        float acc = 0.0f;
        for (int k = 0; k < n; ++k)
        {
            phase[k] += dw * (0.6f + 0.2f * (float) (k % 5));
            if (phase[k] > 6.2831853f) phase[k] -= 6.2831853f;

            const float L = L0[k] * (1.0f + drift * 0.004f * std::sin (phase[k]));
            const float s = line[k].readHermite (L);

            // однополюсный loop-фильтр: g(1+a)/(1 + a z^-1)
            const float lp = g[k] * (1.0f + a[k]) * s - a[k] * lpz[k];
            lpz[k] = lp;
            const float v = dc[k].process (lp) + x * (1.0f - g[k]) * inv + dith.next();
            line[k].write (v);
            acc += s;
        }
        return acc * inv;
    }

    bool checkAndRepair() noexcept
    {
        for (int k = 0; k < n; ++k)
            if (isBad (lpz[k]) || std::fabs (lpz[k]) > 1.0e6f) { reset(); return false; }
        return true;
    }

    int numStrings() const noexcept { return n; }
    float stringFreq (int k) const noexcept { return f0[k]; }

private:
    void updateDamping() noexcept
    {
        invSqrtN = 1.0f / std::sqrt ((float) n);
        for (int k = 0; k < n; ++k)
        {
            g[k] = std::pow (10.0f, -3.0f * L0[k] / (sr * decay));
            g[k] = std::min (g[k], 0.9995f);
            float av = -(1.0f - hf) / (1.0f + hf) * 0.9f;
            a[k] = std::max (av, -0.88f);
        }
    }

    DelayLine line[kMaxStrings];
    DCBlocker dc[kMaxStrings];
    DenormalDither dith;
    float f0[kMaxStrings] {}, L0[kMaxStrings] {}, g[kMaxStrings] {}, a[kMaxStrings] {};
    float lpz[kMaxStrings] {}, phase[kMaxStrings] {};
    float sr = 48000.0f, decay = 4.0f, hf = 0.22f, drift = 0.35f, dw = 0.0f;
    float invSqrtN = 0.3f;
    int n = 10;
};

/** Строит частоты симпатических струн из тональности. */
inline int buildScaleTuning (int root, bool isMinor, int loMidi, int hiMidi,
                             int wanted, float* out) noexcept
{
    static const int maj[7] = { 0, 2, 4, 5, 7, 9, 11 };
    static const int min_[7] = { 0, 2, 3, 5, 7, 8, 10 };
    const int* sc = isMinor ? min_ : maj;

    int pool[64], np = 0;
    for (int m = loMidi; m <= hiMidi && np < 64; ++m)
    {
        const int pc = ((m - root) % 12 + 12) % 12;
        for (int i = 0; i < 7; ++i)
            if (pc == sc[i]) { pool[np++] = m; break; }
    }
    if (np == 0) return 0;

    const int cnt = std::min (wanted, std::min (np, SympatheticField::kMaxStrings));
    for (int i = 0; i < cnt; ++i)
    {
        const int idx = (cnt == 1) ? 0 : (int) std::lround ((double) i * (np - 1) / (cnt - 1));
        out[i] = midiToHz ((float) pool[idx]);
    }
    return cnt;
}

} // namespace husk
