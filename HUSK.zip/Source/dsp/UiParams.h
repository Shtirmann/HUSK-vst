#pragma once
#include "HuskEngine.h"

namespace husk
{

/** Значения ровно в том виде, в каком они стоят на ручках. Единственный
    источник правды для маппинга «интерфейс → движок»: им пользуются и плагин,
    и офлайн-рендер, и таблица пресетов. */
struct UiParams
{
    float split        = 0.55f;
    float cross        = 0.00f;
    float husk         = 1.00f;

    float bodyshape    = 0.25f;
    int   bodymodes    = 18;
    float bodydecay    = 2.00f;
    float bodybright   = 0.50f;
    float bodypos      = 0.26f;
    float bodyamt      = 1.00f;
    int   bodytune     = 0;        // 0 Follow, 1 Key, 2 Fixed
    float bodyfixed    = 110.0f;

    float fieldamt     = 0.70f;
    float fielddecay   = 5.00f;
    float fielddamp    = 0.20f;
    int   fieldstrings = 10;
    float drift        = 0.40f;

    float airamt       = 0.35f;
    float airsize      = 1.00f;
    float airbloom     = 0.82f;
    float airdamp      = 0.45f;
    float airdrive     = 0.12f;
    bool  freeze       = false;

    float mix          = 0.50f;
    float outputDb     = 0.00f;
};

inline float dbToGain (float db) noexcept { return std::pow (10.0f, db / 20.0f); }

inline Parameters toEngine (const UiParams& u) noexcept
{
    Parameters p;
    p.split      = u.split;
    p.cross      = u.cross;
    p.huskGain   = u.husk;

    p.bodyShape  = u.bodyshape;
    p.bodyModes  = u.bodymodes;
    p.bodyDecay  = u.bodydecay;
    p.bodyBright = u.bodybright;
    p.bodyPos    = 0.02f + 0.96f * u.bodypos;
    p.bodyAmt    = u.bodyamt;
    p.bodyTuneMode = u.bodytune;
    p.bodyFixedHz  = u.bodyfixed;
    // нижняя граница T60 мод привязана к яркости: чем ярче, тем короче можно,
    // но никогда не настолько, чтобы банк превратился в шумовой фильтр
    p.bodyT60Min = 0.14f - 0.06f * u.bodybright;
    p.bodyTilt   = 1.1f;

    p.fieldAmt     = u.fieldamt;
    p.fieldDecay   = u.fielddecay;
    p.fieldDamp    = 0.05f + 0.6f * u.fielddamp;
    p.fieldStrings = u.fieldstrings;
    p.drift        = u.drift;

    p.airAmt   = u.airamt;
    p.airSize  = u.airsize;
    p.airBloom = u.airbloom;
    p.airDamp  = u.airdamp;
    p.airDrive = u.airdrive;
    p.freeze   = u.freeze;

    p.mix     = u.mix;
    p.outGain = dbToGain (u.outputDb);
    return p;
}

} // namespace husk
