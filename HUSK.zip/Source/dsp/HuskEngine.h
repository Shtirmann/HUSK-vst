#pragma once
#include "Utils.h"
#include "Analysis.h"
#include "ModalBank.h"
#include "SympatheticField.h"
#include "FDN8.h"
#include <atomic>

namespace husk
{

struct Parameters
{
    // разбор
    float split      = 0.55f;  // 0 = движки питает CORE, 1 = HUSK
    float cross      = 0.0f;   // обмен адресами движков
    float huskGain   = 1.0f;
    // тело
    float bodyShape  = 0.25f;  // струна → труба → брусок → пластина
    float bodyDecay  = 2.0f;   // сек
    float bodyT60Min = 0.09f;
    int   bodyModes  = 18;
    float bodyBright = 0.50f;
    float bodyPos    = 0.26f;
    float bodyTilt   = 1.1f;
    float bodyAmt    = 1.0f;
    int   bodyTuneMode = 0;    // 0 = FOLLOW, 1 = KEY, 2 = FIXED
    float bodyFixedHz = 110.0f;
    // поле
    float fieldAmt   = 0.7f;
    float fieldDecay = 5.0f;
    float fieldDamp  = 0.20f;
    int   fieldStrings = 10;
    float drift      = 0.4f;
    // воздух
    float airAmt     = 0.35f;
    float airSize    = 1.0f;
    float airBloom   = 0.82f;
    float airDamp    = 0.45f;
    float airDrive   = 0.12f;
    bool  freeze     = false;
    // выход
    float mix        = 0.5f;
    float outGain    = 1.0f;
};

/** Снимок состояния для интерфейса. Пишется в аудио-потоке раз в блок,
    читается таймером редактора. Согласованность — через seqlock: писатель
    поднимает счётчик до и после записи, читатель повторяет чтение, если
    счётчик нечётный или изменился. Ни блокировок, ни аллокаций. */
struct VisualState
{
    float f0 = 110.0f;
    int   keyRoot = 0;
    bool  keyMinor = false;
    float transient = 0.0f;

    int   numModes = 0;
    float modeHz[ModalBank::kMaxModes] {};
    float modeAmp[ModalBank::kMaxModes] {};

    int   numStrings = 0;
    float stringHz[SympatheticField::kMaxStrings] {};

    float huskLevel = 0.0f, coreLevel = 0.0f;
    float bodyLevel = 0.0f, fieldLevel = 0.0f, outLevel = 0.0f;
};

/** Полный тракт HUSK. Аудио-путь целиком во временной области:
    латентность 0 сэмплов. Анализ живёт в control-пути и «опаздывает». */
class Engine
{
public:
    static constexpr int kCtrlInterval = 32;   // пересчёт коэффициентов

    void prepare (double sampleRate, int /*maxBlock*/)
    {
        sr = (float) sampleRate;
        inDC.prepare (sampleRate, 18.0);
        outDCL.prepare (sampleRate, 22.0);
        outDCR.prepare (sampleRate, 22.0);
        huskHP.prepare (sampleRate, 150.0f);
        fieldHP.prepare (sampleRate, 95.0f);

        transient.prepare (sampleRate);
        ale.prepare (320, 4, 0.06f);
        pitch.prepare (sampleRate);
        key.prepare (sampleRate);

        body.prepare (sampleRate);
        field.prepare (sampleRate);
        air.prepare (sampleRate);

        gateEnv.prepare (sampleRate, 0.0005f, 0.030f);
        nfDown = 1.0f - std::exp (-1.0f / (0.5f * (float) sampleRate));
        nfUp   = 1.0f - std::exp (-1.0f / (15.0f * (float) sampleRate));
        refRms.prepare (sampleRate, 0.5f);
        huskAG.prepare  (sampleRate, 0.4f, 0.15f, 12.0f);
        coreAG.prepare  (sampleRate, 0.4f, 0.15f, 4.0f);
        bodyAG.prepare  (sampleRate, 0.5f, 0.20f, 48.0f);
        fieldAG.prepare (sampleRate, 0.5f, 0.20f, 48.0f);
        wetAG.prepare   (sampleRate, 0.5f, 0.20f, 12.0f);

        f0Smooth.prepare (sampleRate, 0.020f, 110.0f);
        peakEnv.prepare (sampleRate, 0.001f, 0.150f);

        reset();
        applyParams (true);
    }

    void reset() noexcept
    {
        inDC.reset(); outDCL.reset(); outDCR.reset();
        huskHP.reset(); fieldHP.reset();
        transient.reset(); ale.reset(); pitch.reset(); key.reset();
        body.reset(); field.reset(); air.reset();
        gateEnv.reset(); ctrlCount = 0; noiseFloor = 1.0e-4f;
    }

    void setParameters (const Parameters& np) noexcept { p = np; dirty = true; }
    const Parameters& getParameters() const noexcept { return p; }

    int  getKeyRoot()  const noexcept { return key.getRoot(); }
    bool getKeyMinor() const noexcept { return key.getIsMinor(); }
    float getTrackedF0() const noexcept { return f0Smooth.value(); }
    float getTransientness() const noexcept { return lastT; }

    /** Читается из message thread. Возвращает false, если снимок не удалось
        получить целиком за разумное число попыток (в UI просто рисуем прошлый). */
    bool readVisualState (VisualState& dest) const noexcept
    {
        for (int attempt = 0; attempt < 8; ++attempt)
        {
            const uint32_t a = visSeq.load (std::memory_order_acquire);
            if ((a & 1u) != 0u) continue;
            dest = vis;
            std::atomic_thread_fence (std::memory_order_acquire);
            if (visSeq.load (std::memory_order_relaxed) == a) return true;
        }
        return false;
    }

    void process (const float* in, float* outL, float* outR, int numSamples) noexcept
    {
        if (dirty) applyParams (false);

        // трекер высоты: работа размазана по блоку, без пика на границе кадра
        pitch.advance (std::max (4, numSamples / 2));

        for (int i = 0; i < numSamples; ++i)
        {
            const float dry = in[i];              // сухой путь не трогаем вообще
            const float ana = inDC.process (dry);  // анализ и wet — с DC-блокером

            // ---- анализ
            pitch.pushSample (ana);
            key.pushSample (ana);
            const float T = transient.process (ana);
            lastT = T;

            float resid = 0.0f;
            const float tonal = ale.process (ana, resid);

            // гейт по огибающей: стационарный шумовой пол не должен становиться
            // «шелухой», иначе плагин действительно превратится в усилитель шипения
            const float env = gateEnv.process (ana);
            // Оценка шумового пола асимметрична: вниз идём за минутой тишины
            // быстро (~0.5 с), вверх — очень медленно (~15 с). Симметричное
            // сглаживание здесь смертельно: порог начинает ездить за самим
            // сигналом, и гейт не открывается никогда.
            noiseFloor += (env < noiseFloor ? nfDown : nfUp) * (env - noiseFloor);
            const float thr = 4.0f * noiseFloor + 1.0e-6f;
            float gate = (env - thr) / (thr + 1.0e-9f);
            gate = std::clamp (gate, 0.0f, 1.0f);
            gate = gate * gate * (3.0f - 2.0f * gate);

            const float Tg = std::pow (T, 1.4f);
            const float husk = huskHP.process (resid) * Tg * gate * p.huskGain;
            const float core = tonal * gate;

            // ---- нормировка слоёв (makeup ограничен сверху)
            const float ref = std::max (refRms.process (ana), 1.0e-5f);
            const bool adapt = gate > 0.5f;     // подстраиваемся только пока играют
            const float hN  = huskAG.process (husk, ref, adapt);
            const float cN  = coreAG.process (core, ref, adapt);

            // ---- маршрутизация
            const float a = p.split, c = p.cross;
            const float srcA = (1.0f - a) * cN + a * hN;
            const float srcB = a * cN + (1.0f - a) * hN;
            const float excBody  = (1.0f - c) * srcA + c * srcB;
            const float excField = fieldHP.process ((1.0f - c) * srcB + c * srcA);

            // ---- control-rate: перестройка резонаторов
            if (--ctrlCount <= 0)
            {
                ctrlCount = kCtrlInterval;
                updateTuning();
            }

            // ---- движки
            const float b = bodyAG.process  (body.process (excBody * 0.9f), ref, adapt);
            const float f = fieldAG.process (field.process (excField), ref, adapt);
            feedMeter (meterHusk, hN);
            feedMeter (meterCore, cN);
            feedMeter (meterBody, b * p.bodyAmt);
            feedMeter (meterField, f * p.fieldAmt);

            float wet = wetAG.process (p.bodyAmt * b + p.fieldAmt * f, ref, adapt);

            float wl = wet, wr = wet;
            if (p.airAmt > 0.001f || p.freeze)
            {
                float al = 0.0f, ar = 0.0f;
                air.process (wet, al, ar);
                const float m = p.freeze ? 1.0f : p.airAmt;
                wl = (1.0f - m) * wet + m * al;
                wr = (1.0f - m) * wet + m * ar;
            }
            // лёгкая стереодекорреляция самих движков
            wl = 0.84f * wl + 0.16f * b * p.bodyAmt;
            wr = 0.84f * wr + 0.16f * f * p.fieldAmt;

            wl = outDCL.process (wl);
            wr = outDCR.process (wr);

            float yl = (1.0f - p.mix) * dry + p.mix * wl * 0.9f;
            float yr = (1.0f - p.mix) * dry + p.mix * wr * 0.9f;
            yl *= p.outGain;
            yr *= p.outGain;

            // мягкий лимитер на выходе
            const float pk = peakEnv.process (std::max (std::fabs (yl), std::fabs (yr)));
            if (pk > 0.9f)
            {
                const float g = 0.9f / pk;
                yl *= g; yr *= g;
            }
            outL[i] = softClip (yl);
            outR[i] = softClip (yr);
            feedMeter (meterOut, outL[i]);
        }

        publishVisualState();

        // страховка раз в блок, а не на сэмпл
        body.checkAndRepair();
        field.checkAndRepair();
        air.checkAndRepair();
        for (int i = 0; i < numSamples; ++i)
            if (isBad (outL[i]) || isBad (outR[i])) { outL[i] = outR[i] = 0.0f; }
    }

private:
    void publishVisualState() noexcept
    {
        visSeq.fetch_add (1u, std::memory_order_release);
        std::atomic_thread_fence (std::memory_order_release);

        vis.f0 = f0Smooth.value();
        vis.keyRoot = key.getRoot();
        vis.keyMinor = key.getIsMinor();
        vis.transient = lastT;

        const int nm = body.visCount();
        vis.numModes = nm;
        for (int k = 0; k < nm; ++k) { vis.modeHz[k] = body.visFreq (k); vis.modeAmp[k] = body.visAmplitude (k); }

        const int ns = field.numStrings();
        vis.numStrings = ns;
        for (int k = 0; k < ns; ++k) vis.stringHz[k] = field.stringFreq (k);

        vis.huskLevel  = meterHusk;
        vis.coreLevel  = meterCore;
        vis.bodyLevel  = meterBody;
        vis.fieldLevel = meterField;
        vis.outLevel   = meterOut;

        std::atomic_thread_fence (std::memory_order_release);
        visSeq.fetch_add (1u, std::memory_order_release);
    }

    static inline void feedMeter (float& m, float x) noexcept
    {
        const float a = std::fabs (x);
        m = (a > m) ? a : m * 0.9995f;
    }

    /** Медленная оценка RMS. */
    class RmsFollower
    {
    public:
        void prepare (double sr, float tau) noexcept
        {
            a = std::exp (-1.0f / (tau * (float) sr));
            e = 1.0e-6f;
        }
        inline float process (float x) noexcept
        {
            e = a * e + (1.0f - a) * (x * x);
            return std::sqrt (e);
        }
    private:
        float a = 0.999f, e = 1.0e-6f;
    };

    /** Приведение уровня ветви к опорному. Сам коэффициент сглаживается,
        иначе на входе/выходе нот слышно «дыхание» усиления. */
    class AutoGain
    {
    public:
        void prepare (double sr, float tauRms, float tauGain, float maxGain) noexcept
        {
            rms.prepare (sr, tauRms);
            aG = std::exp (-1.0f / (tauGain * (float) sr));
            gMax = maxGain;
            g = 1.0f;
        }
        /** adapt = false замораживает коэффициент. Без этого автогейн в паузах
            и на хвостах вытягивает шумовой пол наверх, и весь эффект начинает
            звучать как шипящее пятно. */
        inline float process (float x, float ref, bool adapt) noexcept
        {
            const float r = rms.process (x);
            if (adapt)
            {
                float t = ref / (r + 1.0e-7f);
                t = std::clamp (t, 0.02f, gMax);
                g = aG * g + (1.0f - aG) * t;
            }
            return x * g;
        }
        float gain() const noexcept { return g; }
    private:
        RmsFollower rms;
        float aG = 0.999f, g = 1.0f, gMax = 32.0f;
    };

    void applyParams (bool force) noexcept
    {
        dirty = false;
        body.setShape (p.bodyShape);
        body.setTone (p.bodyModes, p.bodyDecay, p.bodyT60Min, p.bodyBright,
                      p.bodyPos, p.bodyTilt);
        field.setDamping (p.fieldDecay, p.fieldDamp);
        field.setDrift (p.drift, 0.17f);
        air.setSize (p.airSize);
        air.setFeedback (p.airBloom);
        air.setDamping (p.airDamp);
        air.setDrive (p.airDrive);
        air.setFreeze (p.freeze);
        if (force) { lastRoot = -1; lastStrings = -1; }
    }

    /** Квантование в лад: резонаторы не должны «вылизывать» глиссандо
        за питч-трекером, иначе получается вау-эффект. */
    float quantizeToScale (float hz) const noexcept
    {
        bool inScale[12];
        key.getScaleMask (inScale);
        const float m = hzToMidi (hz);
        const int nearest = (int) std::lround (m);
        int best = nearest;
        float bestD = 1.0e9f;
        for (int d = -3; d <= 3; ++d)
        {
            const int c = nearest + d;
            if (inScale[((c % 12) + 12) % 12])
            {
                const float dist = std::fabs ((float) c - m);
                if (dist < bestD) { bestD = dist; best = c; }
            }
        }
        return midiToHz ((float) best);
    }

    void updateTuning() noexcept
    {
        // строй симпатических струн — из определённой тональности
        const int root = key.getRoot();
        const bool mi = key.getIsMinor();
        if (root != lastRoot || mi != lastMinor || p.fieldStrings != lastStrings)
        {
            lastRoot = root; lastMinor = mi; lastStrings = p.fieldStrings;
            float f[SympatheticField::kMaxStrings];
            const int cnt = buildScaleTuning (root, mi, 45, 81, p.fieldStrings, f);
            if (cnt > 0) field.setTuning (f, cnt);
        }

        // высота модального тела
        float target = p.bodyFixedHz;
        if (p.bodyTuneMode == 0)
        {
            if (pitch.getConfidence() > 0.70f) heldF0 = pitch.getF0();
            target = quantizeToScale (heldF0);
        }
        else if (p.bodyTuneMode == 1)
        {
            target = midiToHz ((float) (36 + root));  // тоника, C2-октава
        }
        f0Smooth.setTarget (target);
        for (int i = 0; i < kCtrlInterval; ++i) f0Smooth.next();
        body.updateCoeffs (f0Smooth.value());
    }

    Parameters p;
    bool dirty = true;

    DCBlocker inDC, outDCL, outDCR;
    OnePoleHP huskHP, fieldHP;
    TransientDetector transient;
    AdaptiveLineEnhancer ale;
    PitchTracker pitch;
    KeyFollower key;
    ModalBank body;
    SympatheticField field;
    FDN8 air;

    EnvFollower gateEnv, peakEnv;
    RmsFollower refRms;
    AutoGain huskAG, coreAG, bodyAG, fieldAG, wetAG;
    Smoothed f0Smooth;

    VisualState vis;
    mutable std::atomic<uint32_t> visSeq { 0 };
    float meterHusk = 0.0f, meterCore = 0.0f, meterBody = 0.0f,
          meterField = 0.0f, meterOut = 0.0f;
    float sr = 48000.0f, noiseFloor = 1.0e-4f, heldF0 = 110.0f, lastT = 0.0f;
    float nfDown = 0.0f, nfUp = 0.0f;
    int ctrlCount = 0, lastRoot = -1, lastStrings = -1;
    bool lastMinor = false;
};

} // namespace husk
