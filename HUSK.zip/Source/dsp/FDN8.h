#pragma once
#include "Utils.h"

namespace husk
{

/** Восьмиканальная FDN с матрицей Хаусхолдера.

    A = I − (2/N)·u·uᵀ считается как σ = (2/N)Σs; out_i = s_i − σ, то есть
    2N−1 сложений и ни одного умножения. Householder выбран для петли, а не
    Hadamard: Hadamard перемешивает слишком сильно, линии «слипаются» и сеть
    начинает звучать как один резонатор.

    Длины линий взаимно простые — иначе моды совпадают и появляется
    металлический звон. Модуляция обязательна: без неё сеть звенит на
    собственных модах. Насыщение стоит ПОСЛЕ фильтра потерь, чтобы гармоники
    нелинейности были уже band-limited.
*/
class FDN8
{
public:
    static constexpr int N = 8;

    void prepare (double sampleRate)
    {
        sr = (float) sampleRate;
        // взаимно простые в сэмплах при 48 кГц, в секундах — для любого sr
        static const float base[N] = { 0.0431f, 0.0537f, 0.0669f, 0.0761f,
                                       0.0893f, 0.1039f, 0.1181f, 0.1327f };
        const int maxLen = (int) (0.1327f * 2.5f * sr) + 256;
        for (int i = 0; i < N; ++i)
        {
            secs[i] = base[i];
            line[i].prepare (maxLen);
            dc[i].prepare (sampleRate, 15.0);
            phase[i] = 0.7854f * (float) i;
            lpz[i] = 0.0f;
        }
        setSize (1.0f);
        setDamping (0.45f);
        setModulation (1.0f, 0.13f);
        reset();
    }

    void reset() noexcept
    {
        for (int i = 0; i < N; ++i) { line[i].reset(); dc[i].reset(); lpz[i] = 0.0f; }
    }

    void setSize (float size) noexcept
    {
        sizeAmt = std::clamp (size, 0.15f, 2.5f);
        for (int i = 0; i < N; ++i)
            len[i] = std::max (32.0f, secs[i] * sizeAmt * sr);
    }

    void setFeedback (float fb) noexcept { feedback = std::clamp (fb, 0.0f, 0.995f); }

    void setDamping (float d) noexcept
    {
        const float fc = 500.0f + 9000.0f * (1.0f - std::clamp (d, 0.0f, 1.0f));
        ap = std::exp (-2.0f * kPi * fc / sr);
    }

    void setDrive (float d) noexcept { drive = std::clamp (d, 0.0f, 1.0f); }

    void setModulation (float depth, float rateHz) noexcept
    {
        modDepth = std::clamp (depth, 0.0f, 2.0f);
        dw = 2.0f * kPi * rateHz / sr;
    }

    /** Freeze: вход отключается, потери убираются точно в единицу.
        Это безопаснее, чем feedback = 0.9999. */
    void setFreeze (bool f) noexcept { frozen = f; }

    inline void process (float x, float& outL, float& outR) noexcept
    {
        float s[N];
        for (int i = 0; i < N; ++i)
        {
            phase[i] += dw * (0.7f + 0.09f * (float) i);
            if (phase[i] > 6.2831853f) phase[i] -= 6.2831853f;
            const float d = len[i] + modDepth * sr * 0.0004f * std::sin (phase[i]);
            s[i] = line[i].readHermite (d);
        }

        float sum = 0.0f;
        for (int i = 0; i < N; ++i) sum += s[i];
        sum *= 2.0f / (float) N;

        const float fb = frozen ? 1.0f : feedback;
        const float inGain = frozen ? 0.0f : 0.35f;

        for (int i = 0; i < N; ++i)
        {
            float v = (s[i] - sum) * fb;
            lpz[i] = (1.0f - ap) * v + ap * lpz[i];
            v = lpz[i];
            if (drive > 0.0f && ! frozen)
            {
                const float k = 1.0f + 3.0f * drive;
                v = std::tanh (v * k) / k;
            }
            v = dc[i].process (v) + x * inGain + dith.next();
            line[i].write (v);
        }

        float l = 0.0f, r = 0.0f;
        for (int i = 0; i < N; ++i) (i % 2 == 0 ? l : r) += s[i];
        outL = l * 0.5f;
        outR = r * 0.5f;
    }

    bool checkAndRepair() noexcept
    {
        for (int i = 0; i < N; ++i)
            if (isBad (lpz[i]) || std::fabs (lpz[i]) > 1.0e6f) { reset(); return false; }
        return true;
    }

private:
    DelayLine line[N];
    DCBlocker dc[N];
    DenormalDither dith;
    float secs[N] {}, len[N] {}, lpz[N] {}, phase[N] {};
    float sr = 48000.0f, feedback = 0.82f, ap = 0.5f, drive = 0.15f;
    float modDepth = 1.0f, dw = 0.0f, sizeAmt = 1.0f;
    bool frozen = false;
};

} // namespace husk
