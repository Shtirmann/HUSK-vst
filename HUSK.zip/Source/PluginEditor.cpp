#include "PluginEditor.h"

using namespace juce;

namespace hcol
{
    const Colour bg       { 0xff100d0b };
    const Colour panel    { 0xff191412 };
    const Colour panelHi  { 0xff1f1917 };
    const Colour line     { 0xff2e2622 };
    const Colour lineSoft { 0xff231d1a };
    const Colour text     { 0xffcbb9a6 };
    const Colour dim      { 0xff8a7768 };
    const Colour faint    { 0xff5b4d44 };
    const Colour warm     { 0xffe0913f };   // HUSK / BODY
    const Colour warmDim  { 0xff8a5828 };
    const Colour cool     { 0xff74b3a8 };   // CORE / FIELD
    const Colour coolDim  { 0xff3f665f };
}

namespace
{
    Font uiFont (float h, bool bold = false)
    {
        auto o = FontOptions (h);
        return Font (bold ? o.withStyle ("Bold") : o);
    }

    /** Заголовки секций — вразрядку. JUCE не умеет letter-spacing, рисуем сами. */
    void drawTracked (Graphics& g, const String& s, Rectangle<int> area,
                      float size, float tracking)
    {
        g.setFont (uiFont (size, true));
        float x = (float) area.getX();
        const float y = (float) area.getY();
        const float h = (float) area.getHeight();
        for (int i = 0; i < s.length(); ++i)
        {
            const String ch = s.substring (i, i + 1);
            g.drawText (ch, (int) x, (int) y, 20, (int) h, Justification::centredLeft, false);
            x += g.getCurrentFont().getStringWidthFloat (ch) + tracking;
        }
    }

    float hzToMidiUi (float hz) noexcept
    {
        return 69.0f + 12.0f * std::log2 (jmax (hz, 1.0f) / 440.0f);
    }

    float logPos (float hz, float lo, float hi) noexcept
    {
        return jlimit (0.0f, 1.0f, std::log (jmax (hz, 1.0f) / lo) / std::log (hi / lo));
    }
}

// ============================================================================
HuskLookAndFeel::HuskLookAndFeel()
{
    setColour (ResizableWindow::backgroundColourId, hcol::bg);
    setColour (Label::textColourId,                 hcol::text);
    setColour (ComboBox::backgroundColourId,        hcol::panelHi);
    setColour (ComboBox::textColourId,              hcol::text);
    setColour (ComboBox::outlineColourId,           hcol::line);
    setColour (ComboBox::arrowColourId,             hcol::dim);
    setColour (PopupMenu::backgroundColourId,       hcol::panel);
    setColour (PopupMenu::textColourId,             hcol::text);
    setColour (PopupMenu::highlightedBackgroundColourId, hcol::warmDim.withAlpha (0.45f));
    setColour (PopupMenu::highlightedTextColourId,  Colours::white);
    setColour (PopupMenu::headerTextColourId,       hcol::dim);
    setColour (TooltipWindow::backgroundColourId,   hcol::panel);
    setColour (TooltipWindow::textColourId,         hcol::text);
    setColour (TooltipWindow::outlineColourId,      hcol::line);
    setColour (AlertWindow::backgroundColourId,     hcol::panel);
    setColour (AlertWindow::textColourId,           hcol::text);
    setColour (AlertWindow::outlineColourId,        hcol::line);
    setColour (TextEditor::backgroundColourId,      hcol::bg);
    setColour (TextEditor::textColourId,            hcol::text);
    setColour (TextEditor::outlineColourId,         hcol::line);
    setColour (TextEditor::highlightColourId,       hcol::warmDim);
}

Font HuskLookAndFeel::getComboBoxFont (ComboBox&)  { return uiFont (12.5f); }
Font HuskLookAndFeel::getPopupMenuFont()           { return uiFont (13.5f); }

void HuskLookAndFeel::drawRotarySlider (Graphics& g, int x, int y, int w, int h,
                                        float pos, float a0, float a1, Slider& s)
{
    const auto b = Rectangle<int> (x, y, w, h).toFloat();
    const auto c = b.getCentre();
    // Дуга рисуется ВНУТРИ отведённого прямоугольника: если считать радиус от
    // корпуса и добавлять к нему отступ, дуга уходит за края компонента и её
    // срезает клип. Поэтому сначала внешний радиус, потом всё остальное внутрь.
    const bool master = (bool) s.getProperties().getWithDefault ("master", false);
    const float outer = jmin (b.getWidth(), b.getHeight()) * 0.5f - 1.0f;
    const float arcR  = outer - 2.0f;
    const float bodyR = arcR - 6.0f;
    const float angle = a0 + pos * (a1 - a0);
    const Colour accent = s.findColour (Slider::rotarySliderFillColourId);

    g.setGradientFill (ColourGradient (hcol::panelHi.brighter (0.16f), c.x, c.y - bodyR,
                                       hcol::panel.darker (0.35f),     c.x, c.y + bodyR, false));
    g.fillEllipse (c.x - bodyR, c.y - bodyR, bodyR * 2.0f, bodyR * 2.0f);
    g.setColour (hcol::line);
    g.drawEllipse (c.x - bodyR, c.y - bodyR, bodyR * 2.0f, bodyR * 2.0f, 1.0f);

    Path track;
    track.addCentredArc (c.x, c.y, arcR, arcR, 0.0f, a0, a1, true);
    g.setColour (hcol::lineSoft.brighter (0.18f));
    g.strokePath (track, PathStrokeType (2.0f, PathStrokeType::curved, PathStrokeType::rounded));

    // предупреждающий сектор (BLOOM у края самовозбуждения)
    const auto danger = s.getProperties().getWithDefault ("danger", var());
    if (! danger.isVoid())
    {
        const float d = jlimit (0.0f, 1.0f, (float) (double) danger);
        Path warn;
        warn.addCentredArc (c.x, c.y, arcR, arcR, 0.0f, a0 + d * (a1 - a0), a1, true);
        g.setColour (Colour (0xffb4472e).withAlpha (0.55f));
        g.strokePath (warn, PathStrokeType (2.0f, PathStrokeType::curved, PathStrokeType::rounded));
    }

    if (pos > 0.001f)
    {
        Path val;
        val.addCentredArc (c.x, c.y, arcR, arcR, 0.0f, a0, angle, true);
        g.setColour (accent.withAlpha (s.isEnabled() ? 0.95f : 0.4f));
        g.strokePath (val, PathStrokeType (master ? 4.4f : 3.0f,
                                           PathStrokeType::curved, PathStrokeType::rounded));
    }

    if (master)
    {
        g.setColour (accent.withAlpha (0.22f));
        g.drawEllipse (c.x - bodyR - 2.5f, c.y - bodyR - 2.5f,
                       (bodyR + 2.5f) * 2.0f, (bodyR + 2.5f) * 2.0f, 1.0f);
    }

    Path ptr;
    ptr.startNewSubPath (c.x, c.y - bodyR * 0.26f);
    ptr.lineTo (c.x, c.y - bodyR * 0.88f);
    g.setColour (hcol::text.withAlpha (0.85f));
    g.strokePath (ptr, PathStrokeType (1.8f, PathStrokeType::curved, PathStrokeType::rounded),
                  AffineTransform::rotation (angle, c.x, c.y));
}

void HuskLookAndFeel::drawLinearSlider (Graphics& g, int x, int y, int w, int h,
                                        float pos, float, float,
                                        Slider::SliderStyle, Slider& s)
{
    const auto b = Rectangle<float> ((float) x, (float) y, (float) w, (float) h);
    const float cy = b.getCentreY();
    const auto track = Rectangle<float> (b.getX(), cy - 3.0f, b.getWidth(), 6.0f);

    g.setColour (hcol::bg);
    g.fillRoundedRectangle (track, 3.0f);
    g.setColour (hcol::line);
    g.drawRoundedRectangle (track, 3.0f, 1.0f);

    // заливка от центра к текущему положению — так «баланс» читается лучше,
    // чем классическая заливка слева
    const float px = jlimit (b.getX(), b.getRight(), pos);
    const float mid = b.getCentreX();
    auto fill = Rectangle<float> (jmin (mid, px), cy - 3.0f, std::fabs (px - mid), 6.0f);
    g.setColour (s.findColour (Slider::trackColourId).withAlpha (0.75f));
    g.fillRoundedRectangle (fill, 3.0f);

    g.setColour (hcol::faint);
    g.fillRect (mid - 0.5f, cy - 7.0f, 1.0f, 14.0f);

    g.setColour (hcol::text);
    g.fillEllipse (px - 6.0f, cy - 6.0f, 12.0f, 12.0f);
    g.setColour (hcol::bg);
    g.fillEllipse (px - 3.0f, cy - 3.0f, 6.0f, 6.0f);
}

void HuskLookAndFeel::drawComboBox (Graphics& g, int w, int h, bool,
                                    int, int, int, int, ComboBox&)
{
    auto b = Rectangle<float> (0.0f, 0.0f, (float) w, (float) h).reduced (0.5f);
    g.setColour (hcol::panelHi);
    g.fillRoundedRectangle (b, 3.0f);
    g.setColour (hcol::line);
    g.drawRoundedRectangle (b, 3.0f, 1.0f);

    Path a;
    const float cx = (float) w - 14.0f, cy = (float) h * 0.5f;
    a.startNewSubPath (cx - 4.0f, cy - 2.0f);
    a.lineTo (cx, cy + 2.5f);
    a.lineTo (cx + 4.0f, cy - 2.0f);
    g.setColour (hcol::dim);
    g.strokePath (a, PathStrokeType (1.4f, PathStrokeType::curved, PathStrokeType::rounded));
}

void HuskLookAndFeel::drawButtonBackground (Graphics& g, Button& b, const Colour&,
                                            bool over, bool down)
{
    auto r = b.getLocalBounds().toFloat().reduced (0.5f);
    const bool on = b.getToggleState();
    g.setColour (on ? hcol::warm.withAlpha (0.85f)
                    : (down ? hcol::panelHi.brighter (0.10f)
                            : (over ? hcol::panelHi.brighter (0.05f) : hcol::panelHi)));
    g.fillRoundedRectangle (r, 3.0f);
    g.setColour (on ? hcol::warm : hcol::line);
    g.drawRoundedRectangle (r, 3.0f, 1.0f);
}

void HuskLookAndFeel::drawButtonText (Graphics& g, TextButton& b, bool over, bool)
{
    g.setFont (uiFont (11.0f, true));
    g.setColour (b.getToggleState() ? hcol::bg : (over ? hcol::text : hcol::dim));
    g.drawText (b.getButtonText(), b.getLocalBounds(), Justification::centred, false);
}

// ============================================================================
Knob::Knob (AudioProcessorValueTreeState& state, const String& paramID,
            const String& cap, bool large, Colour ac)
    : caption (cap), big (large), accent (ac)
{
    slider.setSliderStyle (Slider::RotaryHorizontalVerticalDrag);
    slider.setTextBoxStyle (Slider::NoTextBox, false, 0, 0);
    slider.setColour (Slider::rotarySliderFillColourId, accent);
    if (large) slider.getProperties().set ("master", true);
    slider.setRotaryParameters (MathConstants<float>::pi * 1.25f,
                                MathConstants<float>::pi * 2.75f, true);
    slider.setVelocityBasedMode (false);
    addAndMakeVisible (slider);
    slider.addMouseListener (this, true);
    att = std::make_unique<AudioProcessorValueTreeState::SliderAttachment> (state, paramID, slider);
}

void Knob::resized()
{
    auto b = getLocalBounds();
    b.removeFromBottom (kCaptionH);
    const int d = jmin (b.getWidth(), b.getHeight());
    slider.setBounds (b.withSizeKeepingCentre (d, d));
}

void Knob::paint (Graphics& g)
{
    const bool showValue = hover || slider.isMouseButtonDown();
    auto strip = getLocalBounds().removeFromBottom (kCaptionH);
    g.setFont (uiFont (showValue ? 11.0f : 9.5f, ! showValue));
    g.setColour (showValue ? accent.brighter (0.25f) : hcol::dim);
    g.drawText (showValue ? slider.getTextFromValue (slider.getValue()) : caption,
                strip, Justification::centred, false);
}


// ============================================================================
/** Отрисовка «говорящих» регуляторов. Реализована как LookAndFeel одного
    конкретного слайдера: вся мышиная логика, шаги, автоматизация и правый клик
    остаются штатными. */
class Strip::StripLnf : public LookAndFeel_V4
{
public:
    StripLnf (Strip::Kind k, Colour a) : kind (k), accent (a) {}

    void drawLinearSlider (Graphics& g, int x, int y, int w, int h,
                           float pos, float, float, Slider::SliderStyle, Slider& s) override
    {
        auto b = Rectangle<float> ((float) x, (float) y, (float) w, (float) h);
        const double v01 = s.getRange().getLength() > 0.0
                         ? (s.getValue() - s.getMinimum()) / s.getRange().getLength() : 0.0;
        const float t = (float) v01;
        ignoreUnused (pos);

        g.setColour (hcol::bg);
        g.fillRoundedRectangle (b, 3.0f);
        g.setColour (hcol::line);
        g.drawRoundedRectangle (b.reduced (0.5f), 3.0f, 1.0f);
        b = b.reduced (8.0f, 6.0f);

        switch (kind)
        {
            case Strip::Kind::Morph:   drawMorph (g, b, t);   break;
            case Strip::Kind::Density: drawDensity (g, b, s); break;
            case Strip::Kind::Pluck:   drawPluck (g, b, t);   break;
            case Strip::Kind::Steps:   drawSteps (g, b, s);   break;
        }
    }

private:
    /** Четыре формы объекта: струна, труба, брусок, пластина. */
    void drawMorph (Graphics& g, Rectangle<float> b, float t)
    {
        const float cy = b.getCentreY();
        g.setColour (hcol::lineSoft.brighter (0.2f));
        g.fillRect (b.getX(), cy + b.getHeight() * 0.32f, b.getWidth(), 1.0f);

        for (int i = 0; i < 4; ++i)
        {
            const float f = (float) i / 3.0f;
            const float cx = b.getX() + b.getWidth() * (0.11f + 0.78f * f);
            const float d = 1.0f - jlimit (0.0f, 1.0f, std::fabs (t - f) * 3.0f);
            const Colour c = hcol::faint.interpolatedWith (accent, d);
            const float r = 9.0f;
            g.setColour (c);

            if (i == 0)                                    // струна
            {
                g.fillRect (cx - r, cy - 0.9f, r * 2.0f, 1.8f);
                g.fillEllipse (cx - r - 1.5f, cy - 1.5f, 3.0f, 3.0f);
                g.fillEllipse (cx + r - 1.5f, cy - 1.5f, 3.0f, 3.0f);
            }
            else if (i == 1)                               // труба
            {
                g.drawRoundedRectangle (cx - r, cy - r * 0.55f, r * 2.0f, r * 1.1f, r * 0.55f, 1.4f);
            }
            else if (i == 2)                               // брусок
            {
                for (int k = 0; k < 3; ++k)
                    g.fillRect (cx - r + (float) k * r * 0.8f + 1.0f,
                                cy - r * (0.85f - 0.2f * (float) k), 2.0f,
                                r * 2.0f * (0.85f - 0.2f * (float) k) * 0.5f + r * 0.5f);
            }
            else                                           // пластина
            {
                g.drawEllipse (cx - r, cy - r * 0.9f, r * 2.0f, r * 1.8f, 1.3f);
                g.drawEllipse (cx - r * 0.45f, cy - r * 0.4f, r * 0.9f, r * 0.8f, 1.0f);
            }
        }

        const float px = b.getX() + b.getWidth() * (0.11f + 0.78f * t);
        g.setColour (accent);
        Path tri;
        tri.addTriangle (px, cy + b.getHeight() * 0.32f - 5.0f,
                         px - 3.5f, cy + b.getHeight() * 0.32f + 1.0f,
                         px + 3.5f, cy + b.getHeight() * 0.32f + 1.0f);
        g.fillPath (tri);
    }

    /** Плотность мод: сколько резонаторов и как быстро они гаснут вверх. */
    void drawDensity (Graphics& g, Rectangle<float> b, Slider& s)
    {
        const int n = (int) std::lround (s.getValue());
        const int slots = 32;
        const float step = b.getWidth() / (float) slots;
        for (int i = 0; i < slots; ++i)
        {
            const float f = (float) i / (float) (slots - 1);
            const bool on = ((float) i / (float) (slots - 1)) <= (float) (n - 4) / 60.0f;
            const float hgt = b.getHeight() * (0.28f + 0.72f * std::pow (1.0f - f, 0.75f));
            g.setColour (on ? accent.withAlpha (0.30f + 0.55f * (1.0f - f)) : hcol::lineSoft.brighter (0.15f));
            g.fillRect (b.getX() + (float) i * step, b.getBottom() - hgt, jmax (1.4f, step - 1.6f), hgt);
        }
    }

    /** Точка возбуждения: где по струне ударяем и какая при этом гребёнка. */
    void drawPluck (Graphics& g, Rectangle<float> b, float t)
    {
        const float cy = b.getCentreY();
        Path wave;
        const int N = 48;
        for (int i = 0; i <= N; ++i)
        {
            const float f = (float) i / (float) N;
            const float amp = std::sin (MathConstants<float>::pi * f)
                            * std::sin (MathConstants<float>::pi * jlimit (0.02f, 0.98f, t));
            const float px = b.getX() + b.getWidth() * f;
            const float py = cy - amp * b.getHeight() * 0.34f;
            if (i == 0) wave.startNewSubPath (px, py); else wave.lineTo (px, py);
        }
        g.setColour (accent.withAlpha (0.55f));
        g.strokePath (wave, PathStrokeType (1.4f));

        g.setColour (hcol::faint);
        g.fillRect (b.getX(), cy - 0.5f, b.getWidth(), 1.0f);
        g.fillEllipse (b.getX() - 2.0f, cy - 2.5f, 5.0f, 5.0f);
        g.fillEllipse (b.getRight() - 3.0f, cy - 2.5f, 5.0f, 5.0f);

        const float px = b.getX() + b.getWidth() * t;
        g.setColour (accent);
        g.fillRect (px - 1.0f, b.getY(), 2.0f, b.getHeight());
        g.fillEllipse (px - 3.5f, cy - 3.5f, 7.0f, 7.0f);
    }

    /** Количество симпатических струн — просто пересчитать глазами. */
    void drawSteps (Graphics& g, Rectangle<float> b, Slider& s)
    {
        const int n = (int) std::lround (s.getValue());
        const int total = (int) s.getMaximum();
        const float step = b.getWidth() / (float) total;
        for (int i = 0; i < total; ++i)
        {
            const bool on = i < n;
            const float inset = b.getHeight() * (on ? 0.06f : 0.28f);
            g.setColour (on ? accent.withAlpha (0.85f) : hcol::lineSoft.brighter (0.2f));
            g.fillRect (b.getX() + (float) i * step + step * 0.5f - 1.0f,
                        b.getY() + inset, 2.0f, b.getHeight() - inset * 2.0f);
            if (on)
            {
                g.setColour (accent.withAlpha (0.5f));
                g.fillEllipse (b.getX() + (float) i * step + step * 0.5f - 2.0f,
                               b.getBottom() - inset - 4.0f, 4.0f, 4.0f);
            }
        }
    }

    Strip::Kind kind;
    Colour accent;
};

Strip::Strip (AudioProcessorValueTreeState& state, const String& paramID,
              const String& cap, Kind k, Colour ac)
    : caption (cap), kind (k), accent (ac)
{
    lnf = std::make_unique<StripLnf> (k, ac);
    slider.setSliderStyle (Slider::LinearHorizontal);
    slider.setTextBoxStyle (Slider::NoTextBox, false, 0, 0);
    slider.setLookAndFeel (lnf.get());
    addAndMakeVisible (slider);
    slider.addMouseListener (this, true);
    att = std::make_unique<AudioProcessorValueTreeState::SliderAttachment> (state, paramID, slider);
}

Strip::~Strip() { slider.setLookAndFeel (nullptr); }

void Strip::resized()
{
    // Полоса подписи ровно та же, что у Knob, а сам виджет центрируется в
    // остатке: иначе в одном ряду подписи и графика разъезжаются по вертикали.
    auto b = getLocalBounds();
    b.removeFromBottom (kCaptionH);
    slider.setBounds (b.withSizeKeepingCentre (b.getWidth(), jmin (b.getHeight(), 54)));
}

void Strip::paint (Graphics& g)
{
    const bool showValue = hover || slider.isMouseButtonDown();
    auto strip = getLocalBounds().removeFromBottom (kCaptionH);
    g.setFont (uiFont (showValue ? 11.0f : 9.5f, ! showValue));
    g.setColour (showValue ? accent.brighter (0.25f) : hcol::dim);
    g.drawText (showValue ? slider.getTextFromValue (slider.getValue()) : caption,
                strip, Justification::centred, false);
}

// ============================================================================
void RouterView::setRowCentres (float a, float b) noexcept
{
    rowTop = a; rowBottom = b;
    repaint();
}

void RouterView::setState (float s, float c, float h, float co) noexcept
{
    split = s; cross = c; husk = h; core = co;
    repaint();
}

void RouterView::paint (Graphics& g)
{
    auto b = getLocalBounds().toFloat();
    const float chipW = 62.0f, chipH = 22.0f;
    const float lx = b.getX(), rx = b.getRight() - chipW;
    // чипы держим внутри вида: центры рядов приходят из координат слайдеров и
    // на краю могут выйти за границу, а вылезшее просто срежет клип
    const float y1 = jlimit (0.0f, b.getHeight() - chipH, rowTop - chipH * 0.5f);
    const float y2 = jlimit (0.0f, b.getHeight() - chipH, rowBottom - chipH * 0.5f);

    // Веса: core→body = w, husk→body = 1−w, core→field = 1−w, husk→field = w.
    // Ровно то, что делает движок: srcA/srcB из SPLIT, обмен адресами из CROSS.
    const float w = (1.0f - cross) * (1.0f - split) + cross * split;

    struct Ribbon { float fromY, toY, weight; Colour c; };
    const Ribbon ribbons[4] = {
        { y1, y1, w,        hcol::cool },   // CORE -> BODY
        { y2, y1, 1.0f - w, hcol::warm },   // HUSK -> BODY
        { y1, y2, 1.0f - w, hcol::cool },   // CORE -> FIELD
        { y2, y2, w,        hcol::warm },   // HUSK -> FIELD
    };

    for (const auto& rb : ribbons)
    {
        if (rb.weight < 0.005f) continue;
        const float a = rb.fromY + chipH * 0.5f, bb = rb.toY + chipH * 0.5f;
        Path p;
        p.startNewSubPath (lx + chipW + 2.0f, a);
        p.cubicTo (lx + chipW + (rx - lx - chipW) * 0.45f, a,
                   lx + chipW + (rx - lx - chipW) * 0.55f, bb,
                   rx - 2.0f, bb);
        const float src = (rb.c == hcol::warm) ? husk : core;
        const float glow = jlimit (0.0f, 1.0f, src * 3.0f);
        g.setColour (rb.c.withAlpha (0.16f + 0.55f * rb.weight * (0.45f + 0.55f * glow)));
        g.strokePath (p, PathStrokeType (1.5f + 11.0f * rb.weight,
                                         PathStrokeType::curved, PathStrokeType::rounded));
    }

    auto chip = [&g] (Rectangle<float> r, const String& t, Colour c, float lvl)
    {
        g.setColour (hcol::panelHi);
        g.fillRoundedRectangle (r, 3.0f);
        g.setColour (c.withAlpha (0.35f + 0.65f * jlimit (0.0f, 1.0f, lvl * 3.0f)));
        g.drawRoundedRectangle (r, 3.0f, 1.2f);
        g.setColour (c);
        g.setFont (uiFont (10.0f, true));
        g.drawText (t, r, Justification::centred, false);
    };

    chip ({ lx, y1, chipW, chipH }, "CORE",  hcol::cool, core);
    chip ({ lx, y2, chipW, chipH }, "HUSK",  hcol::warm, husk);
    chip ({ rx, y1, chipW, chipH }, "BODY",  hcol::warm, 0.0f);
    chip ({ rx, y2, chipW, chipH }, "FIELD", hcol::cool, 0.0f);
}

// ============================================================================
void ModeView::setModes (const float* h, const float* a, int count, float fund, float lvl) noexcept
{
    n = jlimit (0, 64, count);
    for (int i = 0; i < n; ++i) { hz[(size_t) i] = h[i]; amp[(size_t) i] = a[i]; }
    f0 = fund; level = lvl;
    repaint();
}

void ModeView::paint (Graphics& g)
{
    auto b = getLocalBounds().toFloat();
    g.setColour (hcol::bg);
    g.fillRoundedRectangle (b, 3.0f);

    constexpr float lo = 60.0f, hi = 9000.0f;

    // октавная сетка
    g.setColour (hcol::lineSoft);
    for (float f = 62.5f; f < hi; f *= 2.0f)
    {
        const float x = b.getX() + logPos (f, lo, hi) * b.getWidth();
        g.fillRect (x, b.getY() + 2.0f, 1.0f, b.getHeight() - 4.0f);
    }

    if (n == 0) return;
    float maxA = 1.0e-6f;
    for (int i = 0; i < n; ++i) maxA = jmax (maxA, amp[(size_t) i]);

    const float glow = jlimit (0.0f, 1.0f, level * 3.5f);
    for (int i = 0; i < n; ++i)
    {
        if (amp[(size_t) i] <= 0.0f) continue;
        const float x = b.getX() + logPos (hz[(size_t) i], lo, hi) * b.getWidth();
        const float hgt = (b.getHeight() - 8.0f) * std::pow (amp[(size_t) i] / maxA, 0.55f);
        const float alpha = 0.35f + 0.5f * glow;
        g.setColour (hcol::warm.withAlpha (alpha * (i == 0 ? 1.0f : 0.85f)));
        g.fillRect (x - 1.0f, b.getBottom() - 4.0f - hgt, i == 0 ? 2.0f : 1.6f, hgt);
    }

    g.setColour (hcol::faint);
    g.setFont (uiFont (9.0f));
    g.drawText (String (f0, 1) + " Hz", b.reduced (6.0f, 3.0f), Justification::topRight, false);
}

// ============================================================================
void TailView::setTail (float size, float bloom, float damp, float amount, bool fz) noexcept
{
    // средняя длина линии FDN в секундах (те же коэффициенты, что в FDN8)
    const float meanLen = 0.0855f * jlimit (0.15f, 2.5f, size);
    const float g = jlimit (0.0f, 0.9899f, bloom);
    t60   = (g < 0.001f) ? 0.02f : jlimit (0.02f, 60.0f, -3.0f * meanLen / std::log10 (g));
    t60hf = t60 * jlimit (0.05f, 1.0f, 1.0f - 0.85f * damp);
    amt = amount;
    frozen = fz;
    repaint();
}

void TailView::paint (Graphics& g)
{
    auto b = getLocalBounds().toFloat();
    g.setColour (hcol::bg);
    g.fillRoundedRectangle (b, 3.0f);
    g.setColour (hcol::line);
    g.drawRoundedRectangle (b.reduced (0.5f), 3.0f, 1.0f);
    b = b.reduced (7.0f, 6.0f);

    constexpr float span = 12.0f;                 // секунд по горизонтали
    g.setColour (hcol::lineSoft.withAlpha (0.55f));
    for (int sec = 2; sec < (int) span; sec += 2)
        g.fillRect (b.getX() + b.getWidth() * (float) sec / span,
                    b.getBottom() - 6.0f, 1.0f, 6.0f);

    auto curve = [&] (float t60v, Colour c, float w)
    {
        Path p;
        const int N = 64;
        for (int i = 0; i <= N; ++i)
        {
            const float t = span * (float) i / (float) N;
            const float a = frozen ? 1.0f : std::pow (10.0f, -3.0f * t / jmax (0.02f, t60v));
            const float x = b.getX() + b.getWidth() * (float) i / (float) N;
            const float y = b.getBottom() - b.getHeight() * a * jlimit (0.05f, 1.0f, 0.25f + 0.75f * amt);
            if (i == 0) p.startNewSubPath (x, y); else p.lineTo (x, y);
        }
        g.setColour (c);
        g.strokePath (p, PathStrokeType (w));
    };

    curve (t60hf, hcol::faint, 1.0f);
    curve (t60,   frozen ? hcol::warm : hcol::text.withAlpha (0.75f), 1.6f);

    g.setColour (frozen ? hcol::warm : hcol::dim);
    g.setFont (uiFont (10.0f, true));
    g.drawText (frozen ? "FROZEN" : (t60 >= 10.0f ? String (roundToInt (t60)) + " s" : String (t60, 1) + " s"),
                b.reduced (2.0f, 1.0f), Justification::bottomRight, false);
}

// ============================================================================
void StringView::setStrings (const float* h, int count, float lvl, int r, bool m) noexcept
{
    n = jlimit (0, 12, count);
    for (int i = 0; i < n; ++i) hz[(size_t) i] = h[i];
    level = lvl; root = r; minor = m;
    repaint();
}

void StringView::paint (Graphics& g)
{
    auto b = getLocalBounds().toFloat();
    g.setColour (hcol::bg);
    g.fillRoundedRectangle (b, 3.0f);
    g.setColour (hcol::line);
    g.drawRoundedRectangle (b.reduced (0.5f), 3.0f, 1.0f);

    static const char* names[12] = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };

    auto inner = b.reduced (10.0f, 8.0f);
    const float nutY    = inner.getY() + 8.0f;
    const float bridgeY = inner.getBottom() - 14.0f;

    constexpr float lo = 65.0f, hi = 2600.0f;
    g.setColour (hcol::lineSoft.brighter (0.15f));
    for (float f = 62.5f; f < hi; f *= 2.0f)
    {
        const float x = inner.getX() + logPos (f, lo, hi) * inner.getWidth();
        g.fillRect (x, nutY, 1.0f, bridgeY - nutY);
    }

    // порожек и подставка — из-за них поле читается как инструмент, а не как шкала
    g.setColour (hcol::faint.withAlpha (0.7f));
    g.fillRect (inner.getX(), nutY - 1.0f, inner.getWidth(), 1.5f);
    g.fillRect (inner.getX(), bridgeY, inner.getWidth(), 1.5f);

    const float glow = jlimit (0.0f, 1.0f, level * 3.5f);

    for (int i = 0; i < n; ++i)
    {
        const float x = inner.getX() + logPos (hz[(size_t) i], lo, hi) * inner.getWidth();
        const float thick = 2.2f - 1.1f * logPos (hz[(size_t) i], lo, hi);   // бас толще
        g.setColour (hcol::cool.withAlpha (0.30f + 0.55f * glow));
        g.fillRect (x - thick * 0.5f, nutY, thick, bridgeY - nutY);
        g.setColour (hcol::cool.withAlpha (0.55f + 0.45f * glow));
        g.fillEllipse (x - 2.5f, bridgeY - 2.0f, 5.0f, 5.0f);

        if (inner.getHeight() > 70.0f)
        {
            const int midi = (int) std::lround (hzToMidiUi (hz[(size_t) i]));
            g.setColour (hcol::faint);
            g.setFont (uiFont (8.5f));
            g.drawText (String (names[((midi % 12) + 12) % 12]),
                        (int) x - 10, (int) bridgeY + 4, 20, 10, Justification::centred, false);
        }
    }

    g.setColour (hcol::faint);
    g.setFont (uiFont (9.0f, true));
    g.drawText (String (names[jlimit (0, 11, root)]) + (minor ? " min" : " maj"),
                b.reduced (8.0f, 5.0f), Justification::topRight, false);
    g.setFont (uiFont (8.5f));
    g.drawText (String (n) + (n == 1 ? " string" : " strings"),
                b.reduced (8.0f, 5.0f), Justification::topLeft, false);
}

// ============================================================================
HuskAudioProcessorEditor::HuskAudioProcessorEditor (HuskAudioProcessor& p)
    : AudioProcessorEditor (&p), proc (p)
{
    setLookAndFeel (&lnf);

    router.setName ("view:router");
    tail.setName ("view:tail");
    modes.setName ("view:modes");
    strings.setName ("view:strings");
    splitSlider.setName ("slider:split");
    crossSlider.setName ("slider:cross");
    tuneBox.setName ("combo:tune");
    freezeBtn.setName ("button:freeze");
    presetBtn.setName ("button:preset");
    prevBtn.setName ("button:prev");
    nextBtn.setName ("button:next");
    saveBtn.setName ("button:save");
    addAndMakeVisible (router);
    addAndMakeVisible (tail);
    addAndMakeVisible (modes);
    addAndMakeVisible (strings);

    for (auto* s : { &splitSlider, &crossSlider })
    {
        s->setSliderStyle (Slider::LinearHorizontal);
        s->setTextBoxStyle (Slider::NoTextBox, false, 0, 0);
        addAndMakeVisible (*s);
    }
    splitSlider.setColour (Slider::trackColourId, hcol::warm);
    crossSlider.setColour (Slider::trackColourId, hcol::cool);
    splitAtt = std::make_unique<AudioProcessorValueTreeState::SliderAttachment> (proc.apvts, "split", splitSlider);
    crossAtt = std::make_unique<AudioProcessorValueTreeState::SliderAttachment> (proc.apvts, "cross", crossSlider);

    addKnob ("husk",         "HUSK",    false, hcol::warm);

    addKnob  ("bodyamt",    "LEVEL",  true,  hcol::warm);
    addStrip ("bodyshape",  "SHAPE",  Strip::Kind::Morph,   hcol::warm);
    addStrip ("bodypos",    "POS",    Strip::Kind::Pluck,   hcol::warm);
    addKnob  ("bodydecay",  "DECAY",  false, hcol::warm);
    addKnob  ("bodybright", "BRIGHT", false, hcol::warm);
    addStrip ("bodymodes",  "MODES",  Strip::Kind::Density, hcol::warm);

    addKnob ("fieldamt",     "LEVEL",   true,  hcol::cool);
    addKnob ("fieldstrings", "STRINGS", false, hcol::cool);
    addKnob ("fielddecay",   "DECAY",   false, hcol::cool);
    addKnob ("fielddamp",    "DAMP",    false, hcol::cool);
    addKnob ("drift",        "DRIFT",   false, hcol::cool);

    addKnob ("airamt",       "LEVEL",   true,  hcol::text);
    addKnob ("airsize",      "SIZE",    false, hcol::text);
    addKnob ("airbloom",     "BLOOM",   false, hcol::text).slider
        .getProperties().set ("danger", 0.92);
    addKnob ("airdamp",      "DAMP",    false, hcol::text);
    addKnob ("airdrive",     "DRIVE",   false, hcol::text);

    addKnob ("mix",          "MIX",     true,  hcol::text);
    addKnob ("output",       "TRIM",    false, hcol::text);

    tuneBox.addItemList ({ "Follow", "Key", "Fixed" }, 1);
    addAndMakeVisible (tuneBox);
    tuneAtt = std::make_unique<AudioProcessorValueTreeState::ComboBoxAttachment> (proc.apvts, "bodytune", tuneBox);

    freezeBtn.setClickingTogglesState (true);
    addAndMakeVisible (freezeBtn);
    freezeAtt = std::make_unique<AudioProcessorValueTreeState::ButtonAttachment> (proc.apvts, "freeze", freezeBtn);

    for (auto* b : { &prevBtn, &nextBtn, &presetBtn, &saveBtn }) addAndMakeVisible (*b);
    prevBtn.onClick = [this] { stepPreset (-1); };
    nextBtn.onClick = [this] { stepPreset (+1); };
    presetBtn.onClick = [this] { showPresetMenu(); };
    saveBtn.onClick = [this]
    {
        saveWindow = std::make_unique<AlertWindow> ("Save preset", "Preset name:",
                                                    MessageBoxIconType::NoIcon);
        saveWindow->setLookAndFeel (&lnf);
        saveWindow->addTextEditor ("name", proc.displayedPresetName);
        saveWindow->addButton ("OK", 1, KeyPress (KeyPress::returnKey));
        saveWindow->addButton ("Cancel", 0, KeyPress (KeyPress::escapeKey));
        saveWindow->enterModalState (true, ModalCallbackFunction::create ([this] (int r)
        {
            if (r == 1 && saveWindow != nullptr)
                proc.saveUserPreset (saveWindow->getTextEditorContents ("name"));
            if (saveWindow != nullptr) saveWindow->setLookAndFeel (nullptr);
            saveWindow.reset();
            refreshPresetLabel();
        }), false);
    };

    refreshPresetLabel();
    setSize (kW, kH);
    timerCallback();          // первый кадр не должен быть пустым
    startTimerHz (24);
}

HuskAudioProcessorEditor::~HuskAudioProcessorEditor()
{
    if (saveWindow != nullptr) saveWindow->setLookAndFeel (nullptr);
    setLookAndFeel (nullptr);
}

Knob& HuskAudioProcessorEditor::addKnob (const String& id, const String& cap,
                                         bool large, Colour accent)
{
    auto* k = new Knob (proc.apvts, id, cap, large, accent);
    k->setName ("knob:" + cap + ":" + id);
    knobs.add (k);
    addAndMakeVisible (k);
    return *k;
}

Strip& HuskAudioProcessorEditor::addStrip (const String& id, const String& cap,
                                           Strip::Kind kind, Colour accent)
{
    auto* st = new Strip (proc.apvts, id, cap, kind, accent);
    st->setName ("strip:" + cap + ":" + id);
    strips.add (st);
    addAndMakeVisible (st);
    return *st;
}

// ----------------------------------------------------------------- пресеты
void HuskAudioProcessorEditor::refreshPresetLabel()
{
    presetBtn.setButtonText (proc.displayedPresetName);
    const int i = husk::findPreset (proc.displayedPresetName.toStdString());
    presetCat  = (i >= 0) ? husk::factoryPresets()[(size_t) i].category : "User";
    presetNote = (i >= 0) ? String::fromUTF8 (husk::factoryPresets()[(size_t) i].note) : String();
    presetBtn.setTooltip (i >= 0 ? husk::factoryPresets()[(size_t) i].note : String());
    repaint();
}

void HuskAudioProcessorEditor::stepPreset (int delta)
{
    const int n = (int) husk::factoryPresets().size();
    int i = husk::findPreset (proc.displayedPresetName.toStdString());
    if (i < 0) i = proc.getCurrentProgram();
    i = (i + delta % n + n) % n;
    proc.applyFactoryPreset (i);
    refreshPresetLabel();
}

void HuskAudioProcessorEditor::showPresetMenu()
{
    PopupMenu menu;
    menu.setLookAndFeel (&lnf);

    const auto& bank = husk::factoryPresets();
    String cat;
    PopupMenu sub;
    auto flush = [&] { if (cat.isNotEmpty()) menu.addSubMenu (cat, sub); sub.clear(); };
    for (size_t i = 0; i < bank.size(); ++i)
    {
        if (String (bank[i].category) != cat) { flush(); cat = bank[i].category; }
        PopupMenu::Item it (bank[i].name);
        it.itemID = (int) i + 1;
        it.isTicked = (proc.displayedPresetName == bank[i].name);
        sub.addItem (it);
    }
    flush();

    const auto users = proc.userPresetNames();
    if (! users.isEmpty())
    {
        PopupMenu um;
        for (int i = 0; i < users.size(); ++i)
            um.addItem (10000 + i, users[i], true, proc.displayedPresetName == users[i]);
        menu.addSeparator();
        menu.addSubMenu ("User", um);
    }
    menu.addSeparator();
    menu.addItem (9000, "Reveal preset folder");

    menu.showMenuAsync (PopupMenu::Options().withTargetComponent (presetBtn)
                                            .withMinimumWidth (presetBtn.getWidth()),
                        [this, users] (int r)
    {
        if (r == 0) return;
        if (r == 9000) { HuskAudioProcessor::userPresetDir().revealToUser(); return; }
        if (r >= 10000)
        {
            const int i = r - 10000;
            if (i < users.size())
                proc.loadUserPreset (HuskAudioProcessor::userPresetDir()
                                        .getChildFile (users[i] + ".huskpreset"));
        }
        else proc.applyFactoryPreset (r - 1);
        refreshPresetLabel();
    });
}

// ------------------------------------------------------------------ таймер
void HuskAudioProcessorEditor::timerCallback()
{
    proc.readVisualState (vis);

    static const char* names[12] = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
    keyText = String (names[jlimit (0, 11, vis.keyRoot)]) + (vis.keyMinor ? " min" : " maj");
    f0Text  = String (vis.f0, 1) + " Hz";

    transientMeter = 0.7f * transientMeter + 0.3f * vis.transient;
    outMeter = jmax (vis.outLevel, outMeter * 0.82f);

    router.setState (proc.apvts.getRawParameterValue ("split")->load(),
                     proc.apvts.getRawParameterValue ("cross")->load(),
                     vis.huskLevel, vis.coreLevel);
    modes.setModes (vis.modeHz, vis.modeAmp, vis.numModes, vis.f0, vis.bodyLevel);
    strings.setStrings (vis.stringHz, vis.numStrings, vis.fieldLevel, vis.keyRoot, vis.keyMinor);
    tail.setTail (proc.apvts.getRawParameterValue ("airsize")->load(),
                  proc.apvts.getRawParameterValue ("airbloom")->load(),
                  proc.apvts.getRawParameterValue ("airdamp")->load(),
                  proc.apvts.getRawParameterValue ("airamt")->load(),
                  proc.apvts.getRawParameterValue ("freeze")->load() > 0.5f);

    if (presetBtn.getButtonText() != proc.displayedPresetName) refreshPresetLabel();
    repaint (0, 0, getWidth(), 90);
    repaint (rOut);
}

// ------------------------------------------------------------------- отрисовка
void HuskAudioProcessorEditor::drawPanel (Graphics& g, Rectangle<int> r,
                                          const String& title, Colour tc) const
{
    g.setGradientFill (ColourGradient (hcol::panel.brighter (0.045f), (float) r.getCentreX(), (float) r.getY(),
                                       hcol::panel,                   (float) r.getCentreX(), (float) r.getBottom(), false));
    g.fillRoundedRectangle (r.toFloat(), 4.0f);
    g.setColour (hcol::line);
    g.drawRoundedRectangle (r.toFloat().reduced (0.5f), 4.0f, 1.0f);
    g.setColour (tc.withAlpha (0.85f));
    drawTracked (g, title, { r.getX() + 16, r.getY() + 6, 200, 12 }, 9.5f, 1.6f);
}

void HuskAudioProcessorEditor::paint (Graphics& g)
{
    // фон: очень мягкое тёплое свечение сверху, иначе плоский чёрный «пластик»
    g.setGradientFill (ColourGradient (Colour (0xff17120f), (float) getWidth() * 0.5f, -80.0f,
                                       hcol::bg, (float) getWidth() * 0.5f, 320.0f, true));
    g.fillAll();

    g.setColour (hcol::text);
    g.setFont (uiFont (27.0f, true));
    g.drawText ("HUSK", 16, 12, 130, 30, Justification::left, false);
    g.setColour (hcol::faint);
    g.setFont (uiFont (11.5f));
    g.drawText ("resonant body driven by how you play", 96, 21, 340, 16, Justification::left, false);

    // статус: две одинаковые колонки «значение + индикатор», выровненные по
    // правому краю окна вместе с кнопкой SAVE
    const int colW = 190, right = getWidth() - 14;
    auto column = [&g, right, colW] (int idx, const String& value, Colour vc,
                                     const String& label, float norm, Colour bc)
    {
        const int x = right - (2 - idx) * colW;
        g.setColour (vc);
        g.setFont (uiFont (13.0f, true));
        g.drawText (value, x, 12, colW - 14, 16, Justification::right, false);
        g.setColour (hcol::faint);
        g.setFont (uiFont (8.5f, true));
        g.drawText (label, x, 32, 50, 10, Justification::left, false);
        auto r = Rectangle<float> ((float) x + 44.0f, 35.0f, (float) colW - 58.0f, 3.0f);
        g.setColour (hcol::lineSoft);
        g.fillRoundedRectangle (r, 1.5f);
        g.setColour (bc.withAlpha (0.9f));
        g.fillRoundedRectangle (r.withWidth (r.getWidth() * jlimit (0.0f, 1.0f, norm)), 1.5f);
    };
    const float outDb = Decibels::gainToDecibels (jmax (outMeter, 1.0e-5f));
    column (0, keyText, hcol::cool, "ATTACK", transientMeter * 2.5f, hcol::warm);
    column (1, f0Text,  hcol::warm, "OUT", (outDb + 60.0f) / 60.0f,
            outDb > -1.0f ? hcol::warm : hcol::cool);

    // строка пресета: категория подписью слева внутри поля
    g.setColour (hcol::faint);
    g.setFont (uiFont (9.0f, true));
    g.drawText (presetCat.toUpperCase(), presetBtn.getX() + 12, presetBtn.getY(),
                120, presetBtn.getHeight(), Justification::centredLeft, false);

    // описание пресета отдельной строкой — иначе его никто никогда не увидит
    g.setColour (hcol::faint);
    g.setFont (uiFont (11.0f));
    g.drawText (presetNote, 18, 84, getWidth() - 36, 14, Justification::centred, true);

    drawPanel (g, rRouter, "ROUTING", hcol::text);
    drawPanel (g, rBody,   "BODY",  hcol::warm);
    drawPanel (g, rField,  "FIELD", hcol::cool);
    drawPanel (g, rAir,    "AIR",   hcol::text);
    drawPanel (g, rOut,    "OUT",   hcol::text);

    // подписи горизонтальных слайдеров
    g.setColour (hcol::dim);
    g.setFont (uiFont (9.0f, true));
    g.drawText ("SPLIT", splitSlider.getX(), splitSlider.getY() - 14, 60, 11, Justification::left, false);
    g.drawText ("CROSS", crossSlider.getX(), crossSlider.getY() - 14, 60, 11, Justification::left, false);
    g.setColour (hcol::faint);
    g.setFont (uiFont (8.5f));
    g.drawText ("core", splitSlider.getX() + 46, splitSlider.getY() - 14, 60, 11, Justification::left, false);
    g.drawText ("husk", splitSlider.getRight() - 60, splitSlider.getY() - 14, 60, 11, Justification::right, false);
    g.drawText ("swap", crossSlider.getRight() - 60, crossSlider.getY() - 14, 60, 11, Justification::right, false);

    g.setColour (hcol::dim);
    g.setFont (uiFont (9.0f, true));
    g.drawText ("TUNE", tuneBox.getX(), tuneBox.getY() - 14, 60, 11, Justification::left, false);

    // подгруппы: тонкая линия слева и мелкий заголовок
    for (const auto& gr : groups)
    {
        if (gr.divider)
        {
            g.setColour (hcol::line);
            g.fillRect (gr.area.getX() - 13, gr.area.getY() - 4, 1, gr.area.getHeight() + 8);
        }
        g.setColour (hcol::faint);
        g.setFont (uiFont (8.5f, true));
        g.drawText (gr.title, gr.area.getX(), gr.area.getY() - 14, 160, 11, Justification::left, false);
    }

}

// -------------------------------------------------------------------- layout
juce::String HuskAudioProcessorEditor::dumpLayout() const
{
    auto rect = [] (const String& n, Rectangle<int> r)
    {
        return "  {\"name\":\"" + n + "\",\"x\":" + String (r.getX())
             + ",\"y\":" + String (r.getY()) + ",\"w\":" + String (r.getWidth())
             + ",\"h\":" + String (r.getHeight()) + "}";
    };
    StringArray items;
    items.add (rect ("window", getLocalBounds()));
    items.add (rect ("panel:ROUTING", rRouter));
    items.add (rect ("panel:BODY", rBody));
    items.add (rect ("panel:FIELD", rField));
    items.add (rect ("panel:AIR", rAir));
    items.add (rect ("panel:OUT", rOut));
    for (const auto& gr : groups) items.add (rect ("group:" + gr.title, gr.area));
    for (auto* c : getChildren())
        if (c->getName().isNotEmpty())
            items.add (rect (c->getName(), c->getBounds()));
    return "[\n" + items.joinIntoString (",\n") + "\n]\n";
}

std::vector<int> HuskAudioProcessorEditor::spreadRow (int x0, int spanW,
                                                      const std::vector<int>& widths,
                                                      int minGap)
{
    int total = 0;
    for (int w : widths) total += w;
    const int n = (int) widths.size();
    const int gap = (n > 1) ? jmax (minGap, (spanW - total) / (n - 1)) : minGap;
    std::vector<int> xs;
    int x = x0;
    for (int i = 0; i < n; ++i) { xs.push_back (x); x += widths[(size_t) i] + gap; }
    return xs;
}

void HuskAudioProcessorEditor::resized()
{
    jassert (knobs.size() == 16 && strips.size() == 3);
    if (knobs.size() < 16 || strips.size() < 3) return;

    groups.clear();

    // Единая сетка. Все элементы одного ряда имеют одинаковую высоту и одну и
    // ту же полосу подписи, поэтому подписи стоят в линию, а круги — в один
    // оптический ряд. HDR — обязательный зазор над рядом, у которого есть
    // заголовок подгруппы: заголовок рисуется на area.y − 14, и если зазор
    // меньше, он наезжает на то, что стоит выше.
    constexpr int M = 14;      // поле окна и зазор между панелями
    constexpr int PAD = 16;    // внутреннее поле панели
    constexpr int TITLE = 22;  // полоса заголовка панели
    constexpr int HDR = 20;    // место под заголовок подгруппы
    constexpr int VIS = 48;    // визуализатор
    constexpr int ROW = 80;    // ряд регуляторов (круг 64 + подпись 16)
    constexpr int KW = 72;     // ширина регулятора
    constexpr int COL = 100;   // мастер-колонка
    constexpr int COLGAP = 24; // мастер-колонка → подгруппа
    constexpr int GAPH = 6;    // минимальный зазор внутри ряда

    const int fullW = getWidth() - 2 * M;

    const int py = 54, ph = 30;
    prevBtn.setBounds (M, py, 30, ph);
    saveBtn.setBounds (getWidth() - M - 62, py, 62, ph);
    nextBtn.setBounds (saveBtn.getX() - 6 - 30, py, 30, ph);
    presetBtn.setBounds (M + 30 + 6, py, nextBtn.getX() - (M + 36) - 6, ph);

    const int routerH = TITLE + ROW + PAD;                       // 118
    const int panelH  = TITLE + VIS + HDR + ROW + HDR + ROW + PAD;  // 286
    const int airH    = TITLE + HDR + ROW + PAD;                 // 138 − 20 = 138
    const int outW    = 190;
    const int halfW   = (fullW - M) / 2;

    rRouter = { M, 100, fullW, routerH };
    rBody   = { M, rRouter.getBottom() + M, halfW, panelH };
    rField  = { M + halfW + M, rBody.getY(), halfW, panelH };
    rAir    = { M, rBody.getBottom() + M, fullW - outW - M, airH };
    rOut    = { M + fullW - outW, rAir.getY(), outW, airH };

    // ---- ROUTING
    {
        const int x = rRouter.getX(), top = rRouter.getY() + TITLE;
        const int bot = rRouter.getBottom() - PAD;
        router.setBounds (x + PAD, top, 340, bot - top);

        const int sx = x + 392, sw = rRouter.getWidth() - 392 - PAD - KW - COLGAP;
        splitSlider.setBounds (sx, top + 14, sw, 20);
        crossSlider.setBounds (sx, bot - 20, sw, 20);
        router.setRowCentres ((float) (splitSlider.getBounds().getCentreY() - top),
                              (float) (crossSlider.getBounds().getCentreY() - top));

        knobs[0]->setBounds (rRouter.getRight() - PAD - KW, top, KW, ROW);
    }

    // ---- BODY
    {
        const int x = rBody.getX(), y = rBody.getY();
        const int rowA = y + TITLE + VIS + HDR;
        const int rowB = rowA + ROW + HDR;
        modes.setBounds (x + PAD, y + TITLE, rBody.getWidth() - 2 * PAD, VIS);

        // TUNE — в верхнем ряду мастер-колонки, LEVEL — в нижнем, чтобы мастера
        // BODY и FIELD стояли на одной линии
        tuneBox.setBounds (x + PAD, rowA + (ROW - Knob::kCaptionH - 22) / 2, COL, 22);
        knobs[1]->setBounds (x + PAD + (COL - KW) / 2, rowB, KW, ROW);

        const int x0 = x + PAD + COL + COLGAP;
        const int span = rBody.getRight() - PAD - x0;

        auto a = spreadRow (x0, span, { 176, 146 }, GAPH);
        strips[0]->setBounds (a[0], rowA, 176, ROW);                 // SHAPE
        strips[1]->setBounds (a[1], rowA, 146, ROW);                 // POS
        groups.push_back ({ { x0, rowA, span, ROW }, "OBJECT", true });

        auto bx = spreadRow (x0, span, { KW, KW, 160 }, GAPH);
        knobs[2]->setBounds  (bx[0], rowB, KW, ROW);                 // DECAY
        knobs[3]->setBounds  (bx[1], rowB, KW, ROW);                 // BRIGHT
        strips[2]->setBounds (bx[2], rowB, 160, ROW);                // MODES
        groups.push_back ({ { x0, rowB, span, ROW }, "TONE", true });
    }

    // ---- FIELD
    {
        const int x = rField.getX(), y = rField.getY();
        const int rowA = y + TITLE + VIS + HDR;
        const int rowB = rowA + ROW + HDR;
        // картинка поля занимает место верхнего ряда, но обрывается за HDR до
        // нижнего, иначе заголовок TUNING ложится прямо на её рамку
        strings.setBounds (x + PAD, y + TITLE, rField.getWidth() - 2 * PAD,
                           (rowB - HDR) - (y + TITLE));

        knobs[4]->setBounds (x + PAD + (COL - KW) / 2, rowB, KW, ROW);
        const int x0 = x + PAD + COL + COLGAP;
        const int span = rField.getRight() - PAD - x0;
        auto xs = spreadRow (x0, span, { KW, KW, KW, KW }, GAPH);
        for (int i = 0; i < 4; ++i) knobs[5 + i]->setBounds (xs[(size_t) i], rowB, KW, ROW);
        groups.push_back ({ { x0, rowB, span, ROW }, "TUNING", true });
        ignoreUnused (rowA);
    }

    // ---- AIR
    {
        const int x = rAir.getX(), row = rAir.getY() + TITLE + HDR;
        knobs[9]->setBounds (x + PAD + (COL - KW) / 2, row, KW, ROW);
        ignoreUnused (row);

        const int x0 = x + PAD + COL + COLGAP;
        const int freezeW = 104;
        const int tailX0 = x0 + 4 * KW + 3 * GAPH + COLGAP;
        const int spaceSpan = tailX0 - COLGAP - x0;
        auto xs = spreadRow (x0, spaceSpan, { KW, KW, KW, KW }, GAPH);
        for (int i = 0; i < 4; ++i) knobs[10 + i]->setBounds (xs[(size_t) i], row, KW, ROW);
        groups.push_back ({ { x0, row, spaceSpan, ROW }, "SPACE", true });

        freezeBtn.setBounds (rAir.getRight() - PAD - freezeW,
                             row + (ROW - Knob::kCaptionH - 30) / 2, freezeW, 30);
        const int tailW = freezeBtn.getX() - COLGAP - tailX0;
        tail.setBounds (tailX0, row + (ROW - Knob::kCaptionH - 52) / 2, tailW, 52);
        groups.push_back ({ { tailX0, row, tailW, ROW }, "TAIL", true });
    }

    // ---- OUT
    {
        const int x = rOut.getX(), row = rOut.getY() + TITLE + HDR;
        const int x0 = x + PAD;
        auto xs = spreadRow (x0, rOut.getWidth() - 2 * PAD, { KW, KW }, GAPH);
        knobs[14]->setBounds (xs[0], row, KW, ROW);
        knobs[15]->setBounds (xs[1], row, KW, ROW);
    }
}
