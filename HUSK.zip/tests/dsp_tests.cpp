// Юнит-тесты DSP-ядра HUSK. Без зависимостей, только стандартная библиотека.
#include "../Source/dsp/HuskEngine.h"
#include "../Source/Presets.h"
#include <set>
#include <cstdio>
#include <random>
#include <vector>
#include <string>

static int failures = 0;
static int checks = 0;

static void check (bool ok, const std::string& name, const std::string& info = {})
{
    ++checks;
    if (! ok) { ++failures; printf ("  ПРОВАЛ  %s  %s\n", name.c_str(), info.c_str()); }
    else       printf ("  ok      %s  %s\n", name.c_str(), info.c_str());
}

/** Мощность на частоте f методом Гёрцеля — хватает вместо целого FFT. */
static double goertzel (const std::vector<float>& x, double sr, double f)
{
    const double w = 2.0 * husk::kPid * f / sr;
    const double c = 2.0 * std::cos (w);
    double s0 = 0.0, s1 = 0.0, s2 = 0.0;
    for (float v : x) { s0 = v + c * s1 - s2; s2 = s1; s1 = s0; }
    return s1 * s1 + s2 * s2 - c * s1 * s2;
}

static void runEngine (husk::Engine& e, const std::vector<float>& in,
                       std::vector<float>& l, std::vector<float>& r, int block = 128)
{
    l.assign (in.size(), 0.0f);
    r.assign (in.size(), 0.0f);
    for (size_t i = 0; i < in.size(); i += (size_t) block)
    {
        const int n = (int) std::min ((size_t) block, in.size() - i);
        e.process (in.data() + i, l.data() + i, r.data() + i, n);
    }
}

static bool allFinite (const std::vector<float>& v)
{
    for (float x : v) if (! std::isfinite (x)) return false;
    return true;
}

static float peak (const std::vector<float>& v)
{
    float p = 0.0f;
    for (float x : v) p = std::max (p, std::fabs (x));
    return p;
}

static float rms (const std::vector<float>& v)
{
    double s = 0.0;
    for (float x : v) s += (double) x * x;
    return (float) std::sqrt (s / std::max<size_t> (1, v.size()));
}

// ---------------------------------------------------------------------------
static void testBypass()
{
    printf ("\n[1] Прозрачность при MIX = 0\n");
    const int sr = 48000, N = sr * 2;
    std::mt19937 rng (1);
    std::uniform_real_distribution<float> d (-0.5f, 0.5f);
    std::vector<float> in ((size_t) N);
    for (auto& v : in) v = d (rng);

    husk::Engine e;
    e.prepare (sr, 128);
    husk::Parameters p; p.mix = 0.0f;
    e.setParameters (p);
    std::vector<float> l, r;
    runEngine (e, in, l, r);

    float maxErr = 0.0f;
    for (int i = 0; i < N; ++i) maxErr = std::max (maxErr, std::fabs (l[(size_t) i] - in[(size_t) i]));
    check (maxErr < 1.0e-5f, "сухой сигнал не изменяется", "макс. ошибка " + std::to_string (maxErr));
}

// ---------------------------------------------------------------------------
static void testStability()
{
    printf ("\n[2] Устойчивость на экстремальных настройках\n");
    const int sr = 48000, N = sr * 20;
    std::mt19937 rng (7);
    std::uniform_real_distribution<float> d (-1.0f, 1.0f);
    std::vector<float> in ((size_t) N);
    for (auto& v : in) v = d (rng);            // 0 dBFS белый шум, 20 секунд

    husk::Engine e;
    e.prepare (sr, 64);
    husk::Parameters p;
    p.split = 1.0f; p.cross = 1.0f; p.huskGain = 3.0f;
    p.bodyModes = 64; p.bodyDecay = 12.0f; p.bodyBright = 1.0f; p.bodyAmt = 1.0f;
    p.fieldAmt = 1.0f; p.fieldDecay = 20.0f; p.fieldStrings = 12; p.drift = 1.0f;
    p.airAmt = 1.0f; p.airBloom = 0.99f; p.airSize = 2.5f; p.airDrive = 1.0f;
    p.mix = 1.0f; p.outGain = 4.0f;
    e.setParameters (p);

    std::vector<float> l, r;
    runEngine (e, in, l, r, 64);
    check (allFinite (l) && allFinite (r), "нет NaN/Inf на максимальных настройках");
    check (peak (l) <= 1.01f && peak (r) <= 1.01f, "выход ограничен",
           "пик " + std::to_string (peak (l)));
}

// ---------------------------------------------------------------------------
static void testFreezeAndDecayToSilence()
{
    printf ("\n[3] Тишина на входе и режим FREEZE\n");
    const int sr = 48000;
    husk::Engine e;
    e.prepare (sr, 128);
    husk::Parameters p;
    p.mix = 1.0f; p.airAmt = 0.8f; p.airBloom = 0.9f;
    e.setParameters (p);

    // 1 c сигнала, потом 20 c тишины — хвост обязан затухнуть
    std::vector<float> in ((size_t) sr * 21, 0.0f);
    for (int i = 0; i < sr; ++i)
        in[(size_t) i] = 0.4f * std::sin (2.0f * husk::kPi * 196.0f * i / sr)
                       * std::exp (-3.0f * i / sr);
    std::vector<float> l, r;
    runEngine (e, in, l, r);

    std::vector<float> tail (l.end() - sr, l.end());
    check (allFinite (l), "нет NaN при затухании");
    check (rms (tail) < 1.0e-4f, "хвост уходит в тишину",
           "rms последней секунды " + std::to_string (rms (tail)));

    // FREEZE: хвост держится
    husk::Engine e2;
    e2.prepare (sr, 128);
    husk::Parameters q = p; q.freeze = false;
    e2.setParameters (q);
    std::vector<float> in2 ((size_t) sr * 12, 0.0f);
    for (int i = 0; i < sr; ++i)
        in2[(size_t) i] = 0.4f * std::sin (2.0f * husk::kPi * 196.0f * i / sr);
    std::vector<float> l2, r2;
    // включаем freeze после первой секунды
    l2.assign (in2.size(), 0.0f); r2.assign (in2.size(), 0.0f);
    for (size_t i = 0; i < in2.size(); i += 128)
    {
        if (i > (size_t) sr && ! q.freeze) { q.freeze = true; e2.setParameters (q); }
        const int n = (int) std::min<size_t> (128, in2.size() - i);
        e2.process (in2.data() + i, l2.data() + i, r2.data() + i, n);
    }
    std::vector<float> ftail (l2.end() - sr, l2.end());
    check (allFinite (l2), "FREEZE не разваливается");
    check (rms (ftail) > 1.0e-5f, "FREEZE удерживает хвост через 10 секунд",
           "rms " + std::to_string (rms (ftail)));
    check (peak (l2) <= 1.01f, "FREEZE не разгоняется", "пик " + std::to_string (peak (l2)));
}

// ---------------------------------------------------------------------------
static void testModalTuning()
{
    printf ("\n[4] Модальное тело настраивается туда, куда сказано\n");
    const int sr = 48000, N = sr * 2;
    husk::ModalBank b;
    b.prepare (sr);
    b.setShape (0.0f);                         // струна: гармонический ряд
    b.setTone (16, 2.0f, 0.10f, 0.5f, 0.26f, 1.1f);
    b.updateCoeffs (220.0f);

    std::mt19937 rng (3);
    std::uniform_real_distribution<float> d (-1.0f, 1.0f);
    std::vector<float> out ((size_t) N);
    for (int i = 0; i < N; ++i)
    {
        const float x = (i < 64) ? d (rng) : 0.0f;   // короткий шумовой всплеск
        out[(size_t) i] = b.process (x);
    }
    check (allFinite (out), "нет NaN");

    const double p220 = goertzel (out, sr, 220.0);
    const double p440 = goertzel (out, sr, 440.0);
    const double p311 = goertzel (out, sr, 311.1);   // между гармониками
    check (p220 > 30.0 * p311, "пик на основной частоте выражен",
           "220/меж = " + std::to_string (p220 / (p311 + 1e-30)));
    check (p440 > 5.0 * p311, "вторая гармоника присутствует",
           "440/меж = " + std::to_string (p440 / (p311 + 1e-30)));
}

// ---------------------------------------------------------------------------
static void testFieldDecay()
{
    printf ("\n[5] Симпатические струны затухают примерно за заданный T60\n");
    const int sr = 48000;
    husk::SympatheticField f;
    f.prepare (sr);
    const float freqs[4] = { 110.0f, 164.81f, 220.0f, 329.63f };
    f.setTuning (freqs, 4);
    f.setDamping (3.0f, 0.9f);      // почти без ВЧ-демпфирования
    f.setDrift (0.0f, 0.0f);

    const int N = sr * 6;
    std::vector<float> out ((size_t) N);
    for (int i = 0; i < N; ++i)
    {
        const float x = (i < 32) ? 1.0f : 0.0f;
        out[(size_t) i] = f.process (x);
    }
    check (allFinite (out), "нет NaN");

    auto seg = [&] (int fromSec, int lenSec)
    {
        return rms (std::vector<float> (out.begin() + (size_t) fromSec * sr,
                                        out.begin() + (size_t) (fromSec + lenSec) * sr));
    };
    const float e0 = seg (0, 1), e3 = seg (3, 1);
    const float dropDb = 20.0f * std::log10 ((e3 + 1e-20f) / (e0 + 1e-20f));
    // за 3 секунды при T60 = 3 c ожидаем примерно −60 dB, допускаем разброс
    check (dropDb < -25.0f && dropDb > -95.0f, "затухание в разумных пределах",
           std::to_string (dropDb) + " dB за 3 c");
}

// ---------------------------------------------------------------------------
static void testKeyDetection()
{
    printf ("\n[6] Определение тональности\n");
    const int sr = 48000;
    husk::KeyFollower k;
    k.prepare (sr);
    // арпеджио D-dur: D3 F#3 A3 D4
    const float notes[4] = { 146.83f, 185.00f, 220.00f, 293.66f };
    for (int rep = 0; rep < 6; ++rep)
        for (int n = 0; n < 4; ++n)
            for (int i = 0; i < sr / 3; ++i)
            {
                const float t = (float) i / sr;
                float v = 0.0f;
                for (int h = 1; h <= 4; ++h)
                    v += std::sin (2.0f * husk::kPi * notes[n] * h * t) / (float) h;
                k.pushSample (0.25f * v * std::exp (-2.0f * t));
            }
    check (k.getRoot() == 2, "тоника определена как D",
           "получено " + std::to_string (k.getRoot()) + (k.getIsMinor() ? "m" : "M"));
}

// ---------------------------------------------------------------------------
static void testSampleRates()
{
    printf ("\n[7] Независимость от частоты дискретизации\n");
    const int rates[5] = { 44100, 48000, 88200, 96000, 192000 };
    float ref = 0.0f;
    bool ok = true;
    for (int idx = 0; idx < 5; ++idx)
    {
        const int sr = rates[idx];
        const int N = sr * 3;
        std::vector<float> in ((size_t) N, 0.0f);
        for (int i = 0; i < N; ++i)
            in[(size_t) i] = 0.3f * std::sin (2.0f * husk::kPi * 196.0f * i / sr)
                           * std::exp (-1.2f * (float) (i % sr) / sr);
        husk::Engine e;
        e.prepare (sr, 256);
        husk::Parameters p; p.mix = 1.0f;
        e.setParameters (p);
        std::vector<float> l, rr;
        runEngine (e, in, l, rr, 256);
        const float v = rms (l);
        if (! allFinite (l)) ok = false;
        if (idx == 0) ref = v;
        const float ratio = v / (ref + 1e-12f);
        check (std::isfinite (v) && ratio > 0.4f && ratio < 2.5f,
               "sr = " + std::to_string (sr), "rms " + std::to_string (v));
    }
    check (ok, "нет NaN ни на одной частоте");
}

// ---------------------------------------------------------------------------
static void testParameterStorm()
{
    printf ("\n[8] Шторм автоматизации (параметры меняются каждый блок)\n");
    const int sr = 48000, N = sr * 10;
    std::mt19937 rng (11);
    std::uniform_real_distribution<float> u (0.0f, 1.0f);
    std::uniform_real_distribution<float> d (-0.6f, 0.6f);
    std::vector<float> in ((size_t) N);
    for (auto& v : in) v = d (rng);

    husk::Engine e;
    e.prepare (sr, 32);
    std::vector<float> l ((size_t) N, 0.0f), r ((size_t) N, 0.0f);
    for (size_t i = 0; i < in.size(); i += 32)
    {
        husk::Parameters p;
        p.split = u (rng); p.cross = u (rng); p.huskGain = 3.0f * u (rng);
        p.bodyShape = u (rng); p.bodyModes = 4 + (int) (60 * u (rng));
        p.bodyDecay = 0.05f + 12.0f * u (rng); p.bodyBright = u (rng);
        p.bodyPos = 0.02f + 0.96f * u (rng); p.bodyAmt = u (rng);
        p.bodyTuneMode = (int) (3 * u (rng)) % 3;
        p.fieldAmt = u (rng); p.fieldDecay = 0.2f + 20.0f * u (rng);
        p.fieldDamp = 0.05f + 0.6f * u (rng); p.fieldStrings = 1 + (int) (11 * u (rng));
        p.drift = u (rng);
        p.airAmt = u (rng); p.airSize = 0.15f + 2.3f * u (rng);
        p.airBloom = 0.99f * u (rng); p.airDamp = u (rng); p.airDrive = u (rng);
        p.freeze = u (rng) > 0.9f;
        p.mix = u (rng);
        e.setParameters (p);
        const int n = (int) std::min<size_t> (32, in.size() - i);
        e.process (in.data() + i, l.data() + i, r.data() + i, n);
    }
    check (allFinite (l) && allFinite (r), "нет NaN при непрерывной автоматизации");
    check (peak (l) <= 1.01f, "выход ограничен", "пик " + std::to_string (peak (l)));
}

// ---------------------------------------------------------------------------
static void testDenormalDecay()
{
    printf ("\n[9] Затухание до денормальных значений не ломает и не тормозит\n");
    const int sr = 48000;
    husk::SympatheticField f;
    f.prepare (sr);
    const float fr[2] = { 110.0f, 220.0f };
    f.setTuning (fr, 2);
    f.setDamping (0.4f, 0.5f);
    f.setDrift (0.0f, 0.0f);
    for (int i = 0; i < 64; ++i) f.process (1.0f);
    float last = 0.0f;
    for (int i = 0; i < sr * 30; ++i) last = f.process (0.0f);
    check (std::isfinite (last) && std::fabs (last) < 1.0e-10f,
           "состояние уходит в ноль", "последнее " + std::to_string (last));
}

// ---------------------------------------------------------------------------
static void testFactoryBank()
{
    printf ("\n[10] Заводской банк пресетов\n");
    const auto& bank = husk::factoryPresets();
    check (bank.size() >= 12, "банк непустой", std::to_string (bank.size()) + " пресетов");

    std::set<std::string> names;
    bool dupes = false, emptyNote = false;
    for (const auto& p : bank)
    {
        if (! names.insert (p.name).second) dupes = true;
        if (p.note == nullptr || std::string (p.note).empty()) emptyNote = true;
    }
    check (! dupes, "имена уникальны");
    check (! emptyNote, "у каждого пресета есть описание");

    // прогон всего банка: сигнал, потом тишина
    const int sr = 48000;
    std::vector<float> in ((size_t) sr * 4, 0.0f);
    std::mt19937 rng (23);
    std::uniform_real_distribution<float> d (-0.5f, 0.5f);
    for (int i = 0; i < sr * 2; ++i)
    {
        const float t = (float) (i % (sr / 2)) / sr;
        in[(size_t) i] = (0.45f * std::sin (2.0f * husk::kPi * 196.0f * i / sr)
                          + 0.05f * d (rng)) * std::exp (-4.0f * t);
    }

    int bad = 0, loud = 0, silent = 0;
    for (const auto& pr : bank)
    {
        husk::Engine e;
        e.prepare (sr, 128);
        e.setParameters (husk::toEngine (pr.p));
        std::vector<float> l, r;
        runEngine (e, in, l, r);
        if (! allFinite (l) || ! allFinite (r)) { printf ("  ПРОВАЛ  NaN в %s\n", pr.name); ++bad; }
        if (peak (l) > 1.01f || peak (r) > 1.01f) { printf ("  ПРОВАЛ  клип в %s\n", pr.name); ++loud; }
        if (rms (l) < 1.0e-4f) { printf ("  ПРОВАЛ  тишина в %s\n", pr.name); ++silent; }
        // хвост должен затухать
        std::vector<float> tail (l.end() - sr / 2, l.end());
        if (rms (tail) > 0.3f) { printf ("  ПРОВАЛ  хвост не спадает в %s\n", pr.name); ++bad; }
    }
    check (bad == 0, "ни один пресет не даёт NaN и не зависает");
    check (loud == 0, "ни один пресет не клипует");
    check (silent == 0, "ни один пресет не молчит");
}

int main()
{
    printf ("=== Тесты DSP-ядра HUSK ===\n");
    testBypass();
    testStability();
    testFreezeAndDecayToSilence();
    testModalTuning();
    testFieldDecay();
    testKeyDetection();
    testSampleRates();
    testParameterStorm();
    testDenormalDecay();
    testFactoryBank();
    printf ("\n=== %d проверок, провалов: %d ===\n", checks, failures);
    return failures == 0 ? 0 : 1;
}
