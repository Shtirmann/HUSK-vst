// Оффскрин-рендер редактора в PNG: чтобы смотреть на интерфейс без DAW.
#include "../Source/PluginProcessor.h"
#include "../Source/PluginEditor.h"

int main (int argc, char** argv)
{
    juce::ScopedJuceInitialiser_GUI gui;

    HuskAudioProcessor proc;
    proc.prepareToPlay (48000.0, 512);
    if (argc > 2) proc.applyFactoryPreset (std::atoi (argv[2]));

    // прогоняем короткое арпеджио, иначе визуализаторы пустые
    {
        const int sr = 48000, n = sr * 3;
        juce::AudioBuffer<float> buf (2, 256);
        juce::MidiBuffer midi;
        const float notes[4] = { 146.83f, 185.0f, 220.0f, 293.66f };
        int pos = 0;
        while (pos < n)
        {
            for (int i = 0; i < 256; ++i)
            {
                const int g = (pos + i);
                const int note = (g / (sr / 3)) % 4;
                const float t = (float) (g % (sr / 3)) / sr;
                float v = 0.0f;
                for (int hmn = 1; hmn <= 6; ++hmn)
                    v += std::sin (2.0f * 3.14159265f * notes[note] * hmn * t) / (float) hmn;
                v = 0.28f * v * std::exp (-3.0f * t);
                buf.setSample (0, i, v);
                buf.setSample (1, i, v);
            }
            proc.processBlock (buf, midi);
            pos += 256;
        }
    }

    std::unique_ptr<juce::AudioProcessorEditor> ed (proc.createEditor());


    juce::Image img (juce::Image::ARGB, ed->getWidth(), ed->getHeight(), true);
    {
        juce::Graphics g (img);
        ed->paintEntireComponent (g, true);
    }

    const juce::File out (argc > 1 ? juce::String (argv[1]) : juce::String ("husk_ui.png"));
    out.deleteFile();
    juce::FileOutputStream os (out);
    juce::PNGImageFormat png;
    png.writeImageToStream (img, os);
    printf ("записано: %s\n", out.getFullPathName().toRawUTF8());

    if (auto* he = dynamic_cast<HuskAudioProcessorEditor*> (ed.get()))
    {
        auto j = out.withFileExtension ("json");
        j.replaceWithText (he->dumpLayout());
        printf ("геометрия: %s\n", j.getFullPathName().toRawUTF8());
    }
    return 0;
}
