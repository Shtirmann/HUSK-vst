// Офлайн-прогон движка без JUCE: проверка сборки, устойчивости и звука.
//   ./offline in.wav out.wav [preset]
#include "../Source/dsp/HuskEngine.h"
#include "../Source/Presets.h"
#include <cstdio>
#include <cstring>
#include <cstdint>
#include <vector>
#include <chrono>
#include <string>
#include <cctype>
#include <cstdlib>

#pragma pack(push, 1)
struct WavHeader
{
    char riff[4]; uint32_t size; char wave[4];
    char fmt[4];  uint32_t fmtSize; uint16_t fmtTag; uint16_t channels;
    uint32_t rate; uint32_t byteRate; uint16_t align; uint16_t bits;
    char data[4]; uint32_t dataSize;
};
#pragma pack(pop)

static bool readWav (const char* path, std::vector<float>& mono, int& sr)
{
    FILE* f = fopen (path, "rb");
    if (! f) return false;
    char id[4]; uint32_t sz;
    fread (id, 1, 4, f); fread (&sz, 4, 1, f); fread (id, 1, 4, f);   // RIFF/size/WAVE
    uint16_t ch = 1, bits = 16, tag = 1; uint32_t rate = 48000;
    std::vector<float> out;
    while (fread (id, 1, 4, f) == 4 && fread (&sz, 4, 1, f) == 1)
    {
        if (! memcmp (id, "fmt ", 4))
        {
            std::vector<uint8_t> b (sz);
            fread (b.data(), 1, sz, f);
            memcpy (&tag, b.data() + 0, 2);
            memcpy (&ch, b.data() + 2, 2);
            memcpy (&rate, b.data() + 4, 4);
            memcpy (&bits, b.data() + 14, 2);
        }
        else if (! memcmp (id, "data", 4))
        {
            std::vector<uint8_t> b (sz);
            fread (b.data(), 1, sz, f);
            const int bytes = bits / 8;
            const size_t frames = sz / (bytes * ch);
            out.resize (frames);
            for (size_t i = 0; i < frames; ++i)
            {
                double acc = 0.0;
                for (int c = 0; c < ch; ++c)
                {
                    const uint8_t* q = b.data() + (i * ch + (size_t) c) * (size_t) bytes;
                    if (tag == 3 && bits == 32) { float v; memcpy (&v, q, 4); acc += v; }
                    else if (bits == 16) { int16_t v; memcpy (&v, q, 2); acc += v / 32768.0; }
                    else if (bits == 24) { int32_t v = (q[0] << 8) | (q[1] << 16) | (q[2] << 24); acc += (v >> 8) / 8388608.0; }
                    else if (bits == 32) { int32_t v; memcpy (&v, q, 4); acc += v / 2147483648.0; }
                }
                out[i] = (float) (acc / ch);
            }
        }
        else fseek (f, (long) sz + (long) (sz & 1), SEEK_CUR);
    }
    fclose (f);
    mono.swap (out);
    sr = (int) rate;
    return ! mono.empty();
}

static void writeWav (const char* path, const std::vector<float>& l,
                      const std::vector<float>& r, int sr)
{
    const uint32_t frames = (uint32_t) l.size();
    WavHeader h {};
    memcpy (h.riff, "RIFF", 4); memcpy (h.wave, "WAVE", 4);
    memcpy (h.fmt, "fmt ", 4);  memcpy (h.data, "data", 4);
    h.fmtSize = 16; h.fmtTag = 1; h.channels = 2; h.rate = (uint32_t) sr;
    h.bits = 24; h.align = 6; h.byteRate = (uint32_t) sr * 6;
    h.dataSize = frames * 6; h.size = 36 + h.dataSize;
    FILE* f = fopen (path, "wb");
    fwrite (&h, sizeof h, 1, f);
    std::vector<uint8_t> buf (frames * 6);
    for (uint32_t i = 0; i < frames; ++i)
        for (int c = 0; c < 2; ++c)
        {
            float v = (c == 0 ? l[i] : r[i]);
            v = v > 0.999f ? 0.999f : (v < -0.999f ? -0.999f : v);
            const int32_t s = (int32_t) (v * 8388607.0f);
            uint8_t* q = buf.data() + (i * 2 + (uint32_t) c) * 3;
            q[0] = (uint8_t) (s & 0xff); q[1] = (uint8_t) ((s >> 8) & 0xff); q[2] = (uint8_t) ((s >> 16) & 0xff);
        }
    fwrite (buf.data(), 1, buf.size(), f);
    fclose (f);
}

static bool resolvePreset (const std::string& n, husk::UiParams& out, std::string& realName)
{
    const auto& bank = husk::factoryPresets();
    if (n == "dry")  { out.mix = 0.0f; realName = "dry";  return true; }
    if (n == "wet")  { out.mix = 1.0f; realName = "wet";  return true; }
    if (! n.empty() && isdigit ((unsigned char) n[0]))
    {
        const int i = std::atoi (n.c_str());
        if (i >= 0 && i < (int) bank.size()) { out = bank[(size_t) i].p; realName = bank[(size_t) i].name; return true; }
        return false;
    }
    const int i = husk::findPreset (n);
    if (i < 0) return false;
    out = bank[(size_t) i].p;
    realName = bank[(size_t) i].name;
    return true;
}

static void listPresets (bool tsv)
{
    const auto& b = husk::factoryPresets();
    for (size_t i = 0; i < b.size(); ++i)
    {
        if (tsv) printf ("%d\t%s\t%s\n", (int) i, b[i].category, b[i].name);
        else     printf ("%2d  %-10s  %-18s  %s\n", (int) i, b[i].category, b[i].name, b[i].note);
    }
}

int main (int argc, char** argv)
{
    if (argc >= 2 && std::string (argv[1]) == "--list")     { listPresets (false); return 0; }
    if (argc >= 2 && std::string (argv[1]) == "--list-tsv") { listPresets (true);  return 0; }
    if (argc < 3) { printf ("usage: offline in.wav out.wav [preset] [outputDb] [--wet]\n"
                            "       offline --list | --list-tsv\n"); return 1; }
    bool forceWet = false;
    for (int i = 1; i < argc; ++i) if (std::string (argv[i]) == "--wet") forceWet = true;
    std::vector<float> in;
    int sr = 48000;
    if (! readWav (argv[1], in, sr)) { printf ("не читается: %s\n", argv[1]); return 1; }

    const std::string pn = (argc > 3 ? argv[3] : "0");
    husk::UiParams ui;
    std::string realName;
    if (! resolvePreset (pn, ui, realName)) { printf ("нет такого пресета: %s\n", pn.c_str()); return 1; }
    if (argc > 4 && std::string (argv[4]) != "--wet") ui.outputDb = (float) std::atof (argv[4]);
    if (forceWet) { ui.mix = 1.0f; ui.outputDb = 0.0f; }

    husk::Engine e;
    e.prepare (sr, 512);
    e.setParameters (husk::toEngine (ui));

    std::vector<float> L (in.size()), R (in.size());
    const int block = 128;
    const auto t0 = std::chrono::steady_clock::now();
    for (size_t i = 0; i < in.size(); i += (size_t) block)
    {
        const int n = (int) std::min ((size_t) block, in.size() - i);
        e.process (in.data() + i, L.data() + i, R.data() + i, n);
    }
    const auto t1 = std::chrono::steady_clock::now();
    const double secs = std::chrono::duration<double> (t1 - t0).count();
    const double audio = (double) in.size() / sr;

    double pk = 0.0, rms = 0.0;
    bool bad = false;
    for (size_t i = 0; i < L.size(); ++i)
    {
        if (! std::isfinite (L[i]) || ! std::isfinite (R[i])) bad = true;
        pk = std::max (pk, (double) std::max (std::fabs (L[i]), std::fabs (R[i])));
        rms += (double) L[i] * L[i];
    }
    rms = std::sqrt (rms / L.size());

    printf ("%-16s  sr=%d  %.2f c аудио за %.3f c  (x%.1f реального времени, ~%.1f%% ядра)\n",
            realName.c_str(), sr, audio, secs, audio / secs, 100.0 * secs / audio);
    printf ("            пик=%.3f rms=%.4f  тональность=%d%s  f0=%.1f  %s\n",
            pk, rms, e.getKeyRoot(), e.getKeyMinor() ? "m" : "M", e.getTrackedF0(),
            bad ? "!!! NaN/Inf !!!" : "конечные значения ok");

    writeWav (argv[2], L, R, sr);
    return bad ? 2 : 0;
}
